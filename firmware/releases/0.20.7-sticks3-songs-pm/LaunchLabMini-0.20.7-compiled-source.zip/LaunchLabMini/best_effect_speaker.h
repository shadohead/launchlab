#pragma once
#include <M5Unified.h>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include "best_effect_sound.h"
#include "motion_acquisition.h"
#include "pm1_idle.h"
#include "es8311_power.h"
#include "sound_sync.h"
#include "music_stream.h"
#include "freertos/semphr.h"

// Plays personal-best sounds on the StickS3 speaker (ES8311 codec and amp).
// They are powered only while a sound plays: M5.Speaker.begin() before and
// end() once it is silent. Both switch power over the internal I2C bus the IMU
// owner polls, so they run under its gate, and end() never runs during a
// measured pull. Playback is the speaker's DMA task, pinned to the UI core
// and fed from a PSRAM buffer rendered once per effect, so UI frame timing
// cannot disturb it and acquisition on core 0 is untouched. Each sound has
// its own buffer, kept once rendered: a milestone's effect is only known
// when its pull ends, so every effect it may play is rendered ahead. At most
// MAX_BUFFERS are kept (about 90 KB each for a 2.8 s sound): preparing
// another frees the least recently used one, never the one playing. A
// loaded effect with a sound of its own (LoadableFx::Sound) has its slot's
// buffer, kept while its file stays the same; any other plays its stock
// fallback's. A loaded effect whose sound is a song (engine level 2) is
// streamed instead (music_stream.h): rendered by the music task on core 0
// as it plays, on its own channel, and it plays on past its effect's
// frames; a pull's start fades it out within 20 ms.

// The music task's lock (a FreeRTOS mutex) and the speaker's music channel.
struct RtosLock {
  SemaphoreHandle_t mutex=xSemaphoreCreateMutex();
  struct Hold {RtosLock &l;explicit Hold(RtosLock &x):l(x){xSemaphoreTake(l.mutex,portMAX_DELAY);}~Hold(){xSemaphoreGive(l.mutex);}};
};
using Music=MusicStream<RtosLock>;
struct MusicChannel:MusicOutput {
  static constexpr uint8_t CHANNEL=1;  // effect sounds play on 0
  unsigned queued() override{return unsigned(M5.Speaker.isPlaying(CHANNEL));}
  bool queue(const int16_t *p,size_t n) override{return M5.Speaker.playRaw(p,n,LoadableFx::SOUND_RATE,false,1,CHANNEL,false);}
  void volume(uint8_t v) override{M5.Speaker.setChannelVolume(CHANNEL,v);}
  void stop() override{M5.Speaker.stop(CHANNEL);}
};

class BestEffectSpeaker {
public:
  // While set the codec never starts: the battery lab's 40 MHz CPU stops the
  // PLL that clocks I2S (power_lab_device.h).
  bool blocked=false;
  // A loaded effect's own sound (loaded_effects.h, through the sketch):
  // whether the effect has one, its identity (its file's CRC, so a replaced
  // file renders again) and length, and a resumable render that gives the
  // same samples for any slicing, as BestEffectSound::Synth does.
  struct LoadedSounds {
    virtual bool sound(unsigned effect,uint32_t &key,size_t &samples)=0;  // false: it sounds as its stock fallback
    virtual bool begin(unsigned effect)=0;
    virtual size_t run(int16_t *out,size_t count)=0;
    // A song, streamed: whether the effect's sound is one, and its file.
    virtual bool song(unsigned effect)=0;
    virtual bool readSong(unsigned effect,const uint8_t *&file,size_t &bytes)=0;
  };
  explicit BestEffectSpeaker(StickS3MotionAcquisition &imu):imu_(imu){}
  // Call once after M5.begin() with the internal speaker configured.
  // Mono output: M5Unified sets the StickS3 up as stereo, so its task mixed
  // two identical channels from our mono sounds, refilling the DMA on the UI
  // core during effect frames (0.6-1 ms of a worst frame with sound on). Mono
  // halves that mixing at the same loudness (mono folds left and right
  // without the stereo gain shift) and the same I2S frames (the S3's mono
  // slot mode sends each sample on both slots, so the ES8311 sees no change).
  void configure() {
    auto c=M5.Speaker.config();c.task_pinned_core=1;c.stereo=false;M5.Speaker.config(c);
    configured_=M5.Speaker.isEnabled();
  }
  // Loaded effects' own sounds, once the store is open; without it every
  // loaded effect sounds as its stock fallback.
  void attach(LoadedSounds *loaded){loaded_=loaded;}
  // The music streamer and its task (on core 0), once allocated; without
  // them a song effect sounds as its stock fallback.
  void attachMusic(Music *music,TaskHandle_t task){music_=music;musicTask_=task;}
  // Renders up to `slice` more samples of the effect's sound into its own
  // buffer, restarting if another sound was in progress. A whole sound
  // takes far longer than a UI frame at 80 MHz, so the sketch renders a
  // slice per idle loop pass. Another sound's buffer may be playing.
  // A loaded effect plays its own sound when its file has one, else its
  // stock fallback's.
  bool prepare(Appearance::Effect e,size_t slice=SIZE_MAX) {
    const Source s=source(e);
    if(s.stream)return configured_;  // streamed as it plays: nothing to render ahead
    if(!configured_ || s.index==SOUNDS)return false;
    if(ready(s))return true;
    const unsigned i=s.index;
    // A loaded effect replaced while its old sound plays renders once that ends.
    if(i==playingIndex_ && begun_ && M5.Speaker.isPlaying())return false;
    used_[i]=++clock_;
    if(buffers_[i] && size(i)!=s.samples){heap_caps_free(buffers_[i]);buffers_[i]=nullptr;}
    if(!buffers_[i]) {
      makeRoom(i);
      buffers_[i]=static_cast<int16_t *>(heap_caps_malloc(s.samples*sizeof(int16_t),MALLOC_CAP_SPIRAM));
      if(!buffers_[i])return false;
      if(i>=Appearance::DRAWN)loadedSize_[i-Appearance::DRAWN]=s.samples;
    }
    rendered_[i]=false;
    if(target_!=i || targetKey_!=s.key) {
      target_=i;targetKey_=s.key;progress_=0;renderUs_=0;
      if(s.loaded){if(!loaded_->begin(unsigned(e))){target_=SOUNDS;return false;}}
      else synth_.restart(s.effect,s.samples);
    }
    const int64_t started=esp_timer_get_time();
    const size_t want=std::min(slice,s.samples-progress_);
    const size_t got=s.loaded?loaded_->run(buffers_[i]+progress_,want):synth_.run(buffers_[i]+progress_,want);
    progress_+=got;
    const uint32_t spent=uint32_t(esp_timer_get_time()-started);renderUs_+=spent;maxSliceUs_=std::max(maxSliceUs_,spent);
    if(progress_>=s.samples){rendered_[i]=true;if(i>=Appearance::DRAWN)loadedKey_[i-Appearance::DRAWN]=s.key;target_=SOUNDS;}
    else if(got<want)target_=SOUNDS;  // the render stopped short: start over next time
    return ready(s);
  }
  bool prepared(Appearance::Effect e)const{return ready(source(e));}
  bool muted=false;  // the mic holds the codec and its clock pins (mic_listener.h)
  // Powers the codec if it is off (under the IMU owner's gate).
  bool power() {
    if(begun_)return true;
    if(blocked || muted)return false;
    if(!imu_.lock()){++lockMisses_;return false;}
    const int64_t started=esp_timer_get_time();
    if(!pm1Idle().ensureAwake()){imu_.unlock();return false;}
    const bool ok=M5.Speaker.begin();
    beginUs_=std::max(beginUs_,uint32_t(esp_timer_get_time()-started));imu_.unlock();
    begun_=ok;return ok;
  }
  // Starts the effect's sound `skip` samples in; false if it is not ready,
  // the codec cannot start or nothing is left.
  bool play(Appearance::Effect e,Appearance::Sound level,size_t skip=0) {
    const Source s=source(e);
    // Rendering is the sketch's job, a slice per idle pass; play only what is ready.
    if(s.stream) {
      const uint8_t *file=nullptr;size_t bytes=0;
      if(level==Appearance::Sound::Off || !loaded_->readSong(unsigned(e),file,bytes) || !power())return false;
      M5.Speaker.setVolume(level==Appearance::Sound::High?HIGH_VOLUME:LOW_VOLUME);
      outputUs_=SoundSync::outputUs(M5.Speaker.isPlaying());
      if(!music_->start(file,bytes,uint32_t(skip),255,channel_))return false;
      xTaskNotifyGive(musicTask_);playingIndex_=SOUNDS;++plays_;return true;
    }
    if(level==Appearance::Sound::Off || !ready(s) || skip>=s.samples || !power())return false;
    M5.Speaker.setVolume(level==Appearance::Sound::High?HIGH_VOLUME:LOW_VOLUME);
    const unsigned i=s.index;
    outputUs_=SoundSync::outputUs(M5.Speaker.isPlaying());
    if(!M5.Speaker.playRaw(buffers_[i]+skip,s.samples-skip,BestEffectSound::RATE,false,1,0,true))return false;
    used_[i]=++clock_;playingIndex_=i;++plays_;return true;
  }
  // The latency of the last play's first sample (SoundSync::outputUs), and
  // what the next would have now.
  uint32_t outputUs()const{return outputUs_;}
  uint32_t nextOutputUs(){return SoundSync::outputUs(begun_ && M5.Speaker.isPlaying());}
  // Silence now: no bus traffic, safe during a measured pull.
  void stop(){if(music_)music_->stop(channel_);if(begun_ && M5.Speaker.isPlaying()){M5.Speaker.stop();++stops_;}}
  // A pull begins: effect sounds stop at once, a song fades out within 20
  // ms (no bus traffic either way).
  void fadeOut() {
    if(music_ && music_->active())music_->fade(uint32_t(esp_timer_get_time()/1000));
    if(begun_ && M5.Speaker.isPlaying(0)){M5.Speaker.stop(0);++stops_;}
  }
  // A song is playing (it outlives its effect's frames).
  bool streaming()const{return music_ && music_->active();}
  // Each loop pass: the song's next blocks to the speaker; the codec powers
  // down once silent, but never while a pull is measured.
  // The song's next blocks to the speaker: every loop pass, and between the
  // lines of a long print in the same pass (status()), as a song has only
  // two 32 ms blocks queued.
  void feedSong(){if(music_)music_->feed(uint32_t(esp_timer_get_time()/1000),channel_);}
  void tick(bool measuring) {
    feedSong();
    if(!begun_ || measuring || M5.Speaker.isPlaying() || streaming() || !imu_.lock())return;
    powerDownLocked();imu_.unlock();
  }
  // Before sleep or power-off: silence and power down at once, so neither the
  // amplifier enable nor the codec stays on through standby. stop() only asks
  // M5's speaker task to stop (isPlaying() stays true until it has), so this
  // does not wait for tick(): end() stops the task itself.
  void shutdown() {
    stop();
    if(!begun_ || !imu_.lock())return;
    powerDownLocked();imu_.unlock();
  }
  bool powered()const{return begun_;}
  bool playing()const{return begun_ && (M5.Speaker.isPlaying() || streaming());}
  void status(Appearance::Sound level) {
    unsigned buffers=0;for(const auto *b:buffers_)buffers+=b!=nullptr;
    static char rendered[512],loaded[160];std::strcpy(rendered,"none");std::strcpy(loaded,"none");size_t used=0,usedLoaded=0;
    for(unsigned i=0;i<Appearance::DRAWN;++i)if(rendered_[i])
      used+=snprintf(rendered+used,sizeof(rendered)-used,"%s%s",used?",":"",Appearance::label(Appearance::drawnEffect(i)));
    for(unsigned i=Appearance::DRAWN;i<SOUNDS;++i)if(rendered_[i])
      usedLoaded+=snprintf(loaded+usedLoaded,sizeof(loaded)-usedLoaded,"%s%u",usedLoaded?",":"",Appearance::FIRST_LOADED+i-Appearance::DRAWN);
    Serial.printf("SOUND_STATUS level=%s configured=%d buffers=%u evictions=%lu rendered=%s powered=%d playing=%d plays=%lu stops=%lu lock_misses=%lu render_us=%lu max_slice_us=%lu max_begin_us=%lu max_end_us=%lu loaded_rendered=%s codec_failures=%lu\n",
      Appearance::label(level),configured_,buffers,(unsigned long)evictions_,rendered,begun_,playing(),
      (unsigned long)plays_,(unsigned long)stops_,(unsigned long)lockMisses_,(unsigned long)renderUs_,(unsigned long)maxSliceUs_,(unsigned long)beginUs_,(unsigned long)endUs_,loaded,(unsigned long)codecFailures_);
    Serial.printf("MUSIC_STATUS ready=%d streaming=%d fading=%d plays=%lu underruns=%lu played_blocks=%lu\n",music_!=nullptr,streaming(),
      music_ && music_->fading(),(unsigned long)(music_?music_->plays():0),(unsigned long)(music_?music_->underruns():0),(unsigned long)(music_?music_->played():0));
  }
  static constexpr unsigned MAX_BUFFERS=12;
  // A buffer per built-in effect, then one per loaded slot.
  static constexpr unsigned SOUNDS=Appearance::DRAWN+Appearance::LOADED;
private:
  static constexpr uint8_t LOW_VOLUME=72,HIGH_VOLUME=160;
  // The speaker off, under the IMU owner's gate: end() only switches the
  // amplifier off (M5Unified on StickS3), so the codec's own power-down.
  void powerDownLocked() {
    const int64_t started=esp_timer_get_time();
    if(!pm1Idle().ensureAwake())return;
    M5.Speaker.end();
    if(!Es8311Power::down(M5.In_I2C))++codecFailures_;
    endUs_=std::max(endUs_,uint32_t(esp_timer_get_time()-started));
    begun_=false;
  }
  // What an effect sounds like: a loaded effect's own sound (its slot's
  // buffer, keyed by its file), else the built-in it stands for.
  struct Source {unsigned index=SOUNDS;Appearance::Effect effect=Appearance::Effect::Off;bool loaded=false,stream=false;uint32_t key=0;size_t samples=0;};
  Source source(Appearance::Effect e)const {
    Source s;
    if(Appearance::loaded(unsigned(e)) && loaded_ && music_ && loaded_->song(unsigned(e))){s.effect=e;s.stream=true;return s;}
    if(Appearance::loaded(unsigned(e)) && loaded_ && loaded_->sound(unsigned(e),s.key,s.samples) && s.samples) {
      s.index=Appearance::DRAWN+(unsigned(e)-Appearance::FIRST_LOADED);s.effect=e;s.loaded=true;return s;
    }
    e=Appearance::stockFallback(e);
    if(Appearance::drawn(unsigned(e))){s.index=Appearance::drawnIndex(e);s.effect=e;s.samples=BestEffectSound::samples(e);}
    return s;
  }
  bool ready(const Source &s)const{if(s.stream)return configured_;return s.index<SOUNDS && rendered_[s.index] && size(s.index)==s.samples && (!s.loaded || loadedKey_[s.index-Appearance::DRAWN]==s.key);}
  // A buffer's length: a built-in's is fixed, a loaded slot's is its file's.
  size_t size(unsigned i)const{return i<Appearance::DRAWN?BestEffectSound::samples(Appearance::drawnEffect(i)):loadedSize_[i-Appearance::DRAWN];}
  // Frees least recently used buffers until one more fits, keeping `keep`
  // and the buffer the speaker is playing.
  void makeRoom(unsigned keep) {
    for(;;) {
      unsigned count=0,oldest=SOUNDS;
      for(unsigned j=0;j<SOUNDS;++j) {
        if(!buffers_[j])continue;
        ++count;
        if(j==keep || (j==playingIndex_ && M5.Speaker.isPlaying()))continue;
        if(oldest==SOUNDS || used_[j]<used_[oldest])oldest=j;
      }
      if(count<MAX_BUFFERS || oldest==SOUNDS)return;
      heap_caps_free(buffers_[oldest]);buffers_[oldest]=nullptr;rendered_[oldest]=false;++evictions_;
      if(target_==oldest)target_=SOUNDS;
    }
  }
  StickS3MotionAcquisition &imu_;
  LoadedSounds *loaded_=nullptr;
  Music *music_=nullptr;TaskHandle_t musicTask_=nullptr;MusicChannel channel_;
  // More sounds than a 64-bit mask holds since 0.18: one flag each.
  int16_t *buffers_[SOUNDS]={};bool rendered_[SOUNDS]={};uint32_t used_[SOUNDS]={},clock_=0,evictions_=0;unsigned playingIndex_=SOUNDS;
  // A loaded slot's rendered sound: its file's key and its length.
  uint32_t loadedKey_[Appearance::LOADED]={};size_t loadedSize_[Appearance::LOADED]={};
  BestEffectSound::Synth synth_{Appearance::Effect::Off,0};
  unsigned target_=SOUNDS;uint32_t targetKey_=0;size_t progress_=0;  // the sound being rendered and how far
  bool configured_=false,begun_=false;
  uint32_t plays_=0,stops_=0,lockMisses_=0,renderUs_=0,maxSliceUs_=0,beginUs_=0,endUs_=0,outputUs_=0,codecFailures_=0;
};

