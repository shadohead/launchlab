#include <M5Unified.h>
#include <Preferences.h>
#include <memory>
#include "esp_mac.h"
#include "acquisition.h"
#include "level_indicator.h"
#include "practice_store.h"
#include "history_log.h"
#include "spiffs_flash.h"
#include "loaded_effects.h"
#include "fx_transfer.h"
#if LAUNCHLAB_HIL
// Test builds: the NVS write faults (hil.h) also slow, fail or arm the history log writes.
namespace Hil{inline bool nvsWrite(const char *key,size_t bytes);}
#endif
#include "practice_ui.h"
#include "power_status.h"
#include "sensor_idle.h"
#include "cpu_power.h"
#include "power_savers.h"
#include "frame_rows.h"
#ifndef LAUNCHLAB_MOTION_ADC_GATE
#define LAUNCHLAB_MOTION_ADC_GATE 0
#endif
#include "usb_awake.h"
#include <HWCDC.h>
#include "usb_tx.h"
#include "usb_command_guard.h"
#include "power_diagnostics.h"
#ifndef LAUNCHLAB_POWER_LAB
#define LAUNCHLAB_POWER_LAB 0
#endif
#if LAUNCHLAB_POWER_LAB
#include "power_lab.h"
// Battery lab test builds (power_lab_device.h): the open run's profile; the
// shipped behaviour (default knobs) when no run is open.
namespace Lab {inline PowerLab::Knobs knobs;inline bool running=false,displayAsleep=false;inline uint32_t frames=0,rows=0,loops=0;}
#endif
#include <sys/time.h>
#include <esp32-hal-cpu.h>
#include <esp_heap_caps.h>
#include <esp_ota_ops.h>
#include <esp_image_format.h>
#include <esp_memory_utils.h>
#include <nvs.h>
#include "shake_wake.h"
#include "wake_ui_state.h"
#include "rpm_estimator_setting.h"
#include "brightness.h"
#include "display_flip_setting.h"
#include "ble_link.h"
#include "ble_motion.h"
#include "battle_radio.h"
#include "battles_setting.h"
#include "bluetooth_setting.h"
#include "shake_wake_setting.h"
#include "battery_icon_setting.h"
#include "min_rpm_setting.h"
#include "display_orientation.h"
#include "sensor_profile_setting.h"
#include "start_mark_reference.h"
#include "mount_orientation_setting.h"
#include "dark_display.h"
#include "controls_ui.h"
#include "motion_acquisition.h"
#include "i2c_bus_recovery.h"
#include "motion_store.h"
#include "motion_ui.h"
#include "launch_feedback.h"
#include "appearance_store.h"
#include "milestones.h"
#include "milestone_store.h"
#include "effect_set.h"
#include "best_effect_ui.h"
#include "screens_ui.h"
#include "battle_ui.h"
#include "theme_store.h"
#include "best_effect_speaker.h"
#include "device_backup.h"
#include "device_restore.h"
#include "nvs_budget.h"
#include "radio_calibration.h"
#include "device_wipe_nvs.h"
#include "wipe_confirmation.h"
#include "settings_save.h"

// loop() runs on an 8 KB task. GCC inlines static helpers called once, and the
// frames of inlined bodies add up: 0.11.0's loop frame reached 6.9 KB and
// overflowed on the first status print. Keep heavy or rarely used helpers as
// real calls so each one uses stack only while it runs.
#define LOOP_HELPER __attribute__((noinline))
#include "firmware_version.h"
#if LAUNCHLAB_HIL
// Test-only hardware-in-the-loop build; never a release. See tools/hil.
static constexpr char VERSION[] = "0.21.0-sticks3-songs-hil-pm";
#elif LAUNCHLAB_CPU_PM
static constexpr char VERSION[] = "0.21.0-sticks3-songs-pm";
#else
static constexpr char VERSION[] = "0.21.0-sticks3-songs";
#endif
static_assert(sizeof(VERSION)<=DeviceBackup::RUNTIME_BYTES,"Runtime must fit the USB backup header");
#ifndef LAUNCHLAB_CPU_MHZ
#define LAUNCHLAB_CPU_MHZ 80
#endif
static_assert(LAUNCHLAB_CPU_MHZ==80 || LAUNCHLAB_CPU_MHZ==160 || LAUNCHLAB_CPU_MHZ==240,
  "CPU policy must retain the 80 MHz peripheral clock");
static_assert(!LAUNCHLAB_CPU_PM || LAUNCHLAB_CPU_MHZ==80,"Experimental DFS uses a maximum of 80 MHz");
static constexpr uint32_t ANALOG_SAMPLE_HZ = StickS3Acquisition::SAMPLE_HZ;
#include "raw_transfer.h"
#include "mic_listener.h"
#include "mic_view_ui.h"
#include "analysis_ui.h"
#include "analysis_result_service.h"
#include "audio_metadata_store.h"
#include <esp_app_desc.h>
#include "analysis_result_ui.h"
static AnalysisResult::Service analysisResults;
static AnalysisMode::Session analysis;
static bool analysisCapturePending();
static AnalysisUI::Cache analysisCache;
static uint8_t analysisCacheRotation=0xff;
static StickS3Acquisition acquisition;
static Preferences prefs;
static StickS3Level level;
static M5Canvas screen(&M5.Display);
// What the panel shows, for pushing only the rows that changed (frame_rows.h).
static FrameRows frameRows;static uint8_t frameRotation=0xff;
static PracticeHistory practice;
// USB `t`'s synthetic history (2.6 KB), in PSRAM like micListener: only the
// loop reads it (the History page, its B button and `t`), never a save, the
// IMU or acquisition tasks, an interrupt or a flash write.
static PracticeHistory &demoPractice=*new(heap_caps_aligned_alloc(alignof(PracticeHistory),sizeof(PracticeHistory),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)) PracticeHistory;
static PracticeStore practiceStore;
static Appearance::Config appearance;
static Appearance::Bests personalBests;
static AppearanceStore<Appearance::Config> appearanceStore;
static AppearanceStore<Appearance::Bests> bestStore;
// Automatic saves (history, bests, the power log) go to the history log in
// the spiffs partition (history_log.h): program-only writes the ADC rides,
// no checkpoint and no NVS while the device is in use. NVS keeps 0.15-0.17's
// records as the mirror written at sleep, power-off and restore. Without the
// log (another layout found there), they go to NVS in a checkpoint as before.
static SpiffsFlash spiffsFlash;static HistoryLog::Store<SpiffsFlash> historyLog;
// Loaded effects (loaded_effects.h, docs/FIRMWARE_LOADABLE_EFFECTS.md): the
// store in the same partition and the engine that plays them, allocated at
// boot after the ADC has its DMA memory (internal heap), the playing file in
// PSRAM. Null when either allocation failed: loaded IDs then play their fallbacks.
static LoadedEffects<SpiffsFlash> *loadedEffects=nullptr;
// USB `X`: the request's base64 text and its bytes, in PSRAM, allocated at the first `X`.
static FxTransfer::Receiver effectRx;static char *effectRxText=nullptr;static uint8_t *effectRxBytes=nullptr;
static int64_t effectGuardStart=0;
static uint32_t loggedHistory=0,loggedBests=0;
static uint32_t powerMirror=0;  // checksum of the power log NVS holds
// The user's custom themes (theme IDs THEMES..), beside the appearance record.
static Themes::Library themeLibrary;
static ThemeStore themeStore;
// The Celebrate mode and the RPM milestone table, one record beside them. A
// damaged record shows the defaults and is replaced by the next change.
static Milestones::Config milestones;
static MilestoneStore milestoneStore;
// Each row's next effect, picked from its pool ahead of the pull that plays
// it, so its sound is rendered in time; picked again after it plays (never
// the same twice in a row when the pool has more) and when the table changes.
static Appearance::Effect milestoneNext[Milestones::MAX_ROWS];
static Milestones::Config milestonePicked;static bool milestonePicksReady=false;
// The effect set: the effects Best effect offers and Random draws from, a
// record beside them. A damaged record offers the default set and is
// replaced by the next change.
static EffectSet::Config effectSet;
static AppearanceStore<EffectSet::Config> effectSetStore;
static Appearance::Celebration bestEffect;
// The Best effect editor previews the draft around its value card.
static Appearance::Celebration editorEffect;
// Random's next pick, chosen ahead of the next best so its sound can render.
static Appearance::Effect upcomingEffect=Appearance::Effect::Off;
static BestEffectUI::Renderer bestEffectRenderer;
static bool effectWasMoving=false;
static PracticeUI::View historyView=PracticeUI::View::Recent;
static bool historyPage=false,demo=false,saveError=false;
static bool tournamentMode=false;
enum class TournamentView:uint8_t { RecordingOnly, Rpm };
static TournamentView tournamentView=TournamentView::RecordingOnly;
static Controls::State controls;
static Controls::Gesture gestureA,gestureB;
static WipeConfirmation wipeConfirmation;
static bool wipeFailed=false,wipeBlocked=false,wipeComplete=false;
static bool wipeCheckpointHeld=false,wipeBootRecovery=false,wipeRestartRequested=false;
static bool restorePreview=false;
static uint32_t tournamentHintUntil=0;

static unsigned historyOffset=0;
static uint32_t lastSaveTry=0,saveCount=0,saveErrors=0,maxSaveUs=0,newSessionAt=0;
static constexpr uint32_t HISTORY_COALESCE_MS=10000;
static constexpr uint32_t CELEBRATION_HOLD_MS=1000;
static constexpr uint32_t HISTORY_SAVE_RETRY_MS=5000;
static uint32_t lastAcceptedAt=0,historyPendingSince=0;
static bool screenReady=false;
static bool diagnostics=false,extPower=false,stress=false,dirty=true;
// The Battle Pass profile: the launch number a Beyblade X app's last clear
// (0x75) confirmed, saved, and how many launches that clear took (0 none
// since boot). The app has every launch up to it; the pass lists the rest.
static uint32_t passConfirmed=0,passLastSync=0;
static constexpr const char *PASS_CONFIRMED_KEY="bp_confirmed";
static uint32_t lastDraw=0,lastStatus=0,lastRevision=0,lastBelowMin=0,maxDrawUs=0,maxEffectUs=0,uiStalls=0;
#if LAUNCHLAB_HIL
// HIL only: each recap effect pass since the last E preview (elapsed ms, us),
// listed by `!effectframes`, to see where in an effect its time goes.
static struct {uint16_t elapsed[128],us[128];unsigned count=0;} effectFrames;
// The loaded-effects spike (hil_fx.h): draws a previewing file instead.
static bool hilFxDraw(uint16_t *pixels,int width,int height,uint32_t elapsed,uint16_t accent,uint16_t background);
#ifdef BEST_EFFECT_PROFILE
// A profiling debug build only: each pass's cycles per renderer stage, for
// `!effectstages`.
static struct {uint16_t elapsed[64];uint32_t us[64],cycles[64][BestEffectUI::Renderer::STAGES];unsigned count=0;} effectStages;
#endif
#endif
static uint32_t lastImuPoll=0,maxImuPollUs=0;
static StickS3Level::Reading drawnLevel;
static InactivityTimer inactivity;static OpticalSleepGuard opticalGuard;static ShutdownSaveGuard shutdownSaves;static HeldButtonUse heldButtons;
static uint64_t lastActivityMotionUs=0;
// USB letters a stray byte stream sent outside a standalone command.
static UsbCommandGuard usbCommands;
// Automatic checkpoints prefer a launcher the IMU shows set down.
static HistoryCheckpoint::Stillness imuStill;
static SensorIdle sensorIdle;
static UsbHostAwake usbAwake;
static bool usbAutoOffInhibited=false;
static StickS3ShakeWake shakeWake;
// A side-key click is latched by the G13 edge ISR and acted on by the loop.
static bool powerKeyRequested=false;
static uint32_t powerKeyRequestedAt=0,lastPowerKeyRead=0;
static constexpr uint32_t POWER_KEY_WAIT_MS=10000;
static bool settingsSaveError=false;
static SettingsSave settingsSave;
// A stopped, non-resting ADC owner outlasting this is a lost checkpoint reply.
static constexpr uint32_t ORPHAN_CHECKPOINT_MS=1000;
static bool orphanSeen=false;static uint32_t orphanSince=0;
static uint8_t brightnessPercent=Brightness::DEFAULT_PERCENT;
static bool displayFlipped=false;
// Shake to wake (0.20.2, shake_wake_setting.h): whether an inactivity sleep arms the IMU wake.
static bool shakeToWake=ShakeWakeSetting::DEFAULT_ON;
// Shake wakes in a row that nobody used, as last saved (UnusedWakes, power_status.h).
static uint8_t unusedWakes=0;
// Battery icon (0.20.8, battery_icon_setting.h): the charge in the screens' top right corner.
static bool batteryIcon=BatteryIconSetting::DEFAULT_ON;
// Min RPM's step count (min_rpm.h): the slowest launch recorded is 500 x this.
static uint8_t minRpmSteps=MinRpm::DEFAULT_STEPS;
static ControlsUI::CornerBattery drawnCornerBattery;  // as last drawn
// Off until chosen under Settings; the stack then starts without a restart.
static bool bluetoothOn=BluetoothSetting::DEFAULT_ON;
// As read at boot: the layout and the stack follow this until a restart.
static bool bluetoothAtBoot=BluetoothSetting::DEFAULT_ON;
// Battles (docs/FIRMWARE_BATTLES.md): the record against each rival, and this
// stick's side of the battle it is in. The record is in PSRAM, as demoPractice
// is: only the loop reads and changes it, and its save copies it to a PSRAM
// image before any flash write. It is saved to the history log (history_log.h).
static Battle::Book &rivals=*new(heap_caps_aligned_alloc(alignof(Battle::Book),sizeof(Battle::Book),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)) Battle::Book;
static Battle::Session battle;
static uint32_t loggedRivals=0;
// Auto battles (battles_setting.h): whether a launch looks for a rival's, and
// the match length this player chooses.
static bool battlesOn=BattlesSetting::DEFAULT_ON;
static uint8_t battleMatchTo=Battle::MATCH_SHORT;
namespace BattleFeed {static bool cardShown();static bool press(Battle::Button button);static void status();}
static RpmEstimator::Mode rpmEstimator=RpmEstimator::DEFAULT_MODE;
static StickS3SensorProfile::Mode sensorProfile=StickS3SensorProfile::DEFAULT_MODE;
static MountOrientation::Mode mountMode=MountOrientation::Mode::Top;
// The frame level data and the IMU owner actually use. A new mount choice is
// switched to inside its save checkpoint: switching clears the IMU ring, which
// must never happen during a pull or its capture.
static MountOrientation::Mode liveMount=MountOrientation::Mode::Top;
static StickS3Battery battery;
static ControlsUI::FlashInfo deviceFlash;
static DarkDisplay darkDisplay;
static uint32_t lastBatteryPoll=0,maxBatteryPollUs=0,lastShutdownTry=0;
static bool batteryPolled=false;
static bool powerConfigValid=false;
static uint8_t powerConfig=0;
static Preferences powerPrefs;
static PowerDiagnostics::Image powerLog;
static bool powerLogReady=false,powerLogDirty=false;
static uint32_t powerLogTick=0,lastPowerSample=0,lastPowerSaveTry=0;
struct SleepReceipt {uint32_t magic;int64_t atUs;};
RTC_DATA_ATTR static SleepReceipt sleepReceipt={};
RTC_DATA_ATTR static UsbStandby usbStandby={};
static bool finishStandby=false;
// What the timer re-check of a USB-retained standby read before the boot:
// PM1's power source (0x04) and system IRQ mask (0x44, bit 1 = 5VIN removal).
static struct {bool ran=false,read=false;uint8_t source=0,mask=0xff;} standbyRecheck;
#if LAUNCHLAB_HIL
static char standbyWakeText[224]="none";  // USB_STANDBY_WAKE's fields, for HIL !standbywake (setup writes 224)
#endif
#if LAUNCHLAB_HIL
// !usbstandby <s>: the next USB-retained standby re-checks after s seconds
// and then boots rather than sleeping again, so the rig gets the unit back.
RTC_DATA_ATTR static uint32_t hilStandbyRecheckS=0;
// !flushpull <s>: the next pull's result is left for the side key's shutdown
// flush, as for a pull that ends between the loop's drain and the off
// (shutdown_pull); the off is asked as soon as the detector counts it.
static struct {bool armed=false,holding=false;uint32_t launches=0;} hilFlushPull;
#endif
static uint8_t pm1WakeFlags=0;
static bool pm1WakeValid=false;
static StickS3MotionAcquisition imuAcquisition;
static BestEffectSpeaker soundPlayer(imuAcquisition);
// In PSRAM, made before setup() (the IDF adds PSRAM to the heap before the
// constructors run): the internal heap keeps every byte for pulls and songs.
static MicListener &micListener=*new(heap_caps_aligned_alloc(alignof(MicListener),sizeof(MicListener),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)) MicListener(imuAcquisition);
// A frame costs 22-43 ms at 80 MHz (the 0.20.5 gate's recaps) and the tracker
// runs below the UI, so Analysis redraws at 5 Hz at most.
static constexpr uint32_t MIC_PAGE_FRAME_MS=200;
static uint32_t micPageChecked=0;static bool micPageWarm=false,micPageFresh=false;
// Which sound is playing: a celebration stops when its recap goes, a Settings
// preview when its editor closes. A requested sound that is not rendered yet
// waits for the idle slices rather than stalling the UI loop to render it.
static bool celebrationSound=false,soundPreview=false;
static struct {bool active=false,celebration=false;Appearance::Effect effect=Appearance::Effect::Off;Appearance::Sound level=Appearance::Sound::Off;} soundRequest;
// From reading an effect frame's elapsed time to that frame on the glass
// (effect draw and push), measured each frame: SoundSync lines sound up with it.
static int64_t effectReadUs=0;static uint32_t presentLagUs=15000;
// The last sound start: how far its effect's clock moved, or the samples it
// skipped to join late (SOUND_SYNC).
static int32_t soundShiftMs=0;static uint32_t soundSkipped=0;
// A celebration sound that cannot start within this long after its effect is dropped.
static constexpr uint32_t SOUND_LATE_MS=300;
// A song is heard from its first block, queued once its pre-roll is rendered
// (music_stream.h, 30-95 ms after it starts): its effect holds its first
// frame until then, this long at most, and tickSound() lines it up.
static Appearance::Celebration *songCue=nullptr;static uint32_t songCueFrom=0;
static constexpr uint32_t SONG_HOLD_MS=500;
static void requestSound(Appearance::Effect effect,Appearance::Sound level,bool celebration);static void startSound(bool late);
static const char *milestoneStoreName();static const char *effectSetFields();
static Appearance::Effect celebrationEffect();static Appearance::Effect soundTarget();
static const Appearance::Effect *milestonePicks();static void nextMilestonePick(uint16_t rpm,Appearance::Effect played);
static constexpr size_t USB_TX_BUFFER_BYTES=8192;
// HWCDC drops bytes once its RX queue is full, and a tool's request line
// arrives in one burst. Every build uses this size: the HIL build alone once
// had a large queue, which hid that production's 256-byte one lost the end of
// every v3 milestone request (312 characters), so no save reached 0.18.0.
static constexpr size_t USB_RX_BUFFER_BYTES=8192;
static constexpr uint32_t MOTION_INIT_RETRY_MS=5000,MOTION_DATA_TIMEOUT_MS=250;
// The 1024-sample ring (10 s at 100 Hz) still holds a pull for this long.
static constexpr uint64_t MOTION_CAPTURE_RETRY_US=3000000;
static uint32_t motionCaptureRetries=0,motionRestoreFailures=0;
static bool motionRestoreNeeded=false;
static uint32_t motionInitAttempts=0,lastMotionInit=0;
static bool motionInitPaired=false,motionInitSuccess=false;
static MotionStore motionStore;
// A restore's base64 text, in PSRAM (allocated at the first R): a backup
// with loaded effects can carry up to 32 of them. Decoded in place.
static DeviceBackup::BufferReceiver restoreRx;static char *restoreText=nullptr;
// One framed custom theme request (USB `T`).
static DeviceBackup::LineReceiver<(Themes::Request::BYTES+2)/3*4> themeRx;
// One framed milestone request (USB `U`).
static DeviceBackup::LineReceiver<(Milestones::Request::BYTES+2)/3*4> milestoneRx;
static LaunchMotion::Trace latestMotion,referenceMotion,demoMotion;
// The latest pull's RPM turn by turn (the recap's graph); empty after a restart.
static AnalogTachometer::Curve latestCurve;
static bool motionPending=false,referenceError=false,motionDemo=false;
static uint64_t motionStart=0,motionEnd=0,lastLevelSampleUs=0;
static uint32_t motionDrops=0;
static I2cBusRecovery::Result i2cRecovery=I2cBusRecovery::Result::Idle;static unsigned i2cRecoveryPulses=0;
static bool i2cSdaWas=true,i2cSclWas=true;
static LaunchFeedback launchFeedback;
static AnalogTachometer::Phase lastPhase=AnalogTachometer::Phase::Paused;
static bool lastFault=false;
using Action=StickS3Acquisition::Action;
using Snapshot=StickS3Acquisition::Snapshot;
enum class ShutdownFlush:uint8_t {Busy,NewPull,SaveFailed,Ready};
// Why a shutdown flush runs (flushForShutdown): the inactivity sleep, the side key's power-off, the Bluetooth restart.
enum class ShutdownWhy:uint8_t {Sleep,SideKey,Restart};

static bool motionSensorPaired() {
  // isEnabled only establishes driver detection. Require an actual new paired
  // read before starting the fusion owner; cached data and rest are not tests.
  M5.Imu.setCalibration(0,0,0);
  const uint32_t started=millis();
  do {
    const unsigned fresh=M5.Imu.update();
    const unsigned both=m5::IMU_Class::sensor_mask_accel|m5::IMU_Class::sensor_mask_gyro;
    if((fresh&both)==both) {
      const auto data=M5.Imu.getImuData();
      if(std::isfinite(data.accel.x) && std::isfinite(data.accel.y) && std::isfinite(data.accel.z) &&
         std::isfinite(data.gyro.x) && std::isfinite(data.gyro.y) && std::isfinite(data.gyro.z))return true;
    }
    delay(5);
  } while(uint32_t(millis()-started)<MOTION_DATA_TIMEOUT_MS);
  return false;
}

static bool startMotion() {
  if(imuAcquisition.running())return true;
  // No IMU owner exists here. Main-thread power/level calls are serialized;
  // only the missing IMU is reinitialized, not M5 or optical acquisition.
  ++motionInitAttempts;lastMotionInit=millis();
  // Every M5 begin resets the BMI270 range and FIFO; both must follow detection.
  motionInitPaired=M5.Imu.isEnabled() && configureMotionSensor() && motionSensorPaired();
  if(!motionInitPaired) {
    const bool detected=M5.Imu.begin(&M5.In_I2C,m5::board_t::board_M5StickS3);
    motionInitPaired=detected && configureMotionSensor() && motionSensorPaired();
  }
  // Nothing is captured before the owner starts, so it can take the chosen mount.
  const bool mounted=motionInitPaired && imuAcquisition.setMount(mountMode);
  if(mounted)liveMount=mountMode;
  motionInitSuccess=mounted && imuAcquisition.begin();
  Serial.printf("IMU_STARTUP attempt=%lu enabled=%d type=%d paired=%d task=%d elapsed_ms=%lu\n",
    (unsigned long)motionInitAttempts,M5.Imu.isEnabled(),int(M5.Imu.getType()),motionInitPaired,
    imuAcquisition.running(),(unsigned long)(millis()-lastMotionInit));
  return motionInitSuccess;
}

// Every flash write runs inside an ADC checkpoint (DMA cannot survive the
// cache stall either). The same boundary keeps IMU transfers out of the stall.
// If no quiet window can be established the checkpoint is vetoed; every
// caller already treats a refused checkpoint as busy and retries later.
static bool quietImuForFlash(Action action,bool done,bool ok) {
  const bool writes=action==Action::IdleCheckpointBegin || action==Action::ShutdownBegin || action==Action::ShutdownForce ||
    action==Action::HistoryIdleCheckpointBegin || action==Action::CheckpointBegin;
  if(writes && !done)return imuAcquisition.quiet();
  if((writes && !ok) || action==Action::CheckpointEnd)imuAcquisition.endQuiet();
  return true;
}

// A cancelled standby re-applies M5's measurement configuration and the FIFO.
// If that fails the IMU task keeps running on an unconfigured sensor, so the
// task existing is not proof of tilt data: retry the restore until it works.
static void noteMotionRestoreFailure(){motionRestoreNeeded=true;++motionRestoreFailures;lastMotionInit=millis();}
LOOP_HELPER static void retryMotion(uint32_t now,const Snapshot &s) {
  if(motionPending || uint32_t(now-lastMotionInit)<MOTION_INIT_RETRY_MS ||
     (s.phase!=AnalogTachometer::Phase::Ready && s.phase!=AnalogTachometer::Phase::Paused))return;
  if(!imuAcquisition.running()){startMotion();dirty=true;return;}
  if(!motionRestoreNeeded || !imuAcquisition.lock())return;
  lastMotionInit=now;
  const bool restored=shakeWake.restore();imuAcquisition.unlock();
  if(restored)motionRestoreNeeded=false;else ++motionRestoreFailures;
  Serial.printf("IMU_RESTORE_RETRY ok=%d failures=%lu\n",restored,(unsigned long)motionRestoreFailures);dirty=true;
}

static uint8_t backlightValue(){return (unsigned(brightnessPercent)*255+50)/100;}
// During a pull the preview can be deferred. Sensor coordinates must follow
// the LCD orientation that was actually applied, rather than an unseen draft.
static bool visibleDisplayFlipped(){return DisplayOrientation::flipForRotation(M5.Display.getRotation());}
static Appearance::Theme visibleTheme(){return controls.page==Controls::Page::Edit && controls.setting==5?Appearance::Theme(controls.draft):appearance.theme;}
// The colors on screen: the Theme editor's draft while it is open. A custom
// theme that is missing or invalid shows the default.
static Palette::Colors ui(){return themeLibrary.colors(visibleTheme());}
static void cancelSettingEdit();
static void beginWipe();
static void cancelWipe();
static bool saveWakeNavigation(){return prefs.putUInt("wake_nav",Controls::encodeWake(controls,uint8_t(tournamentView)))==sizeof(uint32_t);}
static void syncNavigation() {
  tournamentMode=controls.page==Controls::Page::Tournament;
  historyPage=controls.page!=Controls::Page::Main && !tournamentMode;
  if(controls.page==Controls::Page::History)historyView=PracticeUI::View(controls.history);
  else if(controls.page==Controls::Page::Battery)historyView=PracticeUI::View::Battery;
  else if(controls.page==Controls::Page::Settings || controls.page==Controls::Page::Edit || controls.page==Controls::Page::Wipe ||
          controls.page==Controls::Page::About)historyView=PracticeUI::View::Settings;
  dirty=true;
}
static int64_t wallUs(){timeval t;gettimeofday(&t,nullptr);return int64_t(t.tv_sec)*1000000+t.tv_usec;}
static uint8_t powerFlags(){return (battery.charging?PowerDiagnostics::Charging:0)
  | (battery.chargeKnown?PowerDiagnostics::ChargeKnown:0) | (powerConfigValid && (powerConfig&0x10)?PowerDiagnostics::Led:0)
  | (extPower?PowerDiagnostics::Boost:0) | (tournamentMode?PowerDiagnostics::Tournament:0) | PowerDiagnostics::SensorRail;}
static void powerRecord(uint8_t event,uint8_t wake=0){PowerDiagnostics::append(powerLog,event,battery.voltageOk?battery.millivolts:0,
  powerFlags(),M5.Display.getBrightness(),ESP.getCpuFreqMHz(),wake);powerLogDirty=true;}
static bool savePowerLog(){
  // Bound retries after an NVS failure; repeated checkpoints keep the detector
  // in Settling and prevent subsequent pulls from being measured.
  lastPowerSaveTry=millis();
  if(!powerLogReady)return false;powerLog.checksum=PowerDiagnostics::hash(powerLog);
  const bool first=powerMirror==HistoryLog::NOT_MIRRORED;
  const bool ok=powerPrefs.putBytes("log",&powerLog,sizeof(powerLog))==sizeof(powerLog);
  if(ok){powerLogDirty=false;powerMirror=powerLog.checksum;}
  // NVS's first copy, logged at once (history_log.h): the log's record said NVS held none.
  if(ok && first && powerMirror!=HistoryLog::NOT_MIRRORED && historyLog.isOpen())historyLog.savePower(powerLog,powerMirror);
  return ok;
}
LOOP_HELPER static void exportPowerLog(){
  Serial.printf("POWER_LOG schema=1 boots=%lu power_button_wakes=%lu shake_wakes=%lu other_wakes=%lu sleeps=%lu awake_s=%llu known_sleep_s=%llu unknown_sleep_intervals=%lu charging_awake_s=%llu led_awake_s=%llu boost_awake_s=%llu display_awake_s=%llu records=%lu storage_ready=%d unsaved=%d current_ma=unavailable\n",
    (unsigned long)powerLog.boots,(unsigned long)powerLog.powerButtonWakes,(unsigned long)powerLog.shakeWakes,
    (unsigned long)powerLog.otherWakes,(unsigned long)powerLog.sleeps,powerLog.awakeMs/1000,powerLog.sleepMs/1000,(unsigned long)powerLog.unknownSleepIntervals,
    powerLog.chargingMs/1000,powerLog.ledMs/1000,powerLog.boostMs/1000,powerLog.displayMs/1000,
    (unsigned long)powerLog.count,powerLogReady,powerLogDirty);
  for(unsigned i=0;i<powerLog.count;++i){const auto &r=powerLog.records[(powerLog.next+PowerDiagnostics::CAPACITY-powerLog.count+i)%PowerDiagnostics::CAPACITY];
    Serial.printf("POWER_RECORD tracked_s=%llu boot=%lu event=%u battery_mv=%u flags=0x%02x backlight=%u cpu_mhz=%u wake=%u\n",
      r.elapsedSeconds,(unsigned long)r.boot,r.event,r.batteryMv,r.flags,r.brightness,r.cpuMhz,r.wake);}
}
LOOP_HELPER static void tickPowerLog(uint32_t now,const Snapshot &s){
  PowerDiagnostics::account(powerLog,now-powerLogTick,powerFlags(),M5.Display.getBrightness());powerLogTick=now;
  if(now-lastPowerSample>=60000){lastPowerSample=now;powerRecord(PowerDiagnostics::Sample);}
  // A resting owner already holds its checkpoint. Keep optional diagnostics
  // in RAM until motion resumes it or final shutdown flushes the log.
  if(!s.resting && powerLogReady && powerLogDirty && now-lastPowerSaveTry>=300000 &&
    HistoryCheckpoint::practiceIdle(now,lastAcceptedAt,
      HistoryCheckpoint::automaticQuietMs(now,imuStill,now-lastPowerSaveTry-300000,HISTORY_COALESCE_MS),
      motionPending,launchFeedback.protects(now),s.phase)){
    // Record the attempt first: a vetoed checkpoint must not repeat the IMU
    // quiet wait on every UI tick. The dirty log stays pending.
    lastPowerSaveTry=now;
    if(historyLog.isOpen()) {
      // To the log, beside history: no checkpoint (sleep and power-off write NVS).
      powerLog.checksum=PowerDiagnostics::hash(powerLog);
#if LAUNCHLAB_HIL
      if(Hil::nvsWrite("log",sizeof(powerLog)))return;
#endif
      if(historyLog.savePower(powerLog,powerMirror))powerLogDirty=false;else Serial.println("POWER_LOG_NOTICE log_save_failed");
      return;
    }
    if(!acquisition.request(Action::IdleCheckpointBegin,s.launches))return;
    if(!savePowerLog())Serial.println("POWER_LOG_NOTICE checkpoint_failed");acquisition.request(Action::CheckpointEnd);
  }
}


static const char *tournamentViewName() {
  switch(tournamentView) {
    case TournamentView::RecordingOnly:return "recording_only";
    default:return "rpm";
  }
}

// Internal RAM headroom for task stacks, drivers and the UI canvas. The
// minimum is the low-water mark since boot, so it covers backup and restore.
LOOP_HELPER static void heapStatus() {
  constexpr uint32_t INTERNAL=MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT;
  const void *canvas=screenReady?screen.getBuffer():nullptr;
  // DMA-capable internal RAM: the ADC's continuous driver, the speaker's I2S
  // ring and USB need it; a build once boot-looped when the ADC found none.
  constexpr uint32_t DMA=MALLOC_CAP_DMA|MALLOC_CAP_INTERNAL;
  Serial.printf("HEAP_STATUS internal_free=%u internal_largest=%u internal_min_free=%u dma_free=%u dma_largest=%u dma_min_free=%u psram_free=%u psram_largest=%u canvas=%s canvas_bytes=%u\n",
    unsigned(heap_caps_get_free_size(INTERNAL)),unsigned(heap_caps_get_largest_free_block(INTERNAL)),
    unsigned(heap_caps_get_minimum_free_size(INTERNAL)),unsigned(heap_caps_get_free_size(DMA)),
    unsigned(heap_caps_get_largest_free_block(DMA)),unsigned(heap_caps_get_minimum_free_size(DMA)),
    unsigned(heap_caps_get_free_size(MALLOC_CAP_SPIRAM)),unsigned(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM)),
    !canvas?"none":esp_ptr_internal(canvas)?"internal":"psram",unsigned(screenReady?screen.bufferLength():0));
}

// NVS entries; a history save needs one rewrite's worth free, and a negative
// headroom means the next history save would fail for lack of space.
static bool nvsAvailable(unsigned &available){
  nvs_stats_t stats{};if(nvs_get_stats(nullptr,&stats)!=ESP_OK)return false;
  available=unsigned(stats.available_entries);return true;
}

// The start floor while a sound plays (start_mark_reference.h, 0.20.1): this
// unit's recent confirmed pulls' weakest start marks, for its sensor profile.
static StartMarkReference::Reference startMarks;
static bool startMarksDirty=false;
static constexpr const char *START_MARKS_KEY="start_marks";
static void loadStartMarks() {
  StartMarkReference::Image image;const size_t n=prefs.getBytesLength(START_MARKS_KEY);
  if(n!=StartMarkReference::IMAGE_BYTES || prefs.getBytes(START_MARKS_KEY,image,n)!=n ||
     !startMarks.decode(image,unsigned(n)) || startMarks.profile!=uint8_t(sensorProfile))startMarks.clear(uint8_t(sensorProfile));
}
// A confirmed pull's weakest start mark joins the reference of its profile.
static void noteStartMark(const Snapshot &e) {
  if(!e.valid || e.startMark<=0)return;
  if(startMarks.profile!=uint8_t(e.sensorProfile))startMarks.clear(uint8_t(e.sensorProfile));
  startMarks.add(e.startMark);startMarksDirty=true;
}
// Saved with the NVS mirror at sleep and power-off, never while the unit is
// in use. A first save takes NVS room, so it keeps the reserve for optional
// records; an empty reference (a new profile, after a wipe) removes the key.
static void saveStartMarks() {
  if(!startMarksDirty)return;
  if(!startMarks.count) {
    if(!prefs.isKey(START_MARKS_KEY) || prefs.remove(START_MARKS_KEY))startMarksDirty=false;
    return;
  }
  const unsigned own=NvsBudget::blobEntries(StartMarkReference::IMAGE_BYTES);
  const unsigned needed=NvsBudget::optionalNeeded(own,prefs.isKey(START_MARKS_KEY)?0:own,NvsBudget::blobEntries(PracticeHistory::IMAGE_BYTES));
  unsigned available=0;
  if(!nvsAvailable(available) || available<needed){Serial.printf("START_MARKS_NOTICE refused nvs_space available=%u needed=%u\n",available,needed);return;}
  StartMarkReference::Image image;startMarks.encode(image);
  if(prefs.putBytes(START_MARKS_KEY,image,sizeof(image))==sizeof(image))startMarksDirty=false;
  else Serial.println("START_MARKS_ERROR save_failed");
}
// Each loop pass: while any sound plays, a launch starts only on marks half
// as strong as this unit's pulls (at most 400 counts); otherwise as ever.
static void updateStartFloor() {
  static float last=-1;
  // A reference kept for another profile (a restore can change it) does not apply.
  const float minMark=StickS3SensorProfile::minMark(sensorProfile);
  const float floor=!soundPlayer.playing()?0:startMarks.profile==uint8_t(sensorProfile)?startMarks.floor(minMark):minMark;
  if(floor!=last){acquisition.setStartFloor(floor);last=floor;}
}
// Each loop pass: Min RPM, the slowest result the optical owner publishes.
// String wear check measures the string's own retractions, which are slower
// than a pull: it sees every result.
static void updateLaunchFloor() {
  static float last=-1;
  const float floor=controls.page==Controls::Page::WearCheck?0:MinRpm::rpm(minRpmSteps);
  if(floor!=last){acquisition.setLaunchFloor(floor);last=floor;}
}
LOOP_HELPER static void nvsStatus() {
  nvs_stats_t stats{};const esp_err_t error=nvs_get_stats(nullptr,&stats);
  Serial.printf("NVS_STATUS ok=%d used_entries=%u available_entries=%u total_entries=%u namespaces=%u history_save_entries=%u history_headroom=%d\n",
    error==ESP_OK,unsigned(stats.used_entries),unsigned(stats.available_entries),unsigned(stats.total_entries),
    unsigned(stats.namespace_count),NvsBudget::blobEntries(PracticeHistory::IMAGE_BYTES),
    NvsBudget::headroom(unsigned(stats.available_entries),PracticeHistory::IMAGE_BYTES));
}

#if LAUNCHLAB_HIL
static uint32_t hilStatusRuns=0;  // !feedgaps: whether a status print starved a song
#endif
// About 6 KB at USB speed, 40-62 ms: longer than a song's two queued 32 ms
// blocks can cover, so it feeds the song between groups of lines (0.20.7,
// HIL !feedgaps; a Mic RPM session's lines made it underrun).
LOOP_HELPER static void status() {
#if LAUNCHLAB_HIL
  ++hilStatusRuns;
#endif
  BleLink::status();
  BattleFeed::status();
  RadioCalibration::status();
  Serial.printf("MOTION_RING psram=%d capture_max_us=%lu sizeof=%u\n",imuAcquisition.ringInPsram(),(unsigned long)imuAcquisition.maxCaptureUs,unsigned(sizeof(LaunchMotion::Ring)));
  const Snapshot s=acquisition.snapshot();
  // Least free stack the loop task has had since boot; 0.11.0 overflowed its 8 KB.
  Serial.printf("STACK loop_min_free_bytes=%u\n",unsigned(uxTaskGetStackHighWaterMark(nullptr)));
  Serial.printf("STATUS v=%s board=StickS3 board_id=%d gpio=%u adc_ready=%d suspended=%d ext5v=%d width=%d height=%d rotation=%u samples=%llu delivered_sps=%.0f mean=%.1f min=%lu max=%lu last=%lu overflow_events=%lu read_errors=%lu adc_error=%s\n",
    VERSION,int(M5.getBoard()),s.pin,s.ready,s.suspended,extPower,M5.Display.width(),M5.Display.height(),
    unsigned(M5.Display.getRotation()),
    (unsigned long long)s.samples,s.rate,s.mean,(unsigned long)s.minimum,(unsigned long)s.maximum,
    (unsigned long)s.last,(unsigned long)s.overflows,(unsigned long)s.readErrors,esp_err_to_name(s.error));
  Serial.printf("RPM_STATUS state=%s valid=%d peak_rpm=%.1f live_peak=%.1f launches=%lu edges=%lu weak_rejected=%lu slow_rejected=%lu noise=%.1f amplitude=%.1f rearm_ms=%lu candidate_rpm=%.1f contrast=%.1f hysteresis=%.1f shape_rejected=%lu inconsistent=%lu rearm_extensions=%lu detector_us=%llu recorder_s=%lu min_mark=%.0f edge_fraction=%.2f start_floor=%.0f start_mark=%.0f sound_held=%lu ref_pulls=%u ref_median=%.0f min_rpm=%.0f below_min=%lu\n",
    s.stateName(),s.valid,s.resultRpm,s.peakRpm,(unsigned long)s.launches,(unsigned long)s.edges,
    (unsigned long)s.weak,(unsigned long)s.slow,s.noise,s.amplitude,(unsigned long)s.rearmMs,
    s.candidateRpm,s.contrast,s.hysteresis,(unsigned long)s.shape,(unsigned long)s.inconsistent,
    (unsigned long)s.rearmExtensions,(unsigned long long)s.detectorUs,
    acquisition.storage()?60ul:0ul,StickS3SensorProfile::minMark(s.sensorProfile),StickS3SensorProfile::EDGE_SWING_FRACTION,
    s.startFloor,s.startMark,(unsigned long)s.soundHeld,unsigned(startMarks.count),startMarks.median(),s.minRpm,(unsigned long)s.belowMin);
  soundPlayer.feedSong();
  Serial.printf("SENSOR_PROFILE_STATUS selected=%s min_mark=%.0f saved_setting=%s\n",
    StickS3SensorProfile::name(s.sensorProfile),StickS3SensorProfile::minMark(s.sensorProfile),StickS3SensorProfile::name(sensorProfile));
  Serial.printf("RPM_ESTIMATORS selected=%s units=rpm three_turn_peak_rpm=%.1f single_turn_peak_rpm=%.1f confirmation_turns=3 max_rpm=30000 single_updates=%lu single_rejected=%lu\n",
    RpmEstimator::name(s.estimator),s.sustainedPeakRpm,s.singlePeakRpm,
    (unsigned long)s.singlePeakUpdates,(unsigned long)s.singlePeakRejected);
  Serial.printf("SETTINGS_SAVE_STATUS pending=0x%03lx failed=%d saves=%lu errors=%lu refusals=%lu\n",(unsigned long)settingsSave.pending(),
    settingsSave.failed(),(unsigned long)settingsSave.saves(),(unsigned long)settingsSave.errors(),(unsigned long)settingsSave.refusals());
  soundPlayer.feedSong();
  Serial.printf("TOURNAMENT_STATUS enabled=%d display=%s persistent=wake\n",tournamentMode,tournamentViewName());
  Serial.printf("MILESTONE_STATUS mode=%s rows=%u revision=%lu store=%s\n",Milestones::name(milestones.mode()),milestones.count(),
    (unsigned long)milestones.revision,milestoneStoreName());
  soundPlayer.status(appearance.sound);
  // Not while the speaker is powered (the mic is off then): this pass also
  // feeds a song, with 64 ms queued, and the mic's lines (up to 8 spins'
  // logs) took a status print past it, so songs underran after a Mic RPM
  // session (0.20.7, HIL !feedgaps). Its counters wait for the next status.
  if(!soundPlayer.powered())micListener.status();
  soundPlayer.feedSong();
  Serial.printf("SOUND_SYNC present_lag_us=%lu output_us=%lu clock_shift_ms=%ld skipped_samples=%lu\n",(unsigned long)presentLagUs,
    (unsigned long)soundPlayer.outputUs(),(long)soundShiftMs,(unsigned long)soundSkipped);
  Serial.printf("UI_STATUS page=%u menu=%u history=%u setting=%u draft=%u battery_icon=%d corner_fill=%u corner_bolt=%d recording=%s\n",
    unsigned(controls.page),controls.menu,controls.history,controls.setting,controls.draft,batteryIcon,unsigned(drawnCornerBattery.fill),
    drawnCornerBattery.tone==ControlsUI::CornerBattery::Charging,
    s.resting?"idle_paused":LAUNCHLAB_MOTION_ADC_GATE?"motion_gated":"always");
  soundPlayer.feedSong();
  Serial.printf("PERF acquisition_core=0 ui_core=%d processing_pct=%.2f max_batch_us=%lu frame_budget_us=%lu max_read_gap_us=%lu stack_free=%lu invalid_frames=%lu lost_events=%lu adc_stalls=%lu max_draw_us=%lu max_effect_us=%lu ui_stalls=%lu stress=%d heap_free=%lu psram_free=%lu usb_drain_timeouts=%lu usb_rejected_commands=%lu frames=%lu whole_frames=%lu unchanged_frames=%lu pushed_rows=%lu row_hashes=%d adc_retimes=%lu\n",
    xPortGetCoreID(),s.processingPercent,(unsigned long)s.maxBatchUs,
    (unsigned long)(uint64_t(StickS3Acquisition::FRAME_BYTES/SOC_ADC_DIGI_RESULT_BYTES)*1000000/StickS3Acquisition::SAMPLE_HZ),(unsigned long)s.maxReadGapUs,
    (unsigned long)s.stackFree,(unsigned long)s.invalidFrames,(unsigned long)s.lostEvents,(unsigned long)s.stalls,
    (unsigned long)maxDrawUs,(unsigned long)maxEffectUs,(unsigned long)uiStalls,stress,
    (unsigned long)ESP.getFreeHeap(),(unsigned long)ESP.getFreePsram(),(unsigned long)UsbTx::drainTimeouts,(unsigned long)usbCommands.rejected,
    (unsigned long)frameRows.frames(),(unsigned long)frameRows.wholeFrames(),(unsigned long)frameRows.unchanged(),
    (unsigned long)frameRows.rows(),frameRows.ready(),(unsigned long)s.retimes);
  heapStatus();nvsStatus();
  const auto tilt=level.reading(millis());const float *acc=level.lastAccel();
  soundPlayer.feedSong();
  Serial.printf("LEVEL_STATUS imu_ready=%d imu_type=%d state=%s degrees=%.2f accel_g=%.3f,%.3f,%.3f samples=%lu rejected=%lu max_poll_us=%lu draw_buffer=%d\n",
    M5.Imu.isEnabled(),int(M5.Imu.getType()),tilt.name(),tilt.degrees,acc[0],acc[1],acc[2],
    (unsigned long)level.samples(),(unsigned long)level.rejected(),(unsigned long)maxImuPollUs,screenReady);
  const auto *session=practice.session();
  const uint32_t now=millis();
  Serial.printf("HISTORY_STATUS records=%u sessions=%u session=%lu session_pulls=%lu session_avg=%.1f generation=%lu pending=%d store_ready=%d save_errors=%lu saves=%lu max_save_us=%lu page=%s view=%u offset=%u demo=%d ui_stack_free=%lu\n",
    practice.size(),practice.sessions(),session?(unsigned long)session->number:0ul,
    session?(unsigned long)session->count:0ul,session?session->mean():0,
    (unsigned long)practice.generation(),historyUnsaved(),practiceStore.ready() || historyLog.isOpen(),
    (unsigned long)saveErrors,(unsigned long)saveCount,(unsigned long)maxSaveUs,
    diagnostics?"signal":historyPage?"history":"live",unsigned(historyView),historyOffset,demo,
    (unsigned long)uxTaskGetStackHighWaterMark(nullptr));
  const bool pendingHistory=historyUnsaved();
  const uint32_t pendingMs=pendingHistory && historyPendingSince?now-historyPendingSince:0;
  const uint32_t quietMs=now-lastAcceptedAt;
  const uint32_t coalesceMs=HistoryCheckpoint::automaticQuietMs(now,imuStill,pendingMs,HISTORY_COALESCE_MS);
  const uint32_t flushDue=quietMs>=coalesceMs?0u:coalesceMs-quietMs;
  const uint32_t retryRemaining=saveError && now-lastSaveTry<HISTORY_SAVE_RETRY_MS?HISTORY_SAVE_RETRY_MS-(now-lastSaveTry):0;
  soundPlayer.feedSong();
  Serial.printf("HISTORY_PENDING unsaved_pulls=%lu pending_ms=%lu flush_due_ms=%lu coalesce_ms=%lu max_pending_ms=%lu retry_remaining_ms=%lu\n",
    (unsigned long)(historyLog.isOpen()?practice.generation()-loggedHistory:practiceStore.pendingCount(practice)),(unsigned long)pendingMs,
    (unsigned long)(pendingHistory?flushDue:0),(unsigned long)coalesceMs,(unsigned long)HistoryCheckpoint::MAX_PENDING_MS,(unsigned long)retryRemaining);
  Serial.printf("POWER_STATUS auto_off_s=%lu shake_wake=%d wake=%s sleep=%s sensor_rail=L2_off_in_battery_standby idle_s=%lu off_in_s=%lu battery_valid=%d battery_mv=%u battery_pct=%d charging=%s max_battery_poll_us=%lu auto_off_inhibited=%d\n",
    (unsigned long)(inactivity.timeout()/1000),shakeToWake,shakeToWake?"shake":"side_key",shakeToWake?"imu_only":"power_off",(unsigned long)(inactivity.elapsed(now)/1000),(unsigned long)((inactivity.remaining(now)+999)/1000),
    battery.valid(now),unsigned(battery.millivolts),battery.valid(now)?battery.percent:-1,
    battery.chargeName(),(unsigned long)maxBatteryPollUs,usbAwake.inhibited(now));
  soundPlayer.feedSong();
  Serial.printf("USB_POWER host_sof=%d host_seen=%d auto_off_inhibited=%d reason=%s power_known=%d last_power_read_ok=%d source=0x%02x host_poll_ms=%lu power_poll_ms=%lu\n",
    usbAwake.sof(),usbAwake.remembered(),usbAwake.inhibited(now),usbAwake.reason(now),usbAwake.powerKnown(now),usbAwake.lastPowerReadOk(),usbAwake.powerBits(),
    (unsigned long)UsbHostAwake::HOST_POLL_MS,(unsigned long)UsbHostAwake::POWER_POLL_MS);
  Serial.printf("POWER_DETAIL uptime_s=%lu cpu_mhz=%lu backlight=%u pm1_cfg_valid=%d pm1_cfg=0x%02x led_enabled=%d current_measurement=unavailable\n",
    (unsigned long)(now/1000),(unsigned long)ESP.getCpuFreqMHz(),unsigned(M5.Display.getBrightness()),
    powerConfigValid,powerConfig,powerConfigValid?int(bool(powerConfig&0x10)):-1);
  soundPlayer.feedSong();
  Serial.printf("POWER_KEY single_click=%s pending=%d clear_failures=%lu\n",
    powerKey().configured()?"firmware_power_off":"pm1_reset",powerKeyRequested,(unsigned long)powerKey().clearFailures());
  Serial.printf("CPU_PM requested=%d enabled=%d min_mhz=%u max_mhz=%d light_sleep=0 error=%s\n",
    LAUNCHLAB_CPU_PM,CpuPower::active(),CpuPower::active()?40u:80u,CpuPower::active()?CpuPower::maxMhz():80,CpuPower::errorName());
  const auto &savers=PowerSavers::settings;
  Serial.printf("POWER_POLICY effective_timeout_s=%lu unused_shake=%d unused_wakes=%u dim_after_ms=%lu dim_ignores_motion=%d dim_backlight=%u rest_after_ms=%lu changed_rows_only=%d imu_poll_ms=%lu level_poll_ms=%lu ui_poll_ms=%lu battery_estimate_mv=%u battery_estimate=voltage_median5\n",
    (unsigned long)(inactivity.activeTimeout()/1000),inactivity.unusedShake(),unsigned(unusedWakes),
    (unsigned long)savers.dimMs,savers.dimIgnoresMotion,unsigned(savers.dimBacklight),(unsigned long)savers.restMs,
    savers.changedRowsOnly,(unsigned long)imuAcquisition.pollMs(),(unsigned long)IdlePowerPolicy::LEVEL_POLL_MS,
    (unsigned long)IdlePowerPolicy::UI_POLL_MS,unsigned(battery.estimateMillivolts));
  // PM1 statistics are written under the shared gate. Do not block status
  // waiting on the IMU owner or sample them concurrently with a PM1 operation.
  if(imuAcquisition.lock()) {
    const auto pm=pm1Idle().stats();imuAcquisition.unlock();
    Serial.printf("PM1_IDLE_STATUS configured=%d seconds=%u fallback_verified=%d wake_retries=%lu recovered_reads=%lu read_failures=%lu write_failures=%lu operation_failures=%lu config_failures=%lu\n",
      pm.configured,unsigned(pm.seconds),pm.fallbackVerified,(unsigned long)pm.wakeRetries,
      (unsigned long)pm.recoveredReads,(unsigned long)pm.readFailures,(unsigned long)pm.writeFailures,
      (unsigned long)pm.operationFailures,(unsigned long)pm.configFailures);
  }
  const auto imu=imuAcquisition.snapshot();
  const auto &activity=imu.activity;
  soundPlayer.feedSong();
  Serial.printf("SENSOR_IDLE enabled=%d resting=%d sensor_power=on_shared_rail adc_pause_after_ms=%lu pauses=%lu resumes=%lu experimental=1\n",
    LAUNCHLAB_MOTION_ADC_GATE,s.resting,(unsigned long)SensorIdle::IDLE_MS,
    (unsigned long)sensorIdle.pauses(),(unsigned long)sensorIdle.resumes());
  Serial.printf("MOTION_ACTIVITY valid=%d fresh=%d moving=%d gyro_dps=%.3f accel_change_g=%.4f gyro_on_dps=%.2f accel_on_g=%.3f confirm_ms=%lu idle_ms=%lu unused_shake=%d off_in_s=%lu\n",
    activity.valid,activity.fresh(esp_timer_get_time()),activity.moving,activity.gyroDps,activity.accelChangeG,
    MotionActivity::GYRO_ON,MotionActivity::ACCEL_ON,(unsigned long)(MotionActivity::CONFIRM_US/1000),
    (unsigned long)inactivity.elapsed(now),inactivity.unusedShake(),(unsigned long)((inactivity.remaining(now)+999)/1000));
  soundPlayer.feedSong();
  Serial.printf("MOUNT_STATUS selected=%s imu_frame=%s accel_gyro_frame=launcher raw_imu_frame=device display_flip=%d\n",
    MountOrientation::label(mountMode),MountOrientation::label(imu.mount),displayFlipped);
  Serial.printf("IMU_RESTORE_STATUS needed=%d failures=%lu capture_retries=%lu\n",motionRestoreNeeded,(unsigned long)motionRestoreFailures,(unsigned long)motionCaptureRetries);
  Serial.printf("IMU_STARTUP_STATUS attempts=%lu last_try_ms=%lu last_paired=%d last_success=%d retry_ms=%lu\n",
    (unsigned long)motionInitAttempts,(unsigned long)lastMotionInit,motionInitPaired,motionInitSuccess,
    (unsigned long)MOTION_INIT_RETRY_MS);
  soundPlayer.feedSong();
  Serial.printf("MOTION_STATUS imu_core=0 imu_task=%d paired_samples=%lu accel_samples=%lu max_gap_us=%lu gaps=%lu max_poll_us=%lu stack_free=%lu gate_misses=%lu late_polls=%lu missed_polls=%lu latest=%lu quality=%s pending=%d ref=%lu ref_rpm=%.1f ref_store_ready=%d ref_load_error=%d dropped=%lu demo=%d feedback=%d\n",
    imuAcquisition.running(),(unsigned long)imu.pairedSamples,(unsigned long)imu.accelSamples,
    (unsigned long)imu.maxGapUs,(unsigned long)imu.gaps,(unsigned long)imu.maxPollUs,(unsigned long)imu.stackFree,(unsigned long)imu.gateMisses,(unsigned long)imu.latePolls,(unsigned long)imu.missedPolls,
    (unsigned long)latestMotion.number,LaunchMotion::name(latestMotion.quality),motionPending,
    (unsigned long)referenceMotion.number,referenceMotion.rpm,motionStore.ready(),referenceError,
    (unsigned long)motionDrops,motionDemo,launchFeedback.shown());
  Serial.printf("ORIENTATION_STATUS algorithm=VQF6D position=disabled absolute_heading=disabled ready=%d rest=%d updates=%lu resets=%lu max_fusion_us=%lu bias_dps=%.4f,%.4f,%.4f bias_sigma_dps=%.4f\n",
    imu.orientationReady,imu.rest,(unsigned long)imu.fusionSamples,(unsigned long)imu.fusionResets,
    (unsigned long)imu.maxFusionUs,imu.bias[0],imu.bias[1],imu.bias[2],imu.biasSigma);
  soundPlayer.feedSong();
  Serial.printf("I2C_RECOVERY bus=internal result=%s pulses=%u sda_was=%d scl_was=%d\n",I2cBusRecovery::name(i2cRecovery),i2cRecoveryPulses,i2cSdaWas,i2cSclWas);
  Serial.printf("IMU_FIFO_STATUS reads=%lu errors=%lu skipped_frames=%lu anchors=%lu max_bytes=%lu period_us=%.1f gyro_samples=%lu accel_samples=%lu flash_quiet_polls=%lu length_errors=%lu data_errors=%lu parse_errors=%lu oversize=%lu overflows=%lu stalls=%lu last_stall_us=%lu last_stall_ms=%lu last_error_bytes=%lu last_error_offset=%lu last_error_ms=%lu last_quiet_ms=%lu..%lu\n",
    (unsigned long)imu.fifoReads,(unsigned long)imu.fifoErrors,(unsigned long)imu.fifoSkipped,(unsigned long)imu.fifoAnchors,
    (unsigned long)imu.fifoMaxBytes,imu.fifoPeriodUs,(unsigned long)imu.pairedSamples,(unsigned long)imu.accelSamples,(unsigned long)imu.quietPolls,
    (unsigned long)imu.fifoLengthErrors,(unsigned long)imu.fifoDataErrors,(unsigned long)imu.fifoParseErrors,(unsigned long)imu.fifoOversize,(unsigned long)imu.fifoOverflows,
    (unsigned long)imu.fifoStalls,(unsigned long)imu.lastStallUs,(unsigned long)imu.lastStallMs,
    (unsigned long)imu.lastErrorBytes,(unsigned long)imu.lastErrorOffset,(unsigned long)imu.lastErrorMs,
    (unsigned long)imuAcquisition.quietBeganMs(),(unsigned long)imuAcquisition.quietEndedMs());
  soundPlayer.feedSong();
  Serial.printf("MOTION_CLIP accel_range_g=%.0f gyro_range_dps=%.0f samples=%lu max_run=%lu last_run=%lu last_ms=%lu last_axes=0x%02lx\n",
    accelRange().fullScaleG(),StickS3AccelRange::GYRO_FULL_SCALE_DPS,(unsigned long)imu.clipSamples,(unsigned long)imu.maxClipRun,
    (unsigned long)imu.lastClipRun,(unsigned long)imu.lastClipMs,(unsigned long)imu.lastClipAxes);
  for(unsigned i=imu.gapNext>StickS3MotionAcquisition::Snapshot::GAPS?imu.gapNext-StickS3MotionAcquisition::Snapshot::GAPS:0;i<imu.gapNext;++i) {
    const auto &g=imu.gapLog[i%StickS3MotionAcquisition::Snapshot::GAPS];
    Serial.printf("MOTION_GAP n=%u at_ms=%lu gap_us=%lu polls=%lu empty_polls=%lu max_period_us=%lu max_lock_us=%lu max_poll_us=%lu max_ring_us=%lu\n",
      i+1,(unsigned long)g.atMs,(unsigned long)g.gapUs,(unsigned long)g.polls,(unsigned long)g.emptyPolls,
      (unsigned long)g.periodUs,(unsigned long)g.lockUs,(unsigned long)g.pollUs,(unsigned long)g.ringUs);
  }
}

// No serial reader is needed: isPlugged() uses IDF's SOF monitor, not CDC I/O.
LOOP_HELPER static void pollUsbAwake(uint32_t now,const Snapshot &s,bool force=false) {
  if(!force && !usbAwake.hostPollDue(now))return;
  usbAwake.sampleHost(now,HWCDC::isPlugged());
  if(usbAwake.powerPollDue(now) && s.phase!=AnalogTachometer::Phase::Launch) {
    uint8_t source=0;bool ok=false;
    if(imuAcquisition.lock()) {
      // Checked PWR_SRC read: wrappers that return zero also hide I2C errors.
      ok=pm1Idle().read(0x04,&source,1);
      imuAcquisition.unlock();
    }
    usbAwake.samplePower(now,ok,source);
  }
  const bool inhibited=usbAwake.inhibited(now);
  // A confirmed computer connection establishes use, even if the initial
  // optimistic SOF already inhibited shutdown on the preceding poll.
  bool hostConfirmed=inhibited && usbAwake.remembered() && usbAwake.powerKnown(now);
#if LAUNCHLAB_HIL
  // The dry run's host is the rig, not a person: `!shakewake` stays an unused wake.
  if(Hil::sleepDry.load())hostConfirmed=false;
#endif
  if(hostConfirmed &&
     (usbAwake.powerBits()&UsbHostAwake::VIN_MASK) && inactivity.unusedShake())inactivity.touch(now);
  if(inhibited!=usbAutoOffInhibited) {
    usbAutoOffInhibited=inhibited;
    // A disconnect starts a full ordinary battery timeout, not an overdue
    // timer accumulated during a long computer session. Touch only on edges.
    // A transient, unconfirmed boot SOF must not turn an accidental shake
    // wake into a full practice timeout. Confirmed detach was promoted above.
    if(!inactivity.unusedShake())inactivity.touch(now);
    lastShutdownTry=0;
    Serial.printf("USB_AUTO_OFF inhibited=%d reason=%s sof=%d host_seen=%d power_known=%d source=0x%02x\n",
      inhibited,usbAwake.reason(now),usbAwake.sof(),usbAwake.remembered(),usbAwake.powerKnown(now),usbAwake.powerBits());
  }
}

// The corner battery (Battery icon) on the Menu and Settings pages
// (Controls::showsCornerBattery), never over the tournament or the
// diagnostics. Editing the row previews the choice. The live Main page shows
// it only while the unit charges (0.20.9), not over a recap or the demo.
static ControlsUI::CornerBattery cornerBattery(uint32_t now) {
  const bool editing=controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::BatteryIcon);
  const bool chargingMain=Controls::showsChargingBattery(controls.page) && battery.charging && !historyPage && !launchFeedback.shown() &&
    !BattleFeed::cardShown();
  const bool shown=(editing?bool(controls.draft):batteryIcon) && !tournamentMode && !diagnostics &&
    (Controls::showsCornerBattery(controls.page) || chargingMain);
  return shown?ControlsUI::cornerBattery(battery.valid(now),battery.percent,battery.charging):ControlsUI::CornerBattery{};
}

LOOP_HELPER static void pollBattery(uint32_t now,const Snapshot &s) {
  if(s.phase==AnalogTachometer::Phase::Launch || (batteryPolled && now-lastBatteryPoll<5000))return;
  if(!imuAcquisition.lock())return;
  batteryPolled=true;lastBatteryPoll=now;
  const int64_t started=esp_timer_get_time();
  uint16_t mv=0;uint8_t bits=0;
  bool voltageRead=false,chargeRead=false;
  if(pm1Idle().ensureAwake()) {
    voltageRead=M5.Power.M5pm1.getBatteryVoltage(&mv);
    chargeRead=M5.Power.M5pm1.getGPIOInputBits(&bits);
  }
  powerConfigValid=pm1Idle().read(0x06,&powerConfig,1);
  imuAcquisition.unlock();
  battery.update(mv,voltageRead,chargeRead,bits,now);
  maxBatteryPollUs=std::max(maxBatteryPollUs,uint32_t(esp_timer_get_time()-started));
  if((historyPage && historyView==PracticeUI::View::Battery) || cornerBattery(now)!=drawnCornerBattery)dirty=true;
}

// The pairing number and a wipe always show; so does anything being diagnosed.
static bool displayDark(uint32_t now) {
  if(!darkDisplay.dark(now) || wipeBlocked || diagnostics || stress)return false;
  uint32_t number=0;bool automatic=false;
  return !BleLink::comparison(number,automatic);
}

// A press that only wakes the screen does nothing else: its click comes at release, which the latch ignores.
static void wakeDisplayOnPress(bool pressed) {
  if(!pressed || !darkDisplay.press(millis()))return;
  gestureA.consumed=gestureB.consumed=true;dirty=true;
}

static void tickDarkDisplay(uint32_t now) {
  if(darkDisplay.requested && !BleLink::connected()){darkDisplay.set(false);dirty=true;}
  darkDisplay.tick(now);
}

LOOP_HELPER static void tickDisplayPower(uint32_t now,const Snapshot &s) {
  // Preserve the electrical conditions during a measured pull. A pull while
  // dimmed restores its feedback brightness only after measurement completes.
  if(s.phase==AnalogTachometer::Phase::Launch ||
     (s.phase==AnalogTachometer::Phase::Ready && !s.opticalIdle))return;
#if LAUNCHLAB_POWER_LAB
  // A fixed lab backlight, never dimmed; 0 puts the panel to sleep.
  if(Lab::running && Lab::knobs.backlight>=0) {
    const uint8_t target=(unsigned(Lab::knobs.backlight)*255+50)/100;
    if(M5.Display.getBrightness()==target && Lab::displayAsleep==!target)return;
    acquisition.displayBoundary(true);
    if(!target){M5.Display.setBrightness(0);M5.Display.sleep();Lab::displayAsleep=true;}
    else{if(Lab::displayAsleep){M5.Display.wakeup();frameRows.invalidate();Lab::displayAsleep=false;}M5.Display.setBrightness(target);}
    acquisition.displayBoundary(false);
    Serial.printf("LAB_DISPLAY backlight_pct=%d asleep=%d\n",Lab::knobs.backlight,Lab::displayAsleep);
    return;
  }
  if(Lab::displayAsleep){M5.Display.wakeup();frameRows.invalidate();Lab::displayAsleep=false;dirty=true;}
#endif
  const auto &savers=PowerSavers::settings;
  const uint8_t selected=controls.page==Controls::Page::Edit && controls.setting==2?
    controls.draft:brightnessPercent;
  const uint32_t idle=savers.dimIgnoresMotion?inactivity.sinceUse(now):inactivity.elapsed(now);
  const uint8_t percent=displayDark(now)?0:IdlePowerPolicy::brightness(selected,idle,usbAwake.inhibited(now),launchFeedback.shown(),savers.dimMs);
  const uint8_t target=percent && percent<selected && savers.dimBacklight?savers.dimBacklight:(unsigned(percent)*255+50)/100;
  if(M5.Display.getBrightness()==target)return;
  acquisition.displayBoundary(true);M5.Display.setBrightness(target);acquisition.displayBoundary(false);
  Serial.printf("DISPLAY_POWER selected_pct=%u actual_pct=%u backlight=%u idle_ms=%lu dimmed=%d\n",
    selected,percent,unsigned(target),(unsigned long)idle,percent<selected);
}

// Cache flash metadata once before acquisition starts; never scan flash while drawing.
static void readDeviceFlash() {
  deviceFlash={};deviceFlash.total=ESP.getFlashChipSize();
  const auto *running=esp_ota_get_running_partition();
  if(!running)return;
  deviceFlash.slot=running->size;
  const esp_partition_pos_t position{running->address,running->size};
  esp_image_metadata_t metadata={};
  if(esp_image_verify(ESP_IMAGE_VERIFY_SILENT,&position,&metadata)==ESP_OK)deviceFlash.app=metadata.image_len;
}
static void drawDevice(lgfx::LGFXBase &g,uint32_t now) {
  ControlsUI::device(g,battery.valid(now),battery.percent,battery.millivolts,battery.chargeKnown,battery.charging,deviceFlash);
}
// The unit's ID is its factory MAC, which is also its USB serial number.
static void drawAbout(lgfx::LGFXBase &g) {
  uint8_t mac[6]={};char id[18]="--";
  if(esp_efuse_mac_get_default(mac)==ESP_OK)snprintf(id,sizeof(id),"%02X:%02X:%02X:%02X:%02X:%02X",mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
  ControlsUI::about(g,id,practice.size());
}

// The applied value of each editable Settings row, in Controls::Setting order.
static uint8_t settingValue(unsigned row) {
  using S=Controls::Setting;
  switch(S(row)) {
    case S::Sleep:return inactivity.minutes();
    case S::Rpm:return uint8_t(rpmEstimator);
    case S::Brightness:return brightnessPercent;
    case S::Flip:return uint8_t(displayFlipped);
    case S::Sensor:return uint8_t(sensorProfile);
    case S::Theme:return uint8_t(themeLibrary.effective(appearance.theme));
    case S::BestEffect:return uint8_t(appearance.effect);
    case S::Celebrate:return uint8_t(milestones.mode());
    case S::Sound:return uint8_t(appearance.sound);
    case S::Mount:return uint8_t(mountMode);
    case S::ShakeWake:return uint8_t(shakeToWake);
    case S::BatteryIcon:return uint8_t(batteryIcon);
    case S::Bluetooth:return uint8_t(bluetoothOn);
    case S::MinRpm:return minRpmSteps;
    case S::WipeAll:case S::About:break;
  }
  return 0;
}
static void drawSettings(lgfx::LGFXBase &g) {
  uint8_t values[Controls::SETTING_COUNT];
  for(unsigned i=0;i<Controls::SETTING_COUNT;++i)values[i]=settingValue(i);
  ControlsUI::settings(g,controls,values);
}

LOOP_HELPER static void exportSignal() {
  if(!acquisition.storage() || !acquisition.request(Action::Suspend)) {
    Serial.println("RAW_ERROR acquisition_suspend_failed");return;
  }
  const Snapshot s=acquisition.snapshot();
  if(s.ringCount) {
    Serial.printf("FLIGHT_EXPORT samples=%lu end_detector_us=%llu state=%s launches=%lu gpio=%u display_blanking=0\n",
      (unsigned long)s.ringCount,(unsigned long long)s.detectorUs,s.stateName(),(unsigned long)s.launches,s.pin);
    opticalTransferRaw(acquisition.storage(),StickS3Acquisition::RING_SAMPLES,s.ringFirst,s.ringCount,
      int64_t(s.ringCount)*1000000/ANALOG_SAMPLE_HZ,0,0,true,ESP_OK,false);
  } else Serial.println("RAW_ERROR no_flight_record");
  if(!acquisition.request(Action::Resume))Serial.println("ADC_ERROR resume_failed");
  dirty=true;
}

// The RPM detector would measure a burst now: not in its rearm second.
static bool wearDetectorReady(const Snapshot &s) {
  return s.ready && !s.signalFault && !s.suspended && s.phase==AnalogTachometer::Phase::Ready;
}
// Wear check's level, as the other Mounting would read the unit: held off
// level here but level there, the page suggests the other Mounting.
LOOP_HELPER static void observeWearMount(const StickS3Level::Reading &tilt) {
  const auto other=liveMount==MountOrientation::Mode::Sidecar?MountOrientation::Mode::Top:MountOrientation::Mode::Sidecar;
  const bool hinted=controls.wear.mountHint();
  controls.wear.observeMount(millis(),WearCheck::Tilt(tilt),WearCheck::Tilt(level.reading(millis(),
    [other](const float *in,float *out){MountOrientation::remapVector(liveMount,other,in,out);})));
  if(controls.wear.mountHint()==hinted)return;
  dirty=true;
  Serial.printf("WEAR_CHECK_MOUNT_HINT shown=%d mount=%s\n",controls.wear.mountHint(),MountOrientation::label(liveMount));
}
// A on the Wear check page starts the check over: say what pressed it.
LOOP_HELPER static void noteWearTap(const char *source) {
  if(controls.page!=Controls::Page::WearCheck)return;
  Serial.printf("WEAR_CHECK_RESET source=%s stage=%s pulls=%u\n",source,
    WearCheck::stageName(controls.wear.stage()),controls.wear.totalAccepted());
}
// Every burst or unmeasured pull on the Wear check page: accepted, completed
// or rejected retractions, the pull out (extension, never counted), the string
// let go before LET GO (early_release) and an unmeasured retraction (missed).
LOOP_HELPER static void logWearPull(WearCheck::Stage stageBefore,WearCheck::Outcome outcome,float rpm) {
  inactivity.touch(millis());
  Serial.printf("WEAR_CHECK_PULL stage=%s pull=%u/%u outcome=%s rpm=%.1f tilt_deg=%.2f\n",
    WearCheck::stageName(stageBefore),
    stageBefore<WearCheck::Stage::Complete?controls.wear.stageCount(unsigned(stageBefore)):WearCheck::PULLS_PER_STAGE,
    WearCheck::PULLS_PER_STAGE,WearCheck::outcomeName(outcome),rpm,controls.wear.lastTiltDegrees());
}

static void drawLiveLevel(lgfx::LGFXBase &view,int cx) {
  drawnLevel=StickS3Level::forDisplay(level.reading(millis()),visibleDisplayFlipped());
  ScreensUI::level(view,ui(),cx,drawnLevel);
}

// The recap's label: NEW BEST for a personal best, otherwise the milestone
// the pull reached; null when the recap celebrates nothing.
static const char *celebrationBadge() {
  static char text[24];
  if(motionDemo || !bestEffect.badge())return nullptr;
  if(bestEffect.best())return "NEW BEST";
  Milestones::milestoneText(text,sizeof(text),bestEffect.milestone());return text;
}
// The Beyblade X page's view, from the Battle Pass feed further down.
namespace BattlePassFeed {LOOP_HELPER static ControlsUI::PassView view();}
LOOP_HELPER static void draw(const Snapshot &s) {
  const int64_t started=esp_timer_get_time();
  const Palette::Colors colors=ui();
  ControlsUI::colors=colors;ControlsUI::themeLabel=[](Appearance::Theme t){return themeLibrary.label(t);};ControlsUI::milestones=&milestones;
  ControlsUI::runtime=VERSION;
  const uint32_t replayFrameElapsed=launchFeedback.replayElapsed(millis());
  const bool replayWasStarted=launchFeedback.replayStarted();
  auto &view=screenReady?static_cast<lgfx::LGFXBase &>(screen):static_cast<lgfx::LGFXBase &>(M5.Display);
  if(!screenReady){acquisition.displayBoundary(true);M5.Display.startWrite();}
  const bool cacheAnalysis=screenReady && controls.page==Controls::Page::Analysis && !analysis.replay() && !analysis.results() && !diagnostics && !tournamentMode;
  if(!cacheAnalysis || analysisCacheRotation!=M5.Display.getRotation())analysisCache.invalidate();
  analysisCacheRotation=M5.Display.getRotation();
  if(!cacheAnalysis)view.fillScreen(colors.background);
  const int cx=view.width()/2;
  view.setTextDatum(top_center);
  view.setTextColor(colors.text,colors.background);
  // The battle card on the main screen, if one is up and its rival still has a record.
  const Battle::Rival *battleRival=BattleFeed::cardShown()?battle.rival(rivals):nullptr;
  const auto battleCard=battleRival?battle.view():Battle::Session::View::None;
  if(!tournamentMode && diagnostics)
    ScreensUI::diagnosticsHeader(view,colors,newSessionAt && millis()-newSessionAt<1500,s.stateName(),s.ready && !s.signalFault);
  view.setTextColor(colors.text,colors.background);
  if(tournamentMode) {
    ScreensUI::tournament(view,colors,s.ready && !s.signalFault,tournamentView==TournamentView::RecordingOnly,s.valid,s.resultRpm);
    if(int32_t(tournamentHintUntil-millis())>0)ControlsUI::footer(view,"B View  Hold A Exit");
  } else if(diagnostics) {
    ScreensUI::diagnostics(view,s.pin,s.last,s.minimum,s.maximum,s.rate);
  } else if(historyPage) {
    if(!cacheAnalysis)view.fillScreen(colors.background);
    switch(controls.page) {
      case Controls::Page::Menu:ControlsUI::list(view,"Menu",ControlsUI::MENU,Controls::MENU_COUNT,controls.menu,Controls::MENU_GROUPS);break;
      case Controls::Page::HistoryMenu:ControlsUI::list(view,"History",ControlsUI::HISTORY,4,controls.history);break;
      case Controls::Page::Settings:drawSettings(view);break;
      case Controls::Page::Edit:ControlsUI::editor(view,controls,settingsSaveError,
        (controls.setting==1 && controls.draft!=uint8_t(rpmEstimator)) ||
        (controls.setting==4 && controls.draft!=uint8_t(sensorProfile)));
        // The previewed effect frames the value text inside its card.
        if(screenReady && controls.setting==unsigned(Controls::Setting::BestEffect) && editorEffect.badge()) {
          const int64_t effectStarted=esp_timer_get_time();effectReadUs=effectStarted;BestEffectUI::Renderer::Anchor card;
          card.top=72;card.bottom=128;card.left=8;card.right=view.width()-9;
          drawEffect(editorEffect.effect(),editorEffect.elapsed(millis()),card,colors);
          maxEffectUs=std::max(maxEffectUs,uint32_t(esp_timer_get_time()-effectStarted));
        }
        break;
      case Controls::Page::NewSession:ControlsUI::session(view,controls.startSession);break;
      case Controls::Page::Battery:drawDevice(view,millis());break;
      case Controls::Page::About:drawAbout(view);break;
      case Controls::Page::Wipe:ControlsUI::wipe(view,wipeConfirmation,millis(),wipeFailed,wipeBlocked,wipeComplete);break;
      case Controls::Page::Analysis: {
        const auto plot=analysisResults.plot(analysis);
        if(analysis.results())AnalysisResultUI::draw(view,analysis,analysisResults.details(),analysisResults.busy(),analysisResults.failed(),colors);
        else AnalysisUI::draw(view,analysis,esp_timer_get_time(),micListener.trace(),micPageState(),latestMotion,
          motionPending,visibleDisplayFlipped(),colors,latestCurve,s.stateName(),s.ready && !s.signalFault,cacheAnalysis?&analysisCache:nullptr,
          plot.fit,plot.input,plot.curve,analysisResults.busy(),analysisResults.forecast(analysis.number()).seconds,analysisCapturePending());
        break;
      }
      case Controls::Page::WearCheck: {
        const auto rawTilt=level.reading(millis());
        drawnLevel=StickS3Level::forDisplay(rawTilt,visibleDisplayFlipped());
        ControlsUI::wearCheck(view,controls.wear,WearCheck::Tilt(rawTilt),WearCheck::Tilt(drawnLevel),wearDetectorReady(s),
          liveMount==MountOrientation::Mode::Sidecar?"Sidecar mount":"Top mount",
          liveMount==MountOrientation::Mode::Sidecar?"Top install?":"Sidecar install?");
        break;
      }
      case Controls::Page::Bluetooth:ControlsUI::bluetoothPage(view,controls.bluetoothRow,bluetoothOn,BleLink::connected(),BattlePass::NAME,BleLink::bondCount());break;
      case Controls::Page::ForgetPhones:ControlsUI::forgetPhones(view,controls.forgetChosen);break;
      case Controls::Page::EnableBluetooth:ControlsUI::enableBluetooth(view,controls.enableChosen);break;
      case Controls::Page::Battles:BattleUI::battles(view,rivals,controls.battleRow,bluetoothOn,battlesOn,battleMatchTo);break;
      case Controls::Page::Rival:
        // A rival is only opened from its row; one replaced since shows the list.
        if(const Battle::Rival *r=rivals.recent(controls.rival))BattleUI::rival(view,*r);
        else BattleUI::battles(view,rivals,controls.battleRow,bluetoothOn,battlesOn,battleMatchTo);
        break;
      case Controls::Page::BeybladeX:
        // After a pull, its result as Main shows it, until it closes by itself;
        // A held stays the pass's button throughout.
        if(launchFeedback.shown()) {
          MotionUI::feedback(view,motionDemo?demoMotion:latestMotion,
            motionPending && !motionDemo,motionDemo,MotionReplay::playbackProgress(motionDemo?demoMotion:latestMotion,
              launchFeedback.position(replayFrameElapsed)),visibleDisplayFlipped(),colors,celebrationBadge(),
            motionDemo?MotionUI::demoCurve(demoMotion.rpm):latestCurve);
          ControlsUI::footer(view,"Hold A Button  B Back");
        }
        else ControlsUI::beybladeX(view,BattlePassFeed::view());
        break;
      default:PracticeUI::draw(view,demo?demoPractice:practice,historyView,historyOffset,demo,colors);break;
    }
  } else if(launchFeedback.shown()) {
    view.fillScreen(colors.background);
    MotionUI::feedback(view,motionDemo?demoMotion:latestMotion,
      motionPending && !motionDemo,motionDemo,MotionReplay::playbackProgress(motionDemo?demoMotion:latestMotion,
        launchFeedback.position(replayFrameElapsed)),visibleDisplayFlipped(),colors,celebrationBadge(),
      motionDemo?MotionUI::demoCurve(demoMotion.rpm):latestCurve);
    ControlsUI::footer(view,"A Main  B Menu");
    // Direct-draw fallback stays functional without reading the hardware LCD.
    if(screenReady && !motionDemo && !motionPending && bestEffect.badge()) {
      const int64_t effectStarted=esp_timer_get_time();effectReadUs=effectStarted;
#if LAUNCHLAB_HIL
      if(!hilFxDraw(static_cast<uint16_t *>(screen.getBuffer()),screen.width(),screen.height(),bestEffect.elapsed(millis()),colors.accent,colors.background))
#endif
      drawEffect(bestEffect.effect(),bestEffect.elapsed(millis()),BestEffectUI::Renderer::Anchor(),colors);
      maxEffectUs=std::max(maxEffectUs,uint32_t(esp_timer_get_time()-effectStarted));
#if LAUNCHLAB_HIL
      if(effectFrames.count<128 && bestEffect.moving(millis())){
        effectFrames.elapsed[effectFrames.count]=uint16_t(bestEffect.elapsed(millis()));
        effectFrames.us[effectFrames.count++]=uint16_t(std::min<int64_t>(65535,esp_timer_get_time()-effectStarted));}
#ifdef BEST_EFFECT_PROFILE
      if(effectStages.count<64 && bestEffect.moving(millis())) {
        const unsigned n=effectStages.count++;effectStages.elapsed[n]=uint16_t(bestEffect.elapsed(millis()));
        effectStages.us[n]=uint32_t(esp_timer_get_time()-effectStarted);
        std::memcpy(effectStages.cycles[n],bestEffectRenderer.stage,sizeof(effectStages.cycles[n]));
      }
#endif
#endif
    }
  } else if(battleCard==Battle::Session::View::Pick) {
    BattleUI::picker(view,colors,*battleRival,battle.pickOutcome(),battle.pickFinish());
  } else if(battleCard==Battle::Session::View::Result) {
    BattleUI::result(view,colors,*battleRival,battle.synced()?BattleUI::Told::Agreed:
      battle.beacon(millis())?BattleUI::Told::Telling:BattleUI::Told::Later);
  } else {
    const bool sessionNotice=newSessionAt && millis()-newSessionAt<1500 &&
      s.ready && !s.signalFault && !s.suspended && s.phase==AnalogTachometer::Phase::Ready;
    const char *status=sessionNotice?"New session ready":s.stateName();
    const auto tone=sessionNotice?ScreensUI::Tone::Text:s.ready && !s.signalFault?ScreensUI::Tone::Ready:ScreensUI::Tone::Warning;
    // An open battle shows both launches where the RPM readout is; the status
    // and the level stay, for the next launch.
    if(battleCard==Battle::Session::View::Versus)BattleUI::versus(view,colors,status,tone,*battleRival);
    else ScreensUI::live(view,colors,status,tone,s.valid,s.resultRpm);
    drawLiveLevel(view,cx);
  }
  if(!tournamentMode && (diagnostics || (!historyPage && !launchFeedback.shown())) &&
     battleCard!=Battle::Session::View::Pick && battleCard!=Battle::Session::View::Result) {
    view.setTextDatum(top_center);view.setTextColor(colors.muted,colors.background);
    ControlsUI::footer(view,battleCard==Battle::Session::View::Versus?"A Won  B Lost":"A Recap  B Menu");
  }
  const uint32_t now=millis();
  if(M5.BtnA.isPressed() && !gestureA.consumed && battleCard==Battle::Session::View::None &&
     (tournamentMode || (controls.page==Controls::Page::Main && !launchFeedback.shown())))
    ControlsUI::hold(view,tournamentMode?"Exit tournament":"Enter tournament",now-M5.BtnA.lastChange(),1000);
  else if(M5.BtnB.isPressed() && !gestureB.consumed && battleCard!=Battle::Session::View::None)
    ControlsUI::hold(view,battleCard==Battle::Session::View::Versus?"Skip battle":battleCard==Battle::Session::View::Pick?"Back":"OK",now-M5.BtnB.lastChange(),1000);
  else if(M5.BtnB.isPressed() && !gestureB.consumed && !tournamentMode)
    ControlsUI::hold(view,controls.page==Controls::Page::Analysis?"Exit analysis":controls.page==Controls::Page::Main?"Enter analysis":controls.page==Controls::Page::Edit?"Cancel change":"Back",now-M5.BtnB.lastChange(),1000);
  drawnCornerBattery=cornerBattery(now);ControlsUI::cornerBattery(view,drawnCornerBattery,controls.page==Controls::Page::Menu);
  BleLink::drawIcon(view,colors.muted,colors.ready,colors.background,colors.text);
  if(BluetoothSetting::restartNeeded(bluetoothOn,bluetoothAtBoot))ControlsUI::restarting(view);
  {uint32_t pairingNumber=0;bool pairingAutomatic=false;if(BleLink::comparison(pairingNumber,pairingAutomatic))ControlsUI::comparison(view,pairingNumber,pairingAutomatic);}
  // An internal canvas is pushed by DMA, which endWrite does not wait for.
  // Wait so the transfer stays inside the boundary marks and the next frame
  // cannot overwrite pixels still being sent.
  if(screenReady) {
    acquisition.displayBoundary(true);M5.Display.startWrite();
    // Only the rows that changed since the panel's last frame, nothing when
    // none did (frame_rows.h); whole after a rotation.
    if(M5.Display.getRotation()!=frameRotation){frameRotation=M5.Display.getRotation();frameRows.invalidate();}
    FrameRows::Span rows;rows.count=screen.height();rows.whole=true;
    if(PowerSavers::settings.changedRowsOnly)rows=frameRows.changed(screen.getBuffer(),screen.width(),screen.height(),millis());
    else frameRows.invalidate();
    if(rows.whole)screen.pushSprite(0,0);
    else if(rows.any()){M5.Display.setClipRect(0,rows.first,screen.width(),rows.count);screen.pushSprite(0,0);M5.Display.clearClipRect();}
    M5.Display.waitDMA();
#if LAUNCHLAB_POWER_LAB
    Lab::rows+=uint32_t(rows.count);
#endif
  }
#if LAUNCHLAB_POWER_LAB
  ++Lab::frames;
#endif
  M5.Display.endWrite();
  if(effectReadUs){presentLagUs=uint32_t(esp_timer_get_time()-effectReadUs);effectReadUs=0;}
  acquisition.displayBoundary(false);
  if(!tournamentMode && !diagnostics && !historyPage && launchFeedback.shown() && !motionDemo && !motionPending)
    bestEffect.presented(millis());
  // The sound starts with the effect's first presented frame. The editor's
  // preview holds its first frame until its sound is rendered, so the two
  // start together.
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::BestEffect) &&
     (appearance.sound==Appearance::Sound::Off || !editorEffect.badge() || soundPlayer.prepared(editorEffect.effect())))editorEffect.presented(millis());
  if(bestEffect.takeCue()) {
    Serial.printf("CELEBRATION_START launch=%lu effect=%s milestone=%u best=%d\n",(unsigned long)latestMotion.number,
      Appearance::label(bestEffect.effect()),unsigned(bestEffect.milestone()),bestEffect.best());
    requestSound(bestEffect.effect(),appearance.sound,true);
    // Keep this pick's clip ready until its first frame has started playback.
    // Only a presented Best effect consumes Random's next pick; a milestone
    // plays its own effect.
    if(appearance.effect==Appearance::Effect::Random && !bestEffect.milestone())upcomingEffect=EffectSet::pick(esp_random(),bestEffect.effect(),effectSet.mask());
    // A milestone uses up its row's pick.
    if(bestEffect.milestone())nextMilestonePick(bestEffect.milestone(),bestEffect.effect());
  }
  if(editorEffect.takeCue())requestSound(editorEffect.effect(),appearance.sound,false);
  launchFeedback.replayPresented(millis(),!tournamentMode && !diagnostics && !historyPage &&
    (!motionPending || motionDemo) && (motionDemo?demoMotion:latestMotion).valid() && (motionDemo?demoMotion:latestMotion).fused,replayFrameElapsed);
  if(!motionDemo && !replayWasStarted && launchFeedback.replayStarted())
    Serial.printf("RECAP_PRESENT launch=%lu after_end_ms=%lu draw_us=%lu\n",(unsigned long)latestMotion.number,
      (unsigned long)((esp_timer_get_time()-motionEnd)/1000),(unsigned long)(esp_timer_get_time()-started));
  maxDrawUs=std::max(maxDrawUs,uint32_t(esp_timer_get_time()-started));
}

LOOP_HELPER static void pollLevel(uint32_t now) {
  // Fusion remains continuous on its own task. The UI needs fresh level data
  // only at 50 Hz, rather than copying the full snapshot on every loop pass.
  if(now-lastImuPoll<IdlePowerPolicy::LEVEL_POLL_MS)return;
  lastImuPoll=now;
  if(imuAcquisition.running()) {
    const auto sample=imuAcquisition.snapshot();
    const uint64_t clockUs=esp_timer_get_time();
    if(sample.activity.fresh(clockUs) && sample.activity.lastMotionUs>lastActivityMotionUs &&
       clockUs>=sample.activity.lastMotionUs && clockUs-sample.activity.lastMotionUs<=MotionActivity::FRESH_US) {
      lastActivityMotionUs=sample.activity.lastMotionUs;inactivity.motion(now);
    }
    imuStill.observe(now,sample.activity.fresh(clockUs) && !sample.activity.moving);
    if(sample.fusedUs && sample.fusedUs!=lastLevelSampleUs) {
      lastLevelSampleUs=sample.fusedUs;
      if(sample.orientationReady)level.feed(sample.gravity[0],sample.gravity[1],sample.gravity[2],uint32_t(sample.fusedUs/1000));
      else level.feed(0,0,0,uint32_t(sample.fusedUs/1000));
    }
    return;
  }
  imuStill.observe(now,false);
  if(!M5.Imu.isEnabled())return;
  const int64_t started=esp_timer_get_time();
  // update's returned accel bit establishes freshness; cached data is not a new sample.
  if(M5.Imu.update() & m5::IMU_Class::sensor_mask_accel) {
    const auto data=M5.Imu.getImuData();
    const auto &range=accelRange();
    const float native[3]={range.toG(data.accel.x),range.toG(data.accel.y),range.toG(data.accel.z)};float mapped[3];
    MountOrientation::mapVector(liveMount,native,mapped);
    level.feed(mapped[0],mapped[1],mapped[2],millis());
  }
  maxImuPollUs=std::max(maxImuPollUs,uint32_t(esp_timer_get_time()-started));
}

LOOP_HELPER static void exportScreen() {
  if(!screenReady){Serial.println("SNAP_ERROR no_draw_buffer");return;}
  // Export the last displayed frame, including its frozen level during a pull.
  const unsigned width=screen.width(),height=screen.height();
  Serial.printf("SNAP %u %u %u\n",width,height,width*height*2);
  uint8_t row[240*2];
  for(unsigned y=0;y<height;++y) {
    for(unsigned x=0;x<width;++x) {
      const uint16_t pixel=screen.readPixel(x,y);row[x*2]=pixel>>8;row[x*2+1]=pixel;
    }
    Serial.write(row,width*2);
  }
}

static void toggleFeedback() {
  if(tournamentMode)return;
  bestEffect.clear();
  historyPage=diagnostics=motionDemo=demo=false;
  launchFeedback.toggle(millis(),latestMotion.number!=0,MotionReplay::playbackDurationMs(latestMotion));dirty=true;
  Serial.printf("MAIN_FEEDBACK shown=%d reason=button t_ms=%lu\n",launchFeedback.shown(),(unsigned long)millis());
}

static void buttonA();
static void buttonB();
LOOP_HELPER static void toggleHistory(){buttonB();}
LOOP_HELPER static void nextView(){buttonA();}
// The pull's RPM turn by turn, copied by the optical task with its result.
LOOP_HELPER static void takeCurve(const Snapshot &event) {
  if(!acquisition.curve(event.revision,latestCurve))latestCurve.clear();
  const auto &c=latestCurve;unsigned peak=0;for(unsigned i=1;i<c.count;++i)if(c.rpm[i]>c.rpm[peak])peak=i;
  Serial.printf("RPM_CURVE launch=%lu points=%u stride=%u peak_rpm=%u peak_ms=%u last_ms=%u\n",(unsigned long)practice.recent()->number,
    unsigned(c.count),unsigned(c.stride),c.count?unsigned(c.rpm[peak]):0u,c.count?unsigned(c.ms[peak]):0u,c.count?unsigned(c.ms[c.count-1]):0u);
}
// celebrate: false for a pull the shutdown flush takes (routeEvent).
LOOP_HELPER static void prepareMotion(const Snapshot &event,bool celebrate=true) {
  lastAcceptedAt=millis();if(!historyPendingSince)historyPendingSince=lastAcceptedAt;
  if(motionPending)++motionDrops;
  latestMotion={};latestMotion.number=practice.recent()->number;latestMotion.rpm=event.resultRpm;
  takeCurve(event);
  const bool beat=bestStore.ready() && personalBests.observe(unsigned(event.sensorProfile),unsigned(event.estimator),event.valid,event.resultRpm);
  // The selected estimator's RPM is the pull's RPM, for milestones as for bests.
  const bool visible=!tournamentMode && !historyPage && !diagnostics;
  const auto decision=visible && celebrate?Milestones::decide(milestones,event.valid,event.resultRpm,beat,
    beat && milestones.mode()!=Milestones::Mode::Milestones?celebrationEffect():Appearance::Effect::Off,milestonePicks()):Milestones::Decision{};
  bestEffect.queue(decision.show,latestMotion.number,decision.effect,decision.best,decision.milestone);
  Serial.printf("CELEBRATION launch=%lu rpm=%.1f shown_rpm=%ld valid=%d mode=%s best=%d milestone=%u effect=%s celebrate=%d\n",(unsigned long)latestMotion.number,
    event.resultRpm,Milestones::shown(event.resultRpm),event.valid,Milestones::name(milestones.mode()),beat,unsigned(decision.milestone),
    decision.show?Appearance::playedLabel(decision.effect):"none",decision.show);
  motionStart=event.burstStartHostUs;motionEnd=event.burstEndHostUs;motionPending=true;
  // Update the recording regardless of navigation, without stealing an edit
  // or revealing results in tournament. Main/recap alone follows new pulls.
  if(!tournamentMode && !historyPage && !diagnostics) {
    motionDemo=demo=false;launchFeedback.show(millis());
  }
  dirty=true;
}
LOOP_HELPER static void finishMotion() {
  if(!motionPending)return;
  const uint64_t now=esp_timer_get_time();const auto imu=imuAcquisition.snapshot();
  if(!LaunchMotion::captureReady(now,motionEnd,imu.fusedUs))return;
  // A failed ring copy (allocation or a busy ring gate) is transient: retry
  // while the samples are still buffered instead of losing the replay.
  if(!imuAcquisition.capture(motionStart,motionEnd,latestMotion.rpm,latestMotion.number,latestMotion) &&
     now<motionEnd+MOTION_CAPTURE_RETRY_US){++motionCaptureRetries;return;}
  motionPending=false;dirty=true;
  const auto state=acquisition.snapshot();
  if(state.phase==AnalogTachometer::Phase::Launch || !launchFeedback.shown() || tournamentMode || historyPage || diagnostics || motionDemo)bestEffect.clear();
  else bestEffect.captured(latestMotion.number);
  // The replay starts over now its trace is in, as it was opened.
  if(launchFeedback.shown())launchFeedback.show(millis(),launchFeedback.replay(),MotionReplay::playbackDurationMs(latestMotion));
  Serial.printf("MAIN_FEEDBACK shown=%d reason=result t_ms=%lu\n",launchFeedback.shown(),(unsigned long)millis());
  Serial.printf("MOTION_RESULT launch=%lu quality=%s points=%u duration_ms=%lu rpm=%.1f stationary_bias=%d saturated=%d bridged=%d capture_retries=%lu peak_accel_g=%.2f accel_range_g=%.0f peak_gyro_dps=%.0f gyro_range_dps=%.0f\n",
    (unsigned long)latestMotion.number,LaunchMotion::name(latestMotion.quality),latestMotion.count,
    (unsigned long)latestMotion.durationMs,latestMotion.rpm,latestMotion.stationaryBias,latestMotion.saturated,latestMotion.bridged,(unsigned long)motionCaptureRetries,
    latestMotion.peakAccelG,accelRange().fullScaleG(),latestMotion.peakGyroDps,StickS3AccelRange::GYRO_FULL_SCALE_DPS);
  if(latestMotion.issueMs!=LaunchMotion::Trace::NO_ISSUE)
    Serial.printf("MOTION_ISSUE launch=%lu quality=%s at_ms=%ld pull_ms=%lu\n",(unsigned long)latestMotion.number,
      LaunchMotion::name(latestMotion.quality),(long)latestMotion.issueMs,(unsigned long)((motionEnd-motionStart)/1000));
  Serial.printf("MOTION_TIMING launch=%lu ready_after_end_ms=%lu pre_ms=%d post_ms=%d\n",
    (unsigned long)latestMotion.number,(unsigned long)((now-motionEnd)/1000),
    latestMotion.count?-int(latestMotion.points[0].ms):0,
    latestMotion.count?int(latestMotion.points[latestMotion.count-1].ms)-int(latestMotion.durationMs):0);
  Serial.printf("RECAP_LEVEL launch=%lu start_valid=%d start_xy=%.4f,%.4f end_valid=%d end_xy=%.4f,%.4f\n",
    (unsigned long)latestMotion.number,latestMotion.startLevel.valid(),latestMotion.startLevel.right,latestMotion.startLevel.down,
    latestMotion.endLevel.valid(),latestMotion.endLevel.right,latestMotion.endLevel.down);
}
LOOP_HELPER static void exportMotion() {
  Serial.printf("RPM_CURVE_EXPORT launch=%lu count=%u stride=%u\n",(unsigned long)latestMotion.number,unsigned(latestCurve.count),unsigned(latestCurve.stride));
  for(unsigned i=0;i<latestCurve.count;++i)Serial.printf("RPM_CURVE_POINT t_ms=%u rpm=%u\n",unsigned(latestCurve.ms[i]),unsigned(latestCurve.rpm[i]));
  for(const auto *t:{&referenceMotion,&latestMotion}) {
    const char *role=t==&referenceMotion?"reference":"latest";
    Serial.printf("MOTION_EXPORT role=%s number=%lu rpm=%.3f quality=%s count=%u duration_ms=%lu stationary_bias=%d fused=%d\n",role,
      (unsigned long)t->number,t->rpm,LaunchMotion::name(t->quality),t->count,(unsigned long)t->durationMs,t->stationaryBias,t->fused);
    if(t->valid())for(unsigned i=0;i<t->count;++i) {
      const auto &p=t->points[i];Serial.printf("MOTION_POINT role=%s t_ms=%d accel_change_g=%.3f,%.3f,%.3f gyro_dps=%.1f,%.1f,%.1f q=%.5f,%.5f,%.5f,%.5f\n",
        role,p.ms,p.a[0]*.001f,p.a[1]*.001f,p.a[2]*.001f,p.g[0]*.1f,p.g[1]*.1f,p.g[2]*.1f,
        p.q[0]/16384.0f,p.q[1]/16384.0f,p.q[2]/16384.0f,p.q[3]/16384.0f);
    }
    auto replay=std::unique_ptr<MotionReplay::Replay>(new(std::nothrow) MotionReplay::Replay);
    if(replay && replay->build(*t)) {
      Serial.printf("REPLAY_EXPORT role=%s number=%lu mode=rotation_only position=disabled absolute_heading=disabled count=%u\n",
        role,(unsigned long)t->number,MotionReplay::Replay::COUNT);
      for(unsigned i=0;i<MotionReplay::Replay::COUNT;++i) {
        const auto &q=replay->pose[i];Serial.printf("REPLAY_POINT role=%s t_ms=%d gravity_aligned_q=%.5f,%.5f,%.5f,%.5f\n",role,
          replay->ms[i],q.w,q.x,q.y,q.z);
      }
    }
  }
}
LOOP_HELPER static void newSession() {
  bestEffect.clear();
  practice.newSession();newSessionAt=millis();demo=false;diagnostics=false;historyPage=false;dirty=true;
  if(controls.page==Controls::Page::Analysis)syncNavigation();
  Serial.println("HISTORY_SESSION next accepted launch starts a new session");
}
LOOP_HELPER static void previewSetting() {
  const auto s=acquisition.snapshot();
  if(s.phase==AnalogTachometer::Phase::Launch){restorePreview=true;return;}
  if(restorePreview) {
    M5.Display.setBrightness(backlightValue());M5.Display.setRotation(DisplayOrientation::rotation(displayFlipped));
    restorePreview=false;
  }
  if(controls.page==Controls::Page::Edit) {
    if(controls.setting==2)M5.Display.setBrightness((unsigned(controls.draft)*255+50)/100);
    if(controls.setting==3)M5.Display.setRotation(DisplayOrientation::rotation(bool(controls.draft)));
  }
}
// Random's upcoming pick stays available until a celebration is presented.
LOOP_HELPER static Appearance::Effect upcoming() {
  if(!Appearance::celebrates(unsigned(upcomingEffect)))upcomingEffect=EffectSet::pick(esp_random(),Appearance::Effect::Off,effectSet.mask());
  return upcomingEffect;
}
LOOP_HELPER static const Appearance::Effect *milestonePicks() {
  if(!milestonePicksReady || !milestonePicked.same(milestones)) {
    for(unsigned i=0;i<milestones.count();++i)milestoneNext[i]=Milestones::pick(Milestones::playable(milestones.row(i).pool),esp_random(),Appearance::Effect::Off);
    milestonePicked=milestones;milestonePicksReady=true;
  }
  return milestoneNext;
}
LOOP_HELPER static void nextMilestonePick(uint16_t rpm,Appearance::Effect played) {
  milestonePicks();
  for(unsigned i=0;i<milestones.count();++i)
    if(milestones.row(i).rpm==rpm)milestoneNext[i]=Milestones::pick(Milestones::playable(milestones.row(i).pool),esp_random(),played);
}
LOOP_HELPER static Appearance::Effect celebrationEffect() {
  // A loaded Best effect that cannot play here (deleted, damaged) plays its fallback.
  if(appearance.effect!=Appearance::Effect::Random)return Appearance::resolve(appearance.effect);
  return upcoming();
}
// Keep a queued recap's clip intact until its first presented frame takes the
// sound cue, including USB previews of an effect other than the saved one.
LOOP_HELPER static Appearance::Effect soundTarget(){
  if(bestEffect.badge() && !bestEffect.started())return bestEffect.effect();
  if(editorEffect.badge() && !editorEffect.started())return editorEffect.effect();
  return appearance.effect==Appearance::Effect::Random?upcoming():appearance.effect;
}
// Plays now if the sound is rendered, otherwise once the idle slices finish it.
LOOP_HELPER static void requestSound(Appearance::Effect effect,Appearance::Sound level,bool celebration) {
  soundRequest={};
  if(soundPlayer.muted)return;
  if(level==Appearance::Sound::Off){soundPlayer.stop();celebrationSound=soundPreview=false;return;}
  soundRequest.active=true;soundRequest.celebration=celebration;soundRequest.effect=effect;soundRequest.level=level;
  if(soundPlayer.prepared(effect))startSound(false);
}
// Starts the requested sound in step with its effect (SoundSync). At the
// effect's cue the effect's clock moves to where the sound will be heard; a
// sound ready only later (`late`) starts at the sample matching the frame
// then on the glass.
LOOP_HELPER static void startSound(bool late) {
  auto &shown=soundRequest.celebration?bestEffect:editorEffect;
  const bool synced=shown.started() && shown.effect()==soundRequest.effect;
  size_t skip=0;
  if(late && synced && soundPlayer.power())
    skip=SoundSync::skipSamples(millis(),soundPlayer.nextOutputUs(),presentLagUs,shown.startedAt(),BestEffectSound::RATE);
  const bool started=soundPlayer.play(soundRequest.effect,soundRequest.level,skip);
  if(started){soundSkipped=uint32_t(skip);soundShiftMs=0;songCue=nullptr;}
  if(started && synced && !late && soundPlayer.song(soundRequest.effect)) {
    songCue=&shown;songCueFrom=shown.startedAt();shown.align(millis()+SONG_HOLD_MS);
  } else if(started && synced && !late) {
    const uint32_t at=SoundSync::clockStart(millis(),soundPlayer.outputUs(),presentLagUs);
    soundShiftMs=int32_t(at-shown.startedAt());shown.align(at);
  }
  (soundRequest.celebration?celebrationSound:soundPreview)=started;soundRequest.active=false;
}
// Each B in the Sound editor plays the current effect at the draft level.
LOOP_HELPER static void previewSound(){requestSound(soundTarget(),Appearance::Sound(controls.draft),false);}
// A match won (Battles): the sound of the player's celebration, as a best launch has.
LOOP_HELPER static void matchWonSound() {
  const Appearance::Effect effect=soundTarget();
  if(effect!=Appearance::Effect::Off)requestSound(effect,appearance.sound,false);
}
// Each B in the Best effect editor, and opening it, plays the draft around the
// value card (with its sound when Sound is on); Random shows a random pick.
LOOP_HELPER static void previewEffect() {
  static Appearance::Effect lastShown=Appearance::Effect::Off;
  const auto choice=Appearance::Effect(controls.draft);
  // A new preview silences the last one: its first frame must not hold under
  // the old sound while its own renders.
  editorEffect.clear();dirty=true;
  if(soundPreview || soundRequest.active){soundPlayer.stop();soundPreview=false;soundRequest={};}
  if(!Appearance::celebrates(unsigned(choice)) && choice!=Appearance::Effect::Random){soundPlayer.stop();soundPreview=false;soundRequest={};return;}
  lastShown=choice==Appearance::Effect::Random?EffectSet::pick(esp_random(),lastShown,effectSet.mask()):choice;
  editorEffect.queue(true,1,lastShown);editorEffect.captured(1);
}
static void cancelSettingEdit() {
  if(controls.page==Controls::Page::Wipe)cancelWipe();
  if(controls.page==Controls::Page::Edit)controls.page=Controls::Page::Settings;
  restorePreview=true;settingsSaveError=false;previewSetting();
}
// Runs inside a checkpoint the caller holds, ordinary or shutdown: the
// detector's estimator and sensor profile can only change there, and the IMU
// frame only outside a pull or capture. A cancelled power-off then leaves the
// live state matching the records. Whatever fails stays pending.
static constexpr const char *CAL_KEY="analysis_cal";
using CalibrationBytes=std::unique_ptr<uint8_t,decltype(&heap_caps_free)>;
// Each stopped run owns its packet until flash commits it. If the fit arrives
// later its attachment can be retried without appending another pull.
struct CalibrationPacket {
  CalibrationPacket *next=nullptr;
  Calibration::Archive::Entry stored{};
  size_t raw=0,fit=0;
  unsigned count=0;
  bool fitSaved=false;
  size_t audio=0;bool audioSaved=false;
  uint8_t *audioData(){return data()+raw+Calibration::fitBytes(count);}
  uint8_t *data(){return reinterpret_cast<uint8_t*>(this+1);}
  bool pending()const{return !stored.size || (fit && !fitSaved) || (audio && !audioSaved);}
  void send(){
    Serial.printf("CAL_DATA %u ram\n",unsigned(raw+fit+audio));Serial.write(data(),raw+fit);if(audio)Serial.write(audioData(),audio);
  }
};
static CalibrationPacket *firstCalibration=nullptr,*latestCalibration=nullptr;
static uint32_t capturedAnalysisLaunch=0,lastCaptureTry=0;
static bool calibrationCapturePending=false;
static bool analysisCapturePending(){return calibrationCapturePending;}
static ForecastShadow::Log shadowLog;

static void observeForecastCheckpoint(unsigned elapsedMs){
  if(!shadowLog.due(elapsedMs))return;
  const auto forecast=analysisResults.forecast(analysis.number());
  if(forecast.atMs<=elapsedMs)shadowLog.observe(forecast);
}

static bool calibrationNeedsSave(){
  if(calibrationCapturePending)return true;
  for(auto *p=firstCalibration;p;p=p->next)if(p->pending())return true;
  return false;
}

static void releaseSavedCalibrations(){
  // A failed older attachment must not pin newer, fully committed packets.
  // Keep the latest packet for a final fit and the immediate USB export.
  auto **link=&firstCalibration;
  while(auto *packet=*link){
    if(packet==latestCalibration || packet->pending()){
      link=&packet->next;
    } else {
      *link=packet->next;
      packet->~CalibrationPacket();
      heap_caps_free(packet);
    }
  }
}

LOOP_HELPER static bool captureStoppedCalibration(){
  if(!analysis.number() || analysis.running() || capturedAnalysisLaunch==analysis.number())return true;
  calibrationCapturePending=true;lastCaptureTry=millis();
  const unsigned elapsed=unsigned(analysis.elapsedUs(0)/1000);
  observeForecastCheckpoint(elapsed);
  micListener.drainTrace();
  micListener.freezeTrace(elapsed);
  const auto *trace=micListener.trace();
  const auto launch=analysis.number();
  if(trace && trace->launch()!=launch)trace=nullptr;
  const unsigned count=trace?trace->rawCount():0;
  const size_t room=sizeof(CalibrationPacket)+Calibration::rawCapacity(count)+Calibration::fitBytes(count)+AudioMetadata::packedBytes(elapsed);
  auto *memory=heap_caps_malloc(room,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  if(!memory){settingsSave.mark(SettingsSave::AnalysisResult);saveError=dirty=true;Serial.println("CAL_ERROR stop_capture_no_memory");return false;}
  auto *packet=new(memory) CalibrationPacket;
  packet->count=count;
  Calibration::Preview preview;
  const auto forecast=analysisResults.forecast(launch);
  if(forecast.atMs && forecast.atMs<=elapsed && forecast.rawCount<=count && std::isfinite(forecast.seconds)){
    preview.model=unsigned(EarlySpin::Source::Stamina);preview.kind=1;
    preview.atMs=forecast.atMs;preview.count=forecast.rawCount;preview.lo=preview.hi=forecast.seconds;
  }
  packet->raw=Calibration::packRaw(packet->data(),launch,analysis.rpm(),elapsed,
      unsigned(analysis.stopReason()),esp_app_get_description()->app_elf_sha256,preview,trace,shadowLog);
  const auto *audio=micListener.audioMetadata(launch);
  const unsigned skipped=trace?trace->skippedMs():0,drops=trace?trace->lostFrames():0;
  packet->audio=audio?audio->pack(packet->audioData(),elapsed,skipped,drops):
    AudioMetadata::pack(packet->audioData(),nullptr,elapsed,skipped,drops,false);
  if(latestCalibration)latestCalibration->next=packet;
  else firstCalibration=packet;
  latestCalibration=packet;releaseSavedCalibrations();
  settingsSave.mark(SettingsSave::AnalysisResult);
  capturedAnalysisLaunch=launch;calibrationCapturePending=false;
  return true;
}

LOOP_HELPER static void captureCalibration(bool completed){
  if(!completed)return;
  const auto *fits=analysisResults.results();
  const auto *input=analysisResults.input();
  if(!fits || !input || !analysisResults.matches(analysis))return;
  auto *packet=latestCalibration;
  if(!packet || packet->fit || packet->count!=input->count ||
     FlashLayout::get32(packet->data()+4)!=analysis.number() ||
     FlashLayout::get32(packet->data()+12)!=input->stopMs)return;
  Calibration::packFit(packet->data()+packet->raw,*input,*fits);
  packet->fit=Calibration::fitBytes(packet->count);
  settingsSave.mark(SettingsSave::AnalysisResult);
}

// Called only inside a granted checkpoint. A failed write keeps both the
// packet and its settings bit pending for SettingsSave's five-second retry.
LOOP_HELPER static bool saveCalibration(){
  bool saved=true;
  // Commit raw traces first; metadata and fit failures retain their own retry state.
  for(auto *p=firstCalibration;p;p=p->next)
    if(!p->stored.size && !Calibration::Archive::append(spiffsFlash,p->data(),p->raw,&p->stored))return false;
  Calibration::Archive::Index committed;
  if(firstCalibration && !Calibration::Archive::scan(spiffsFlash,committed))return false;
  for(auto *p=firstCalibration;p;p=p->next){
    const auto end=committed.entries.begin()+committed.count;
    const auto begin=end-std::min(committed.count,Calibration::Archive::KEEP);
    const bool retained=std::any_of(begin,end,[&](const auto &e){
      return e.sequence==p->stored.sequence && e.offset==p->stored.offset && e.size==p->stored.size;
    });
    if(!retained){
      if((p->audio && !p->audioSaved) || (p->fit && !p->fitSaved))Serial.println("CAL_NOTICE optional_data_evicted");
      p->audioSaved=p->fitSaved=true;continue;
    }
    if(p->audio && !p->audioSaved){
      if(!AudioMetadataStore::save(spiffsFlash,p->stored.sequence,FlashLayout::get32(p->data()+p->raw-4),
                                  p->audioData(),p->audio))saved=false;
      else p->audioSaved=true;
    }
    if(p->fit && !p->fitSaved){
      if(!Calibration::Archive::attach(spiffsFlash,p->stored,p->data()+p->raw,p->fit))saved=false;
      else p->fitSaved=true;
    }
  }
  releaseSavedCalibrations();return saved && !calibrationCapturePending;
}
static bool sendStoredCalibration(const Calibration::Archive::Entry &e,const AudioMetadataStore::Index *audioIndex=nullptr){
  for(auto *p=firstCalibration;p;p=p->next)
    if(p->stored.size && p->stored.sequence==e.sequence && ((p->fit && !p->fitSaved) || (p->audio && !p->audioSaved))){p->send();return true;}
  CalibrationBytes buf(static_cast<uint8_t*>(heap_caps_malloc(e.size+Calibration::fitBytes(Decay::MAX_SAMPLES)+AudioMetadata::MAX_BYTES,
                                                              MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)),heap_caps_free);
  if(!buf || !spiffsFlash.read(e.offset+Calibration::Archive::HEADER_BYTES,buf.get(),e.size)){
    Serial.println("CAL_ERROR read_failed");return false;
  }
  if(!Calibration::validPacket(buf.get(),e.size)){Serial.println("CAL_ERROR corrupt_raw_trace");return false;}
  size_t bytes=e.size;
  if(Calibration::isRawPacket(buf.get())){
    const unsigned count=FlashLayout::get32(buf.get()+20);
    const auto at=Calibration::Archive::fitOffset(e);
    const auto n=Calibration::fitBytes(count);
    uint8_t *fit=buf.get()+bytes;
    if(count<=Decay::MAX_SAMPLES && at+n<=e.offset+Calibration::Archive::SLOT_BYTES &&
       spiffsFlash.read(at,fit,4) && !std::memcmp(fit,"LLF2",4)){
      if(spiffsFlash.read(at+4,fit+4,n-4) && Calibration::validFit(fit,n,count))bytes+=n;
      else Serial.println("CAL_NOTICE invalid_fit_omitted");
    }
  }
  size_t audioBytes=0;
  const auto traceCrc=FlashLayout::get32(buf.get()+e.size-4);
  const bool audioOk=audioIndex
      ? AudioMetadataStore::read(spiffsFlash,*audioIndex,e.sequence,traceCrc,buf.get()+bytes,audioBytes)
      : AudioMetadataStore::read(spiffsFlash,e.sequence,traceCrc,buf.get()+bytes,audioBytes);
  if(!audioOk){
    Serial.println("CAL_ERROR audio_metadata_read_failed");return false;
  }
  bytes+=audioBytes;
  Serial.printf("CAL_DATA %u flash\n",unsigned(bytes));Serial.write(buf.get(),bytes);return true;
}

LOOP_HELPER static void exportLaunchWavs(){
  Serial.println("WAV_ERROR replaced_by_audio_metadata_use_calibration_export");
}

LOOP_HELPER static void exportCalibrationBatch(){
  Calibration::Archive::Index index;
  const bool readable=Calibration::Archive::scan(spiffsFlash,index);
  if(!readable){
    if(!firstCalibration){Serial.println("CAL_ERROR archive_unavailable");return;}
    index.count=0;Serial.println("CAL_RAM_ONLY");
  }
  unsigned stored=std::min(index.count,Calibration::Archive::KEEP),ram=0;
  for(auto *p=firstCalibration;p;p=p->next)if(!readable || !p->stored.size)++ram;
  Serial.printf("CAL_COUNT %u\n",stored+ram);
  AudioMetadataStore::Index audioIndex;
  const auto *audio=stored && AudioMetadataStore::scan(spiffsFlash,audioIndex)?&audioIndex:nullptr;
  for(unsigned i=index.count-stored;i<index.count;++i)
    if(!sendStoredCalibration(index.entries[i],audio))return;
  for(auto *p=firstCalibration;p;p=p->next)if(!readable || !p->stored.size)p->send();
  Serial.println("CAL_END");
}

LOOP_HELPER static void exportCalibration(){
  Calibration::Archive::Index index;
  if(Calibration::Archive::scan(spiffsFlash,index) || firstCalibration){
    Serial.println("CAL_HISTORY");
    if(!latestCalibration && index.count){sendStoredCalibration(index.entries[index.count-1]);return;}
  }
  if(latestCalibration){latestCalibration->send();return;}
  const size_t n=prefs.getBytesLength(CAL_KEY);
  if(!n){
    Decay::Record::Image old{};
    if(prefs.getBytesLength("analysis_fit")==old.size() && prefs.getBytes("analysis_fit",old.data(),old.size())==old.size()){
      Serial.printf("CAL_FIT %u flash\n",unsigned(old.size()));Serial.write(old.data(),old.size());
    } else Serial.println("CAL_ERROR no_saved_trace");
    return;
  }
  if(n<Calibration::HEADER+4 || n>Calibration::MAX_BYTES){Serial.println("CAL_ERROR invalid_size");return;}
  CalibrationBytes disk(static_cast<uint8_t*>(heap_caps_malloc(n,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)),heap_caps_free);
  if(!disk || prefs.getBytes(CAL_KEY,disk.get(),n)!=n){Serial.println("CAL_ERROR read_failed");return;}
  Serial.printf("CAL_DATA %u flash\n",unsigned(n));Serial.write(disk.get(),n);
}

LOOP_HELPER static void logAnalysisResults() {
  const auto *fits=analysisResults.results();if(!fits)return;
  Serial.printf("ANALYSIS_RESULTS samples=%u source=%u best=%d validation=%d observed_stop=%d\n",fits->sampleCount,fits->sourceCount,fits->best,fits->validationPossible,fits->actualStopValid);
  const unsigned i=unsigned(Decay::Model::Riccati);
  const auto &r=fits->models[i];
  Serial.printf("ANALYSIS_MODEL model=%c valid=%d converged=%d boundary=%d unstable=%d a=%.7g b=%.7g c=%.7g k=%.7g n=%.7g stop_valid=%d stop_s=%.3f error_valid=%d error_s=%.3f abs_error_s=%.3f\n",
    'A'+i,r.valid,r.converged,r.boundary,r.unstable,r.params.a,r.params.b,r.params.c,r.params.k,r.params.n,r.stopValid,r.stopSeconds,r.stopErrorValid,r.stopError,r.absoluteStopError);
  const Decay::Metric *metrics[]={&r.training,&r.validation,&r.all};
  for(unsigned j=0;j<3;++j){const auto &m=*metrics[j];Serial.printf("ANALYSIS_METRIC model=%c set=%s valid=%d rmse=%.3f mae=%.3f max=%.3f\n",'A'+i,j==0?"train":j==1?"validation":"all",m.valid,m.rmse,m.mae,m.maxError);}
}
// Optional latest-fit record: reserve capacity for the next practice-history save.
// CRC-protected bytes are read back. Failure leaves the current results usable in RAM.
LOOP_HELPER static bool saveAnalysisResult() {
  if(!analysisResults.recordPending())return true;
  static constexpr const char *key="analysis_fit";
  const unsigned own=NvsBudget::blobEntries(Decay::Record::BYTES);
  const unsigned needed=NvsBudget::optionalNeeded(own,prefs.isKey(key)?0:own,NvsBudget::blobEntries(PracticeHistory::IMAGE_BYTES));
  unsigned available=0;bool ok=false;
  if(nvsAvailable(available) && available>=needed){
    const auto &image=analysisResults.record();Decay::Record::Image check{};
    ok=prefs.putBytes(key,image.data(),image.size())==image.size() &&
      prefs.getBytes(key,check.data(),check.size())==check.size() && check==image;
  }
  Serial.printf("ANALYSIS_RECORD saved=%d bytes=%u available=%u needed=%u\n",ok,unsigned(Decay::Record::BYTES),available,needed);
  analysisResults.recordHandled();return true; // Optional failure must not block shutdown/history.
}
static void writeSettings() {
  const uint32_t items=settingsSave.pending();
  if(!items)return;
  uint32_t saved=0;
  const auto live=acquisition.snapshot();
  if(items&SettingsSave::Rpm) {
    bool current=live.estimator==rpmEstimator;
    // A metric change starts a new session at the moment the detector switches.
    if(!current && acquisition.request(Action::Estimator,uint8_t(rpmEstimator))){current=true;practice.newSession();launchFeedback.clear();}
    if(current && RpmEstimatorSetting::save(prefs,rpmEstimator))saved|=SettingsSave::Rpm;
  }
  if(items&SettingsSave::Sensor) {
    bool current=live.sensorProfile==sensorProfile;
    if(!current && acquisition.request(Action::SensorProfile,uint8_t(sensorProfile))) {
      current=true;practice.newSession();launchFeedback.clear();
      // Another sensor's marks: its own reference starts empty.
      startMarks.clear(uint8_t(sensorProfile));startMarksDirty=true;saveStartMarks();
    }
    if(current && SensorProfileSetting::save(prefs,sensorProfile))saved|=SettingsSave::Sensor;
  }
  if((items&SettingsSave::Sleep) && prefs.putUChar("sleep_min",inactivity.minutes())==1)saved|=SettingsSave::Sleep;
  if((items&SettingsSave::Brightness) && prefs.putUChar(Brightness::KEY,brightnessPercent)==1)saved|=SettingsSave::Brightness;
  if((items&SettingsSave::Flip) && DisplayFlipSetting::save(prefs,displayFlipped))saved|=SettingsSave::Flip;
  if((items&SettingsSave::ShakeWake) && ShakeWakeSetting::save(prefs,shakeToWake))saved|=SettingsSave::ShakeWake;
  if((items&SettingsSave::BatteryIcon) && BatteryIconSetting::save(prefs,batteryIcon))saved|=SettingsSave::BatteryIcon;
  if((items&SettingsSave::MinRpm) && MinRpmSetting::save(prefs,minRpmSteps))saved|=SettingsSave::MinRpm;
  if((items&SettingsSave::Bluetooth) && BluetoothSetting::save(prefs,bluetoothOn))saved|=SettingsSave::Bluetooth;
  if((items&SettingsSave::Bonds) && BleLink::saveBonds(prefs))saved|=SettingsSave::Bonds;
  if((items&SettingsSave::Name) && BleLink::saveName(prefs))saved|=SettingsSave::Name;
  if((items&SettingsSave::PassConfirmed) && prefs.putBytes(PASS_CONFIRMED_KEY,&passConfirmed,sizeof(passConfirmed))==sizeof(passConfirmed))
    saved|=SettingsSave::PassConfirmed;
  if((items&SettingsSave::Battles) && BattlesSetting::save(prefs,battlesOn,battleMatchTo))saved|=SettingsSave::Battles;
  if(items&SettingsSave::Mount) {
    bool current=liveMount==mountMode;
    if(!current && imuAcquisition.setMount(mountMode)) {
      // Level restarts in the new frame; a recap drawn in the old one goes.
      current=true;liveMount=mountMode;level=StickS3Level{};drawnLevel={};lastLevelSampleUs=0;
      launchFeedback.clear();
    }
    if(current && MountOrientationSetting::save(prefs,mountMode))saved|=SettingsSave::Mount;
  }
  if((items&SettingsSave::Appearance) && appearanceStore.saveViewed(appearance))saved|=SettingsSave::Appearance;
  if((items&SettingsSave::Milestones) && milestoneStore.save(milestones))saved|=SettingsSave::Milestones;
  if((items&SettingsSave::Pin) && prefs.putUChar("ao_pin",live.pin)==1)saved|=SettingsSave::Pin;
  if((items&SettingsSave::ExtPower) && prefs.putBool("ext5v",extPower)==1)saved|=SettingsSave::ExtPower;
  if(items&SettingsSave::AnalysisResult){
    const bool fitSaved=saveAnalysisResult();
    if(saveCalibration() && fitSaved)saved|=SettingsSave::AnalysisResult;
  }
  settingsSave.wrote(saved);dirty=true;
  Serial.printf("SETTINGS_SAVE items=0x%03lx saved=0x%03lx\n",(unsigned long)items,(unsigned long)saved);
}
// Pending settings reach flash in the first checkpoint the optical owner
// grants: right away after Apply in the usual case, otherwise as soon as the
// signal is quiet again. Never during a pull or a motion capture.
LOOP_HELPER static void saveSettings(uint32_t now,const Snapshot &s,bool immediate=false) {
  if(!settingsSave.pending() || (!immediate && !settingsSave.due(now)) || motionPending ||
     !SettingsSave::ownerIdle(s.ready,s.suspended,s.opticalIdle,s.signalFault))return;
  // Record the attempt first: a vetoed checkpoint must not repeat the IMU
  // quiet wait on every UI tick.
  settingsSave.attempted(now);
  if(!acquisition.request(Action::IdleCheckpointBegin,s.launches)){settingsSave.refused();return;}
  writeSettings();
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("SETTING_ERROR acquisition_resume");
}
// Apply takes the choice at once and queues its record for flash. It never
// waits for an idle instant: pressing A can itself jiggle the launcher across
// a mark, and that used to refuse Apply after Apply with "Try again when idle".
// Takes one setting's new value in RAM, from the editor or the phone.
static bool applySetting(unsigned setting,uint8_t value,bool &changed) {
  bool applied=true;changed=false;
  switch(Controls::Setting(setting)) {
    case Controls::Setting::Sleep:
      changed=value!=inactivity.minutes();applied=inactivity.setMinutes(value);break;
    // The estimator, sensor profile and mount switch inside the save checkpoint.
    case Controls::Setting::Rpm:
      applied=RpmEstimator::valid(value);changed=applied && RpmEstimator::Mode(value)!=rpmEstimator;
      if(changed)rpmEstimator=RpmEstimator::Mode(value);
      break;
    case Controls::Setting::Brightness:changed=value!=brightnessPercent;brightnessPercent=value;break;
    case Controls::Setting::Flip:changed=bool(value)!=displayFlipped;displayFlipped=value;break;
    case Controls::Setting::ShakeWake:changed=bool(value)!=shakeToWake;shakeToWake=value;break;
    case Controls::Setting::BatteryIcon:changed=bool(value)!=batteryIcon;batteryIcon=value;break;
    // The optical owner takes the new floor on the next loop pass.
    case Controls::Setting::MinRpm:applied=MinRpm::valid(value);changed=applied && value!=minRpmSteps;if(changed)minRpmSteps=value;break;
    case Controls::Setting::Bluetooth:changed=bool(value)!=bluetoothOn;bluetoothOn=value;break;
    case Controls::Setting::Sensor:
      applied=StickS3SensorProfile::valid(value);changed=applied && StickS3SensorProfile::Mode(value)!=sensorProfile;
      if(changed)sensorProfile=StickS3SensorProfile::Mode(value);
      break;
    case Controls::Setting::Mount:
      applied=MountOrientation::valid(value);changed=applied && MountOrientation::Mode(value)!=mountMode;
      if(changed)mountMode=MountOrientation::Mode(value);
      break;
    case Controls::Setting::Theme:case Controls::Setting::BestEffect:case Controls::Setting::Sound: {
      // An unreadable stored look cannot be replaced; keep showing it rather
      // than a choice that would silently revert at the next boot.
      using S=Controls::Setting;const auto row=S(setting);
      auto next=appearance;
      applied=appearanceStore.ready() && (row!=S::Theme || themeLibrary.available(Appearance::Theme(value))) &&
        next.select(row==S::Theme?Appearance::Theme(value):appearance.theme,
                      row==S::BestEffect?Appearance::Effect(value):appearance.effect,
                      row==S::Sound?Appearance::Sound(value):appearance.sound);
      changed=applied && next.generation()!=appearance.generation();
      if(changed)appearance=next;
      break;
    }
    case Controls::Setting::Celebrate: {
      auto next=milestones;
      applied=milestoneStore.ready() && next.select(Milestones::Mode(value));
      changed=applied && next.generation()!=milestones.generation();
      if(changed)milestones=next;
      break;
    }
    case Controls::Setting::WipeAll:case Controls::Setting::About:applied=false;break; // Neither has an editor.
  }
  return applied;
}
static void commitSetting() {
  const uint8_t value=controls.draft;
  bool changed=false;
  const bool applied=applySetting(controls.setting,value,changed);
  settingsSaveError=!applied;
  Serial.printf("SETTING_APPLY row=%u value=%u applied=%d changed=%d\n",controls.setting,value,applied,changed);
  if(applied) {
    if(changed)settingsSave.mark(SettingsSave::item(controls.setting));
    controls.page=Controls::Page::Settings;restorePreview=true;previewSetting();
    saveSettings(millis(),acquisition.snapshot(),true);
  }
  syncNavigation();
}
// The Battle Pass profile's view of this stick (ble_battle_pass.h): what an
// app for the BEYBATTLE PASS is told. Tournament mode hides RPM, so it tells
// nothing then, like the LaunchLab profile.
namespace BattlePassFeed {
// A held on the Beyblade X page: the pass's button, which apps ask for to
// register a pass. What the Beyblade X page last showed, so it redraws on a change.
static bool button=false;
static uint32_t shownKey=0;
LOOP_HELPER static BattlePass::Shots shots() {
  BattlePass::Shots out;
  const auto *latest=practice.recent();
  const uint32_t open=BattlePass::unconfirmed(latest?latest->number:0,passConfirmed);
  const unsigned kept=practice.size(),listed=unsigned(std::min<uint32_t>(std::min<uint32_t>(kept,BattlePass::SHOTS),open));
  for(unsigned i=listed;i>0;--i)out.add(BattlePass::shootPower(practice.recent(i-1)->rpm));
  float best=0;for(float rpm:personalBests.rpm)best=std::max(best,rpm);
  for(unsigned i=0;i<kept;++i)best=std::max(best,practice.recent(i)->rpm);
  out.best=BattlePass::shootPower(best);
  // The count since the app's last clear, as the real pass counts from 0 again.
  out.total=uint16_t(std::min<uint32_t>(65535,open));
  return out;
}
LOOP_HELPER static void sendStatus(bool attached,const BattlePass::Shots &s) {
  uint8_t id[6]={};esp_efuse_mac_get_default(id);
  const uint32_t now=millis();
  BleLink::passSend(BattlePass::status(attached,battery.valid(now)?battery.percent:-1,s.best,s.total,id,button));
}
// The last 50 launches and the latest one's curve. No launch yet: nothing,
// since apps refuse an empty set.
LOOP_HELPER static void sendShots(const BattlePass::Shots &s) {
  if(!s.count)return;
  BattlePass::Packet list[8],turns[4];
  BattlePass::shots(s,list);BattlePass::curve(latestCurve.ms,latestCurve.rpm,latestCurve.count,turns);
  for(const auto &packet:list)BleLink::passSend(packet);
  for(const auto &packet:turns)BleLink::passSend(packet);
}
// After a pull: a top was on the launcher and has left (this stick has no
// sensor for the top, and apps place the launch by that release), then its set.
LOOP_HELPER static void launched() {
  if(tournamentMode || !BleLink::passListening())return;
  const auto s=shots();
  BleLink::passClear();sendStatus(true,s);sendStatus(false,s);sendShots(s);
}
// What an app asked for since the last pass of the loop. A clear confirms
// every launch so far: they leave the list, the count starts at 0 again and
// the number is saved. A power-off ends the link once its answer has gone.
LOOP_HELPER static void tick(uint32_t now) {
  const bool status=BleLink::takePassStatus(now),all=BleLink::takePassShots();
  const bool forget=BleLink::takePassClear(),off=BleLink::takePassOff();
  if(off)BleLink::passPowerOff(now);
  if((!status && !all && !forget) || tournamentMode)return;
  if(forget) {
    const auto *latest=practice.recent();
    const uint32_t number=latest?latest->number:0;
    passLastSync=shots().count;
    Serial.printf("BATTLE_PASS_CLEAR confirmed=%lu listed=%lu\n",(unsigned long)number,(unsigned long)passLastSync);
    if(number!=passConfirmed){passConfirmed=number;settingsSave.mark(SettingsSave::PassConfirmed);}
    dirty=true;
  }
  const auto s=shots();
  if(forget) {
    // A1, the status, and the list, empty now: what the real pass answers.
    BattlePass::Packet list[8];BattlePass::shots(s,list);
    BleLink::passSend(BattlePass::cleared());sendStatus(false,s);
    for(const auto &packet:list)BleLink::passSend(packet);
  }
  if(status)sendStatus(false,s);
  if(all)sendShots(s);
}
// The button follows A on the Beyblade X page; an app hears each change at
// once, as the real pass's status changes while its button is held.
LOOP_HELPER static void tickButton(bool buttonsFresh,bool onPage) {
  const bool held=onPage && (buttonsFresh?M5.BtnA.isPressed():button);
  if(held!=button) {
    button=held;dirty=true;
    if(!tournamentMode && BleLink::passListening())sendStatus(false,shots());
  }
  if(!onPage)return;
  const uint32_t key=uint32_t(BleLink::passListening())|uint32_t(BleLink::connected())<<1|uint32_t(passLastSync)<<2|uint32_t(shots().total)<<12;
  if(key!=shownKey){shownKey=key;dirty=true;}
}
LOOP_HELPER static ControlsUI::PassView view() {
  ControlsUI::PassView v;
  v.on=bluetoothOn;v.app=BleLink::passListening();v.phone=BleLink::connected();v.button=button;v.tournament=tournamentMode;
  v.waiting=BattlePass::unconfirmed(practice.recent()?practice.recent()->number:0,passConfirmed);v.synced=passLastSync;
  return v;
}
}
// Battles (docs/FIRMWARE_BATTLES.md): the sketch's side. A pull is told and
// listened for when Auto battles is on, the radio is up and the stick is not
// in tournament mode, which hides its launches. Nothing here renews the sleep
// timer: a launch and a button press already do, and a battle left alone ends
// by itself (battle_session.h).
namespace BattleFeed {
static bool allowed(){return battlesOn && !tournamentMode && !wipeBlocked && BattleRadio::available(bluetoothAtBoot);}
// A battle card is on the main screen: A and B are the battle's.
static bool cardShown() {
  return controls.page==Controls::Page::Main && !launchFeedback.shown() && !diagnostics && !tournamentMode &&
    battle.view()!=Battle::Session::View::None && battle.rival(rivals);
}
LOOP_HELPER static void report(uint8_t events) {
  if(!events)return;
  dirty=true;
  const Battle::Rival *r=battle.rival(rivals);
  if(!r)return;
  char name[Battle::NAME_CHARS+1];Battle::displayName(*r,name,sizeof(name));
  if(events&Battle::Session::Matched)
    Serial.printf("BATTLE_MATCHED rival=%08lx my_rpm=%u their_rpm=%u launches_together=%u rssi_dbm=%d pulled_ms_after=%ld match=%u-%u match_to=%u name=%s\n",(unsigned long)r->id,
      unsigned(r->myRpm),unsigned(r->theirRpm),unsigned(r->duels),battle.rivalRssi(),(long)battle.rivalOffset(),unsigned(r->matchMe),unsigned(r->matchThem),
      unsigned(r->matchTo),name);
  // The battle whose match win has been heard: a correction back and forth plays it once.
  static uint16_t cheered=0;
  if((events&Battle::Session::Settled) && r->matchEnded() && r->claim.outcome==Battle::Outcome::Won && r->myTag!=cheered) {
    cheered=r->myTag;matchWonSound();
  }
  if(events&Battle::Session::Settled)
    Serial.printf("BATTLE_RESULT rival=%08lx outcome=%s finish=%s rev=%u won=%u lost=%u points=%u-%u match=%u-%u match_to=%u matches=%u-%u\n",(unsigned long)r->id,
      Battle::name(r->claim.outcome),Battle::label(r->claim.finish),unsigned(r->claim.rev),unsigned(r->wins),unsigned(r->losses),
      unsigned(r->pointsFor),unsigned(r->pointsAgainst),unsigned(r->matchMe),unsigned(r->matchThem),unsigned(r->matchTo),unsigned(r->matchWins),unsigned(r->matchLosses));
  if(events&Battle::Session::Synced)Serial.printf("BATTLE_SYNCED rival=%08lx rev=%u\n",(unsigned long)r->id,unsigned(r->claim.rev));
}
// After an accepted pull: tell it, and listen for one made with it.
LOOP_HELPER static void launched(const Snapshot &s) {
  if(!allowed())return;
  const uint32_t now=millis(),ago=uint32_t(std::max<int64_t>(0,esp_timer_get_time()-int64_t(s.burstStartHostUs))/1000);
  battle.launch(now,now-ago,BattlePass::shootPower(s.resultRpm),uint16_t(esp_random()|1),rivals);
  Serial.printf("BATTLE_LAUNCH tag=%04x rpm=%u pull_began_ms_ago=%lu\n",unsigned(battle.tag()),unsigned(BattlePass::shootPower(s.resultRpm)),(unsigned long)ago);
}
// A or B (or hold B) while a card is up. True when the press was the battle's.
static bool press(Battle::Button button) {
  if(!cardShown() || !battle.press(millis(),button,rivals))return false;
  report(battle.take());dirty=true;return true;
}
LOOP_HELPER static void tick(uint32_t now,const Snapshot &s) {
  const bool on=allowed();
  if(!on)battle.stop();
  BattleRadio::Heard heard;
  while(BattleRadio::take(heard)) {
    if(!on)continue;
    Battle::LaunchFrame frame;Battle::NameFrame who;
    if(frame.decode(heard.bytes,heard.length)) {
      // For the serial log: each launch frame whose content is new, its age
      // aside, as BATTLE_TELL shows what this stick tells.
      static uint8_t shown[Battle::LAUNCH_BYTES];
      if(memcmp(shown,heard.bytes,8) || memcmp(shown+10,heard.bytes+10,Battle::LAUNCH_BYTES-10)) {
        char text[2*Battle::LAUNCH_BYTES+1];size_t at=0;
        for(size_t i=0;i<Battle::LAUNCH_BYTES;++i)at+=snprintf(text+at,sizeof(text)-at,"%02x",heard.bytes[i]);
        Serial.printf("BATTLE_HEARD %s rssi_dbm=%d waited_ms=%lu\n",text,int(heard.rssi),(unsigned long)(now-heard.at));
        memcpy(shown,heard.bytes,sizeof(shown));
      }
      battle.heard(heard.at,frame,heard.rssi,rivals);
    }
    else if(who.decode(heard.bytes,heard.length))battle.heard(who,rivals);
  }
  battle.tick(now);
  if(cardShown())battle.presented(now);
  BattleRadio::tick(now,on,s.phase==AnalogTachometer::Phase::Launch,battle,rivals,BleLink::chosenName);
  report(battle.take());
  controls.battlesOn=battlesOn;
  battle.matchLength(battleMatchTo);
  if(controls.rivals!=rivals.count()){controls.rivals=uint8_t(rivals.count());dirty=true;}
}
LOOP_HELPER static void status() {
  Serial.printf("BATTLE_STATUS on=%d match_to=%u allowed=%d active=%d in_battle=%d view=%u rival=%08lx rivals=%u won=%lu lost=%lu points=%lu generation=%lu unsaved=%d\n",
    battlesOn,unsigned(battleMatchTo),allowed(),battle.active(),battle.inBattle(),unsigned(battle.view()),(unsigned long)battle.rivalId(),rivals.count(),
    (unsigned long)rivals.totalWins(),(unsigned long)rivals.totalLosses(),(unsigned long)rivals.totalPoints(),(unsigned long)rivals.generation(),
    rivals.generation()!=loggedRivals);
  BattleRadio::status();
}
}
LOOP_HELPER static void logLaunchMetrics(const Snapshot &s) {
  const auto *record=practice.recent();if(!record)return;
  if(!tournamentMode)BleLink::publishLaunch(record->number,record->session,s.resultRpm);
  BattlePassFeed::launched();
  BattleFeed::launched(s);
  Serial.printf("LAUNCH_METRICS number=%lu session=%lu selected_estimator=%s selected_rpm=%.1f three_turn_peak_rpm=%.1f single_turn_peak_rpm=%.1f units=rpm\n",
    (unsigned long)record->number,(unsigned long)record->session,RpmEstimator::name(s.estimator),
    s.resultRpm,s.sustainedPeakRpm,s.singlePeakRpm);
}
LOOP_HELPER static MicView::Mic micPageState() {
  if(micListener.state()==MicSession::State::Refused)return micListener.why()==MicSession::Why::Memory?MicView::Mic::NoMemory:MicView::Mic::Failed;
  return micListener.warm(millis())?MicView::Mic::On:MicView::Mic::Starting;
}
// Analysis runs the mic (through 0.20.11 the Mic RPM page did). Opening it mutes the speaker, which
// powers down, and then the mic starts; leaving it, however the page changed,
// stops the mic and gives the speaker back. An owner who never opens the page
// stops at the first line.
LOOP_HELPER static void tickMicPage() {
  micListener.setAnalysisMode(controls.page==Controls::Page::Analysis);
  const bool open=controls.page==Controls::Page::Analysis;
  if(!open && micListener.off())return;
  const uint32_t now=millis();
  const auto before=micListener.state();
  micListener.tick(open,soundPlayer.powered(),now);
  soundPlayer.muted=micListener.muted();
  if(soundPlayer.muted) {
    if(soundRequest.active || soundPlayer.playing())soundPlayer.stop();
    soundRequest={};celebrationSound=soundPreview=false;
  }
  if(micListener.state()!=before)dirty=true;
  if(open && (micListener.on() && now-micPageChecked>=MIC_PAGE_FRAME_MS)) {
    micPageChecked=now;
    if(micListener.warm(now)!=micPageWarm){micPageWarm=!micPageWarm;dirty=true;}  // "warming up" ends without a reading
  }
  if(micListener.fresh())micPageFresh=true;
  if(micPageFresh && now-lastDraw>=MIC_PAGE_FRAME_MS){
    micPageFresh=false;
    if(controls.page!=Controls::Page::Analysis || (!analysis.replay() && !analysis.results()))dirty=true;
  }
}
static bool interruptAnalysis(uint64_t now) {
  analysis.interrupt(now);
  return captureStoppedCalibration();
}

// Preserve an unfinished recording before the next microphone launch reuses
// its trace and audio metadata buffers. Invalid optical pulls leave it running.
static void followAnalysisLaunch(const Snapshot &event) {
  if(controls.page==Controls::Page::Analysis) {
    if(!event.valid || !event.launches || !event.burstEndHostUs || event.launches==analysis.number())return;
    if(!interruptAnalysis(esp_timer_get_time())) {
      Serial.println("CAL_ERROR launch_waiting_for_capture");return;
    }
    capturedAnalysisLaunch=0;
    analysis.begin(event.launches,event.valid,event.resultRpm,event.burstEndHostUs);
    shadowLog.reset();
  }
  micListener.launch(event.launches,event.valid,event.resultRpm,event.burstStartHostUs,event.burstEndHostUs);
}

// Sleep and power-off wait for this, so neither meets a running mic, unless
// its stop never ends: then they go ahead after MicSession::STOP_LIMIT_MS.
LOOP_HELPER static void leaveMicPage() {
  if(controls.page==Controls::Page::Analysis){
    if(!interruptAnalysis(esp_timer_get_time()))return;
    analysis.clear();controls.page=Controls::Page::Main;syncNavigation();dirty=true;
  }
}
static void browseOlder() {
  if(tournamentMode || !historyPage)return;
  const auto &h=demo?demoPractice:practice;
  const unsigned total=PracticeUI::count(h,historyView),step=PracticeUI::window(historyView);
  historyOffset=historyOffset+step<total?historyOffset+step:0;dirty=true;
}
static void navigate(Controls::Effect effect,Controls::Page previous) {
  if(previous!=controls.page && (previous==Controls::Page::Analysis || controls.page==Controls::Page::Analysis)) {
    if(previous==Controls::Page::Analysis && !interruptAnalysis(esp_timer_get_time())) {
      controls.page=previous;syncNavigation();dirty=true;return;
    }
    analysis.clear();launchFeedback.clear();dirty=true;
  }
  if(previous==Controls::Page::Wipe && controls.page!=previous)wipeConfirmation.cancel();
  if(previous!=controls.page || effect==Controls::Effect::Recap || effect==Controls::Effect::Tournament)bestEffect.clear();
  if((previous==Controls::Page::Main || previous==Controls::Page::BeybladeX) && controls.page!=previous)launchFeedback.clear();
  if(previous!=controls.page){diagnostics=false;motionDemo=false;demo=false;historyOffset=0;}
  switch(effect) {
    case Controls::Effect::AnalysisReplay:
      analysis.toggleReplay(esp_timer_get_time());dirty=true;break;
    case Controls::Effect::AnalysisStop:
      if(analysis.stop(esp_timer_get_time())){captureStoppedCalibration();inactivity.touch(millis());dirty=true;}
      else if(calibrationCapturePending){captureStoppedCalibration();dirty=true;}
      else if(analysis.nextResult()){inactivity.touch(millis());dirty=true;}
      break;
    case Controls::Effect::Recap:toggleFeedback();break;
    case Controls::Effect::BeginEdit:
      settingsSaveError=false;
      controls.draft=settingValue(controls.setting);
      if(controls.setting==unsigned(Controls::Setting::BestEffect))previewEffect();
      break;
    case Controls::Effect::Preview:settingsSaveError=false;previewSetting();
      if(controls.setting==unsigned(Controls::Setting::BestEffect))previewEffect();
      if(controls.setting==unsigned(Controls::Setting::Sound))previewSound();
      break;
    case Controls::Effect::Apply:commitSetting();break;
    case Controls::Effect::CancelEdit:cancelSettingEdit();break;
    case Controls::Effect::Older:browseOlder();break;
    case Controls::Effect::NewSession:newSession();break;
    case Controls::Effect::Tournament:
      if(previous==Controls::Page::Tournament && controls.page==previous)
        tournamentView=TournamentView((unsigned(tournamentView)+1)%2);
      else if(controls.page==Controls::Page::Tournament)tournamentView=TournamentView::RecordingOnly;
      launchFeedback.clear();tournamentHintUntil=millis()+2500;
      Serial.printf("TOURNAMENT_CHANGE enabled=%d display=%s\n",controls.page==Controls::Page::Tournament,tournamentViewName());
      break;
    case Controls::Effect::BeginWipe:beginWipe();break;
    case Controls::Effect::ConfirmWipe:if(wipeConfirmation.confirm(millis()))dirty=true;break;
    case Controls::Effect::CancelWipe:cancelWipe();break;
    case Controls::Effect::ForgetPhones:BleLink::forget();settingsSave.mark(SettingsSave::Bonds);break;
    case Controls::Effect::ToggleBluetooth:bluetoothOn=!bluetoothOn;settingsSave.mark(SettingsSave::Bluetooth);dirty=true;break;
    case Controls::Effect::ToggleBattles:
      battlesOn=!battlesOn;settingsSave.mark(SettingsSave::Battles);dirty=true;
      Serial.printf("BATTLES_SETTING on=%d match_to=%u\n",battlesOn,unsigned(battleMatchTo));
      break;
    case Controls::Effect::ToggleMatchLength:
      battleMatchTo=battleMatchTo==Battle::MATCH_LONG?Battle::MATCH_SHORT:Battle::MATCH_LONG;settingsSave.mark(SettingsSave::Battles);dirty=true;
      Serial.printf("BATTLES_SETTING on=%d match_to=%u\n",battlesOn,unsigned(battleMatchTo));
      break;
    case Controls::Effect::None:break;
  }
  syncNavigation();
}
// While a battle card is up, A and B (and hold B) are the battle's, and hold
// A does nothing: a battle is not the moment to enter tournament mode.
static void buttonA(){if(BattleFeed::press(Battle::Button::A))return;const auto p=controls.page;const auto e=controls.tapA();navigate(e,p);}
static void buttonB(){if(BattleFeed::press(Battle::Button::B))return;const auto p=controls.page;const auto e=controls.tapB();navigate(e,p);}
LOOP_HELPER static void holdA(){if(BattleFeed::cardShown())return;const auto p=controls.page;const auto e=controls.holdA(launchFeedback.shown());navigate(e,p);}
LOOP_HELPER static void holdB(){if(BattleFeed::press(Battle::Button::HoldB))return;const auto p=controls.page;const auto e=controls.holdB(launchFeedback.shown());navigate(e,p);}
static void beginWipe() {
  restoreRx.cancel();
  wipeFailed=false;wipeConfirmation.begin(millis());
  controls.page=Controls::Page::Wipe;controls.setting=unsigned(Controls::Setting::WipeAll);
  gestureA.consumed=gestureB.consumed=true;
  syncNavigation();
}
static void cancelWipe() {
  wipeConfirmation.cancel();
  // After an erase attempt, old RAM must never be saved back into storage.
  controls.page=wipeBlocked?Controls::Page::Wipe:Controls::Page::Settings;
  controls.setting=unsigned(Controls::Setting::WipeAll);
  gestureA.consumed=gestureB.consumed=true;
  syncNavigation();
}
LOOP_HELPER static void restartAfterWipe() {
  if(wipeRestartRequested)return;
  wipeRestartRequested=true;sleepReceipt.magic=0;
  Serial.println("WIPE_RESTART");UsbTx::drain(200);delay(150);ESP.restart();
}
LOOP_HELPER static void commitWipe(const Snapshot &s) {
  // Only pollWipe's fresh physical three-second hold calls this function.
  // An active capture or newly started optical burst cannot cross the erase.
  if(!wipeCheckpointHeld && !wipeBootRecovery) {
    if(motionPending || !acquisition.request(Action::IdleCheckpointBegin,s.launches)) {
      wipeFailed=true;wipeConfirmation.begin(millis());dirty=true;
      Serial.println("WIPE_DEFERRED wait_until_idle");return;
    }
    wipeCheckpointHeld=true;
  }
  wipeBlocked=true; // Set before the first write; retained on every failure.
  soundPlayer.stop();soundRequest={};celebrationSound=soundPreview=false;
  bestEffect.clear();editorEffect.clear();launchFeedback.clear();
  restoreRx.cancel();
  startMarks.clear(uint8_t(sensorProfile));startMarksDirty=false;  // the wipe takes its key too
  DeviceWipe::NvsStore store;
  wipeComplete=DeviceWipe::begin(store)==DeviceWipe::Result::Complete;
  wipeFailed=!wipeComplete;wipeConfirmation.cancel();dirty=true;
  Serial.println(wipeComplete?"WIPE_OK release_buttons_to_restart":"WIPE_ERROR retry_or_restart_no_normal_saves");
  // Keep the ADC checkpoint held. Success restarts on button release; a
  // partial wipe may only retry/reboot, never resume ordinary RAM saves.
}
LOOP_HELPER static void pollWipe(uint32_t now,bool buttonsFresh,const Snapshot &s) {
  if(controls.page!=Controls::Page::Wipe)return;
  const bool aDown=M5.BtnA.isPressed(),bDown=M5.BtnB.isPressed();
  if(wipeComplete) {
    if(buttonsFresh && !aDown && !bDown)restartAfterWipe();
    return;
  }
  const bool clickedA=buttonsFresh && gestureA.click(M5.BtnA.wasPressed(),M5.BtnA.wasHold(),M5.BtnA.wasClicked());
  const bool clickedB=buttonsFresh && gestureB.click(M5.BtnB.wasPressed(),M5.BtnB.wasHold(),M5.BtnB.wasClicked());
  // Launches defer screen redraws. Do not accept an unseen warning or count a
  // hold while the display is frozen; require a new press after measurement.
  const bool measuring=s.phase==AnalogTachometer::Phase::Launch;
  if(measuring)gestureA.consumed=true;
  const bool wasConfirming=wipeConfirmation.active();
  if(wipeConfirmation.tick(now,aDown,bDown,buttonsFresh && !measuring)) {commitWipe(s);return;}
  if(!wipeConfirmation.active()) {
    if(wasConfirming){cancelWipe();return;}
    if(!wipeBlocked){cancelWipe();return;}
    if(clickedA)beginWipe();
    else if(clickedB)restartAfterWipe();
    return;
  }
  if(clickedA && !measuring)buttonA();
  else if(clickedB)cancelWipe();
  if(now-lastDraw>=50)dirty=true;
}
LOOP_HELPER static bool recoverWipe() {
  DeviceWipe::NvsStore store;
  const auto state=DeviceWipe::inspect(store);
  if(state==DeviceWipe::State::Clean)return true;
  if(state==DeviceWipe::State::Pending && DeviceWipe::resume(store)==DeviceWipe::Result::Complete) {
    sleepReceipt.magic=0;Serial.println("WIPE_BOOT completed_pending_erase");return true;
  }
  // No old settings/history are loaded and no acquisition task is started.
  // An invalid marker is not permission to erase; the physical flow must run.
  wipeBlocked=wipeBootRecovery=wipeFailed=true;
  controls.page=Controls::Page::Wipe;controls.setting=unsigned(Controls::Setting::WipeAll);
  M5.Display.setRotation(DisplayOrientation::rotation(false));M5.Display.setBrightness(102);M5.Display.setTextSize(1);
  M5.BtnA.setHoldThresh(1000);M5.BtnB.setHoldThresh(1000);
  syncNavigation();Serial.println("WIPE_BOOT_ERROR normal_load_and_saves_blocked");return false;
}
LOOP_HELPER static void previewHistory() {
  if(controls.page==Controls::Page::Analysis){leaveMicPage();if(controls.page==Controls::Page::Analysis)return;}
  bestEffect.clear();
  demo=!demo;diagnostics=false;historyPage=demo;historyView=PracticeUI::View::Recent;historyOffset=0;
  if(demo && !demoPractice.size()) {
    uint32_t count=0;
    for(unsigned session=0;session<18;++session) {
      demoPractice.newSession();
      for(unsigned i=0;i<12;++i) {
        const float rpm=4200+session*130+float(int(i%5)-2)*260+i*35;
        demoPractice.accept(++count,true,rpm,session*900000+i*20000);
      }
    }
  }
  Serial.printf("HISTORY_DEMO enabled=%d synthetic display only; saved history unchanged\n",demo);dirty=true;
}
LOOP_HELPER static void exportHistory() {
  Serial.printf("HISTORY_EXPORT records=%u sessions=%u metric=peak_rpm order=oldest_first\n",practice.size(),practice.sessions());
  for(unsigned i=practice.size();i>0;--i) {
    const auto &r=*practice.recent(i-1);
    Serial.printf("HISTORY_LAUNCH number=%lu session=%lu rpm=%.3f session_seconds=%lu\n",
      (unsigned long)r.number,(unsigned long)r.session,r.rpm,(unsigned long)r.seconds);
  }
  for(unsigned i=practice.sessions();i>0;--i) {
    const auto &s=*practice.session(i-1);
    Serial.printf("HISTORY_SESSION number=%lu pulls=%lu average_rpm=%.3f best_rpm=%.3f seconds=%lu\n",
      (unsigned long)s.number,(unsigned long)s.count,s.mean(),s.best,(unsigned long)s.seconds);
  }
}
// History and bests newer than their saved copy: the log's when it is open, else NVS's.
static bool historyUnsaved(){return historyLog.isOpen()?practice.generation()!=loggedHistory:practiceStore.pending(practice);}
static bool bestsUnsaved(){return historyLog.isOpen()?personalBests.generation()!=loggedBests:bestStore.pending(personalBests);}
static bool logHistory() {
#if LAUNCHLAB_HIL
  if(Hil::nvsWrite("history",PracticeHistory::IMAGE_BYTES))return false;
#endif
  if(!historyLog.saveHistory(practice,practiceStore.savedGeneration()))return false;
  loggedHistory=practice.generation();return true;
}
static bool logBests() {
#if LAUNCHLAB_HIL
  if(Hil::nvsWrite("best",32))return false;
#endif
  if(!historyLog.saveBests(personalBests,bestStore.savedGeneration()))return false;
  loggedBests=personalBests.generation();return true;
}
// The battle records, kept in the log alone: without the log (another layout
// in its partition) they last until the stick sleeps.
static bool rivalsUnsaved(){return historyLog.isOpen() && rivals.generation()!=loggedRivals;}
static bool logRivals() {
#if LAUNCHLAB_HIL
  if(Hil::nvsWrite("rivals",Battle::Book::IMAGE_BYTES))return false;
#endif
  if(!historyLog.saveRivals(rivals))return false;
  loggedRivals=rivals.generation();return true;
}
// At boot, newest wins between the log and NVS (history_log.h); a copy only
// in NVS is logged at the next save. A record NVS lost behind this firmware's
// back (Wipe all on 0.15-0.17) is not loaded, and the empty one is logged over
// it at once, so neither this firmware nor a rollback to 0.18-0.20.10 loads it.
static struct {HistoryLog::Source history=HistoryLog::Source::None,bests=HistoryLog::Source::None,power=HistoryLog::Source::None;bool nvsLost=false;} bootFrom;
// NVS without a single namespace: erased since anything used it, as the
// Arduino core erases it at boot after NO_FREE_PAGES or NEW_VERSION_FOUND. An
// old firmware's Wipe all leaves its namespaces (history_log.h).
static bool nvsVirgin(){nvs_stats_t stats{};return nvs_get_stats(nullptr,&stats)==ESP_OK && stats.namespace_count==0;}
// Lost, not wiped: the log's records stop saying NVS held their copies, so
// they load. Before anything creates a namespace, so a power cut here leaves
// NVS virgin and the next boot does it again.
static void disownLostNvs(bool virgin) {
  bootFrom.nvsLost=virgin;
  if(virgin && historyLog.isOpen())Serial.printf("HISTORY_LOG_NVS_LOST disowned=%d\n",historyLog.disown());
}
static void pickLoggedPower(HistoryLog::Nvs nvs) {
  std::unique_ptr<PowerDiagnostics::Image> logged(new(std::nothrow) PowerDiagnostics::Image);uint32_t mirrored=0;
  const bool inLog=logged && historyLog.isOpen() && historyLog.loadPower(*logged,mirrored);
  bootFrom.power=HistoryLog::pick(inLog,mirrored,nvs,powerMirror);
  if(bootFrom.power==HistoryLog::Source::Log)powerLog=*logged;
  else if(bootFrom.power==HistoryLog::Source::None && inLog){powerLog.checksum=PowerDiagnostics::hash(powerLog);historyLog.savePower(powerLog,powerMirror);}
}
static void pickLoggedBests(bool bestsInNvs) {
  Appearance::Bests logged;uint32_t mirrored=0;const bool inLog=historyLog.isOpen() && historyLog.loadBests(logged,mirrored);
  const auto nvs=bestsInNvs?HistoryLog::Nvs::Found:bestStore.ready() && !bestStore.present()?HistoryLog::Nvs::Absent:HistoryLog::Nvs::Unreadable;
  const auto from=bootFrom.bests=HistoryLog::pick(inLog,mirrored,nvs,personalBests.generation());
  if(from==HistoryLog::Source::Log)personalBests=logged;
  loggedBests=from==HistoryLog::Source::Log?personalBests.generation():~personalBests.generation();
  if(from==HistoryLog::Source::None && inLog && historyLog.saveBests(personalBests,bestStore.savedGeneration()))loggedBests=personalBests.generation();
}
static void pickLoggedHistory() {
  if(!historyLog.isOpen())return;
  std::unique_ptr<PracticeHistory> logged(new(std::nothrow) PracticeHistory);uint32_t mirrored=0;
  const bool inLog=logged && historyLog.loadHistory(*logged,mirrored);
  const auto nvs=practiceStore.found()?HistoryLog::Nvs::Found:practiceStore.ready()?HistoryLog::Nvs::Absent:HistoryLog::Nvs::Unreadable;
  const auto from=bootFrom.history=HistoryLog::pick(inLog,mirrored,nvs,practiceStore.savedGeneration());
  if(from==HistoryLog::Source::Log){practice=*logged;saveError=false;}
  loggedHistory=from==HistoryLog::Source::Log?practice.generation():~practice.generation();
  if(from==HistoryLog::Source::None && inLog && historyLog.saveHistory(practice,practiceStore.savedGeneration()))loggedHistory=practice.generation();
  Serial.printf("HISTORY_LOG_LOAD from=%s log_generation=%lu mirrored=%lu nvs_generation=%lu nvs_found=%d bests_from=%s power_from=%s nvs_lost=%d\n",
    HistoryLog::name(from),inLog?(unsigned long)logged->generation():0ul,(unsigned long)mirrored,(unsigned long)practiceStore.savedGeneration(),
    practiceStore.found(),HistoryLog::name(bootFrom.bests),HistoryLog::name(bootFrom.power),bootFrom.nvsLost);
}
// At boot, before sampling starts: the first boot of 0.18 formats the
// partition (blank, erased or another firmware's bytes) in under a second.
static void openHistoryLog() {
  if(!spiffsFlash.begin()){Serial.println("HISTORY_LOG_BOOT state=no_partition");return;}
  const int64_t started=esp_timer_get_time();
  using Open=HistoryLog::Store<SpiffsFlash>::Log::Open;
  const auto opened=historyLog.open(spiffsFlash);
  Serial.printf("HISTORY_LOG_BOOT state=%s ready_sectors=%u us=%lld\n",opened==Open::Ready?"ready":opened==Open::Formatted?"formatted":
    opened==Open::Unsupported?"unsupported_layout":"failed",historyLog.isOpen()?historyLog.log().readyCount():0u,
    (long long)(esp_timer_get_time()-started));
}
// A loaded effect's own sound, for the speaker: rendered by the store's
// engine from its own copy of the file.
struct LoadedSoundSource:BestEffectSpeaker::LoadedSounds {
  bool sound(unsigned effect,uint32_t &key,size_t &samples) override{return loadedEffects && loadedEffects->soundOf(effect,key,samples);}
  bool begin(unsigned effect) override{return loadedEffects && loadedEffects->beginSound(effect);}
  size_t run(int16_t *out,size_t count) override{return loadedEffects?loadedEffects->renderSound(out,count):0;}
  bool song(unsigned effect) override{return loadedEffects && loadedEffects->songOf(effect);}
  bool readSong(unsigned effect,const uint8_t *&file,size_t &bytes) override{return loadedEffects && loadedEffects->readSong(effect,file,bytes);}
};
static LoadedSoundSource loadedSounds;
// Songs (engine level 2) stream from a task on core 0 at priority 1, below
// the optical ADC owner and the IMU, so it renders only in core 0's idle
// time; it sleeps until a song starts. Its file copy, renderer and ring
// are in PSRAM.
static Music *music=nullptr;
static constexpr uint32_t MUSIC_STACK=3584;
static void musicTask(void *) {
  // A block a step, then the sleep step() asks for (at least 1 ms, keeping
  // the task under Music::DUTY_PERCENT of core 0); with nothing to render it
  // waits for play() to wake it.
  for(;;) {
    const uint32_t ms=music->step([]{return uint32_t(esp_timer_get_time());});
    if(ms)vTaskDelay(pdMS_TO_TICKS(ms));
    else ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(250));
  }
}
LOOP_HELPER static void startMusic() {
  void *space=heap_caps_malloc(sizeof(Music::Space),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  void *memory=heap_caps_malloc(sizeof(Music),MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT);
  TaskHandle_t task=nullptr;
  if(space && memory) {
    music=new(memory) Music(new(space) Music::Space());
    // Internal RAM: 2,016 bytes at its deepest over the three example songs
    // (every voice type; HIL songs run, 2026-10-23), plus a 1.5 KB margin.
    if(xTaskCreatePinnedToCore(musicTask,"music",MUSIC_STACK,nullptr,1,&task,0)==pdPASS){soundPlayer.attachMusic(music,task);return;}
  }
  heap_caps_free(space);heap_caps_free(memory);music=nullptr;
  Serial.println("MUSIC_BOOT state=no_memory");
}
// After the ADC has its DMA memory: the runtime, the file buffers and the
// sound renderer from PSRAM; the playing file's hot 4 KB from the internal
// heap on the first added-effect play, so a unit without added effects keeps
// all its DMA-capable memory (0.19 first took 10.5 KB of it at boot).
// The store reads every installed effect once (a few ms each).
static void openLoadedEffects() {
  if(!spiffsFlash.partition){Serial.println("FX_STORE_BOOT state=no_partition");return;}
  using Loaded=LoadedEffects<SpiffsFlash>;
  void *memory=heap_caps_malloc(sizeof(Loaded),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  auto *file=static_cast<uint8_t *>(heap_caps_malloc(Loaded::Store::MAX_PAYLOAD,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!memory || !file){heap_caps_free(memory);heap_caps_free(file);Serial.println("FX_STORE_BOOT state=no_memory");return;}
  // The sound's file copy and renderer go to PSRAM too; without them loaded
  // effects sound as their stock fallbacks.
  auto *soundFile=static_cast<uint8_t *>(heap_caps_malloc(Loaded::Store::MAX_PAYLOAD,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  void *soundMemory=heap_caps_malloc(sizeof(Loaded::SoundSpace),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  Loaded::SoundSpace *sound=soundMemory?new(soundMemory) Loaded::SoundSpace():nullptr;
  if(!soundFile || !sound){heap_caps_free(soundFile);heap_caps_free(soundMemory);soundFile=nullptr;sound=nullptr;Serial.println("FX_STORE_BOOT sound=no_memory");}
  const Loaded::HotMemory hot=[]{return static_cast<uint8_t *>(heap_caps_malloc(LoadableFx::HOT_BYTES,MALLOC_CAP_INTERNAL|MALLOC_CAP_32BIT));};
  loadedEffects=new(memory) Loaded(bestEffectRenderer,file,Loaded::Store::MAX_PAYLOAD,hot,soundFile,sound);
  soundPlayer.attach(&loadedSounds);
  startMusic();
  const int64_t started=esp_timer_get_time();
  using Open=Loaded::Store::Open;
  const auto opened=loadedEffects->begin(spiffsFlash);
  Serial.printf("FX_STORE_BOOT state=%s installed=%u us=%lld\n",opened==Open::Ready?"ready":opened==Open::Unformatted?"unformatted":
    opened==Open::Unsupported?"unsupported_layout":"failed",loadedEffects->store().installed(),(long long)(esp_timer_get_time()-started));
}
// The 9 ms guard of a loaded effect's pass, timed from effectGuardStart.
static bool effectOverBudget(void *){return esp_timer_get_time()-effectGuardStart>9000;}
// A celebration's frame: a loaded effect through the engine, held to 9 ms a
// pass by the guard and given up for the clean recap after three stopped
// frames in a play (FX_OVERRUN); a loaded effect that cannot play here draws
// its stock fallback; a built-in through its renderer.
LOOP_HELPER static void drawEffect(Appearance::Effect e,uint32_t elapsed,const BestEffectUI::Renderer::Anchor &anchor,const Palette::Colors &colors) {
  const BestEffectUI::Surface surface{static_cast<uint16_t *>(screen.getBuffer()),screen.width(),screen.height()};
  if(Appearance::loaded(unsigned(e))) {
    LoadableFx::Guard guard;guard.expired=effectOverBudget;effectGuardStart=esp_timer_get_time();
    if(loadedEffects && loadedEffects->draw(surface,unsigned(e),elapsed,colors.accent,anchor,colors.background,guard)) {
      if(loadedEffects->overran())Serial.printf("FX_OVERRUN id=%u elapsed=%lu\n",unsigned(e),(unsigned long)elapsed);
      return;
    }
    e=Appearance::stockFallback(e);
  }
  bestEffectRenderer.draw(surface,e,elapsed,colors.accent,anchor,colors.background);
}
// At most one sector erase (14-30 ms, the ADC rides it) a second while
// nothing is being measured, so a save never has to erase.
LOOP_HELPER static void tickHistoryLog(uint32_t now,const Snapshot &s) {
  static uint32_t lastErase=0;
  if(!historyLog.isOpen() || now-lastErase<1000 || s.suspended || motionPending ||
     (s.phase!=AnalogTachometer::Phase::Ready && s.phase!=AnalogTachometer::Phase::Paused))return;
  lastErase=now;historyLog.readyAhead();
}
LOOP_HELPER static void saveHistory(uint32_t now,const Snapshot &s) {
  const bool logged=historyLog.isOpen();
  const bool history=logged?historyUnsaved():practiceStore.pending(practice) && practiceStore.ready();
  const bool best=logged?bestsUnsaved():bestStore.pending(personalBests) && bestStore.ready();
  // Failed writes must leave enough uninterrupted quiet for detector rearm.
  const uint32_t retryMs=saveError?HISTORY_SAVE_RETRY_MS:1000;
  // A sensor fault (signal held on the low rail) keeps the detector in Hold
  // until the signal returns, and nothing can be measured meanwhile, as when
  // Paused. Flush through an idle checkpoint rather than keep pulls in RAM.
  const bool fault=s.signalFault && s.phase==AnalogTachometer::Phase::Hold;
  if((!history && !best) || now-lastSaveTry<retryMs ||
     !HistoryCheckpoint::practiceIdle(now,lastAcceptedAt,
       fault?HISTORY_COALESCE_MS:HistoryCheckpoint::automaticQuietMs(now,imuStill,historyPendingSince?now-historyPendingSince:0,
         HISTORY_COALESCE_MS),motionPending,launchFeedback.protects(now),
       fault?AnalogTachometer::Phase::Paused:s.phase))return;
  // Coalesce a rapid practice bout instead of resetting fusion after each pull.
  // Pending RAM history is flushed once the newest accepted pull has been idle.
  // No maximum-age override: a long practice bout stays in RAM until quiet.
  // Automatic sleep still forces a verified flush before entering standby.
  lastSaveTry=now;
  if(logged) {
    // Program-only writes: the ADC keeps sampling, so a pull that starts now
    // is measured however long the write takes.
    const int64_t started=esp_timer_get_time();
    const bool saved=(!history || logHistory()) && (!best || logBests());
    maxSaveUs=std::max(maxSaveUs,uint32_t(esp_timer_get_time()-started));
    if(saved){++saveCount;saveError=false;historyPendingSince=0;}else {++saveErrors;saveError=true;}
    lastSaveTry=millis();
    Serial.printf("HISTORY_SAVE ok=%d generation=%lu duration_us=%lu store=log\n",saved,
      (unsigned long)practice.generation(),(unsigned long)(esp_timer_get_time()-started));
    dirty=true;return;
  }
  if(!acquisition.request(fault?Action::IdleCheckpointBegin:Action::HistoryIdleCheckpointBegin,s.launches))return;
  const int64_t started=esp_timer_get_time();
  const bool saved=(!history || practiceStore.save(practice)) && (!best || bestStore.save(personalBests));
  maxSaveUs=std::max(maxSaveUs,uint32_t(esp_timer_get_time()-started));
  if(saved){++saveCount;saveError=false;historyPendingSince=0;}else {++saveErrors;saveError=true;}
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("HISTORY_ERROR ADC checkpoint resume failed");
  lastSaveTry=millis();
  Serial.printf("HISTORY_SAVE ok=%d generation=%lu duration_us=%lu\n",saved,
    (unsigned long)practice.generation(),(unsigned long)(esp_timer_get_time()-started));
  dirty=true;
}

// A changed battle record goes to the log in the same kind of pause history
// waits for: no capture, no recap on screen, the detector ready, and a few
// seconds since the pull. A program-only write of under a kilobyte: the ADC
// keeps sampling, so a pull that starts now is measured.
LOOP_HELPER static void saveRivals(uint32_t now,const Snapshot &s) {
  static uint32_t lastTry=0;static bool tried=false;
  if(!rivalsUnsaved() || (tried && now-lastTry<HISTORY_SAVE_RETRY_MS) ||
     !HistoryCheckpoint::practiceIdle(now,lastAcceptedAt,HistoryCheckpoint::AGED_QUIET_MS,motionPending,launchFeedback.protects(now),s.phase))return;
  tried=true;lastTry=now;
  const int64_t started=esp_timer_get_time();
  const bool saved=logRivals();
  Serial.printf("BATTLE_SAVE ok=%d generation=%lu rivals=%u duration_us=%lu\n",saved,(unsigned long)rivals.generation(),rivals.count(),
    (unsigned long)(esp_timer_get_time()-started));
  if(saved)tried=false;
}
// Each launch event, from the loop or drained by the shutdown flush: one owner,
// so the two cannot differ (through 0.20.10 the flush saved a Wear check
// retraction as a practice pull, with no USB lines). A new result goes to Wear
// check on its page, never to practice history, bests, motion capture or the
// start-mark reference; elsewhere to practice history. Both print their USB
// lines and reach the mic. celebrate: false only when the unit goes dark next
// (the side key's off, the Bluetooth restart; flushForShutdown): the pull is
// saved, captured and may set a best like any other, but starts no effect or
// sound. A pull the inactivity sleep's flush takes abandons the sleep, so it
// celebrates as in the loop. True: a new pull was taken.
LOOP_HELPER static bool routeEvent(const Snapshot &event,uint32_t now,bool celebrate) {
  bool taken=false;
  // A result Min RPM kept back: no new revision, only its USB line.
  if(event.belowMin!=lastBelowMin) {
    lastBelowMin=event.belowMin;
    Serial.printf("LAUNCH_BELOW_MIN rpm=%.1f min_rpm=%.0f count=%lu t_us=%llu\n",event.belowMinRpm,event.minRpm,
      (unsigned long)event.belowMin,(unsigned long long)event.detectorUs);
  }
  if(event.revision!=lastRevision) {
    lastRevision=event.revision;
    Serial.printf("LAUNCH_RESULT valid=%d peak_rpm=%.1f revs=%lu amplitude=%.1f start_noise=%.1f launches=%lu end=%s t_us=%llu\n",
      event.valid,event.resultRpm,(unsigned long)event.revolutions,event.amplitude,event.startNoise,
      (unsigned long)event.launches,event.endName(),(unsigned long long)event.detectorUs);
    followAnalysisLaunch(event);
    if(controls.page==Controls::Page::WearCheck) {
      const auto stageBefore=controls.wear.stage();
      const auto stepBefore=controls.wear.step();
      const auto outcome=controls.wear.observeBurst(event.launches,event.valid,event.resultRpm,level.reading(now));
      if(outcome!=WearCheck::Outcome::None) {
        taken=true;
        logWearPull(stageBefore,outcome,event.resultRpm);
        if(controls.wear.step()!=stepBefore)
          Serial.printf("WEAR_CHECK_STEP step=%s t_us=%llu\n",WearCheck::stepName(controls.wear.step()),(unsigned long long)event.detectorUs);
        if(outcome==WearCheck::Outcome::Completed) {
          Serial.printf("WEAR_CHECK_RESULT rpm=%.1f median_rpm=%.1f level_rpm=%.1f pull_down_rpm=%.1f pull_up_rpm=%.1f pulls=%u tolerance_deg=%.0f baseline_rpm=%.1f\n",
            controls.wear.overallMean(),controls.wear.overallMedianMean(),
            controls.wear.stageMean(0),controls.wear.stageMean(1),controls.wear.stageMean(2),
            controls.wear.totalAccepted(),WearCheck::TOLERANCE_DEG,WearCheck::FRESH_BASELINE_RPM);
        }
      }
    } else if(practice.accept(event.launches,event.valid,event.resultRpm,now)) {
      taken=true;
      prepareMotion(event,celebrate);logLaunchMetrics(event);noteStartMark(event);
      inactivity.touch(now);
      Serial.printf("HISTORY_ADDED number=%lu session=%lu rpm=%.1f\n",(unsigned long)practice.recent()->number,
        (unsigned long)practice.recent()->session,practice.recent()->rpm);
    }
    dirty=true;
  }
  if(event.phase!=lastPhase || event.signalFault!=lastFault) {
    lastPhase=event.phase;lastFault=event.signalFault;dirty=true;
    Serial.printf("RPM_STATE state=%s t_us=%llu contrast=%.1f noise=%.1f\n",event.stateName(),
      (unsigned long long)event.detectorUs,event.contrast,event.noise);
  }
  return taken;
}

// Stops sampling, accepts queued pulls and saves history/bests before power
// down. Only Ready leaves acquisition stopped; otherwise sampling continues
// and the caller retries. A new pull is recorded but restarts the decision.
// why: a sleep or side-key off is held back by a refused save only
// ShutdownSaveGuard::LIMIT times in a row (a Bluetooth restart: always); a
// pull taken here celebrates only on the way to a sleep, which it abandons
// (the side key and the restart go dark next).
// force: stop even with optical marks pending (OpticalSleepGuard).
LOOP_HELPER static ShutdownFlush flushForShutdown(uint32_t now,const Snapshot &s,ShutdownWhy why,bool force=false) {
  const bool powerOff=why!=ShutdownWhy::Restart;
  if(!acquisition.request(force?Action::ShutdownForce:Action::ShutdownBegin,s.launches))return ShutdownFlush::Busy;
  // Finish any queued accepted result before saving; the owner is now stopped.
  Snapshot event;
  bool newPull=false;
#if LAUNCHLAB_HIL
  hilFlushPull.holding=false;  // what !flushpull held is drained here
#endif
  while(acquisition.takeEvent(event))if(routeEvent(event,now,why==ShutdownWhy::Sleep))newPull=true;
  if(newPull) {
    inactivity.touch(now);dirty=true;
    if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
    return ShutdownFlush::NewPull;
  }
  // Settings never hold up power-off: a failed write is logged, stays pending
  // and is retried if the device stays on.
  writeSettings();
  saveStartMarks();
  const bool historyFirst=practiceStore.savedGeneration()==HistoryLog::NOT_MIRRORED,bestFirst=bestStore.savedGeneration()==HistoryLog::NOT_MIRRORED;
  bool historyFailed=practiceStore.pending(practice) && (!practiceStore.ready() || !practiceStore.save(practice));
  bool bestFailed=bestStore.pending(personalBests) && (!bestStore.ready() || !bestStore.save(personalBests));
  // NVS's first copy, logged at once (history_log.h): the log's record said NVS held none.
  if(historyLog.isOpen()) {
    if(historyFirst && practiceStore.savedGeneration()!=HistoryLog::NOT_MIRRORED)logHistory();
    if(bestFirst && bestStore.savedGeneration()!=HistoryLog::NOT_MIRRORED)logBests();
  }
  // With the history log open, NVS holds only a copy of what the log holds.
  // A copy NVS refuses (full, as one StickS3 was) is retried at the next
  // sleep once the log has it; through 0.20.5 it deferred every sleep, every
  // minute, a drain until flat.
  if((historyFailed || bestFailed) && historyLog.isOpen()) {
    const bool historyLogged=!historyUnsaved() || logHistory(),bestLogged=!bestsUnsaved() || logBests();
    if(historyLogged && bestLogged) {
      ++saveErrors;
      Serial.printf("POWER_OFF_NOTICE nvs_copy_failed history=%d best=%d store=log\n",historyFailed,bestFailed);
      historyFailed=bestFailed=false;
    } else {historyFailed=!historyLogged;bestFailed=!bestLogged;}
  }
  const bool calibrationFailed=calibrationNeedsSave();
  if(historyFailed || bestFailed || calibrationFailed) {
    saveError=true;++saveErrors;dirty=true;lastSaveTry=millis();
    // No store takes it (the log closed, NVS refusing): through 0.20.10 every
    // sleep and side-key off deferred, until flat. A flat battery loses RAM
    // too, so the power-off goes ahead at the LIMIT-th refusal in a row, sampling stopped.
    if(powerOff && shutdownSaves.refused()) {
      Serial.printf("POWER_OFF_NOTICE %s_unsaved history=%d best=%d calibration=%d refusals=%u store=none\n",calibrationFailed?"calibration":historyFailed?"history":"best",
        historyFailed,bestFailed,calibrationFailed,unsigned(shutdownSaves.refusals()));
      return ShutdownFlush::Ready;
    }
    Serial.printf("POWER_OFF_DEFERRED %s_save_failed refusals=%u limit=%u\n",calibrationFailed?"calibration":historyFailed?"history":"best",
      unsigned(shutdownSaves.refusals()),unsigned(powerOff?ShutdownSaveGuard::LIMIT:0));
    if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
    return ShutdownFlush::SaveFailed;
  }
  if(powerOff)shutdownSaves.clear();
  historyPendingSince=0;saveError=false;
  // The battle records never hold up power-off: a failed write is logged and
  // the record stays as last saved.
  if(rivalsUnsaved() && !logRivals())Serial.println("POWER_OFF_NOTICE battle_save_failed");
  return ShutdownFlush::Ready;
}

// The USB-retained standby's timer re-check (shake_wake.h): on a charger
// only; with a computer attached the PM1 IRQ alone ends it.
static uint64_t standbyRecheckUs() {
#if LAUNCHLAB_HIL
  if(hilStandbyRecheckS)return uint64_t(hilStandbyRecheckS)*1000000;
#endif
  return usbAwake.sof() || usbAwake.remembered()?0:StickS3ShakeWake::USB_RECHECK_US;
}
#if LAUNCHLAB_HIL
// !sleepdry: the wake state the sleep set up, read back where it would have
// powered off (the caller holds the IMU/I2C gate): PM1's wake enables (0x18,
// GPIO4 = the IMU's interrupt), its hold (0x07, bit 5 holds the IMU supply)
// and the IMU's power control (bit 2 accelerometer, bit 1 gyroscope).
static void hilSleepDryReport(const SleepPlan &plan) {
  uint8_t wake=0xff,hold=0xff,imu=0xff,cfg=0xff;
  const bool ok=pm1Idle().read(0x18,&wake,1) && pm1Idle().read(0x07,&hold,1) && M5.In_I2C.readRegister(0x68,0x7D,&imu,1,400000) &&
    pm1Idle().read(0x06,&cfg,1);
  // pm1_cfg bit 4 is LED_EN (the green LED, off for standby from 0.20.6).
  Serial.printf("SLEEP_DRY_RUN ok=%d shake_wake=%d arm_imu=%d wake=%s mode=%s pm1_wake=0x%02x pm1_hold=0x%02x imu_power=0x%02x imu_wake_armed=%d pm1_cfg=0x%02x led=%d speaker_powered=%d\n",
    ok,shakeToWake,plan.armImu,plan.wake,plan.mode,wake,hold,imu,ok && (wake&0x18)==0x10 && (hold&0x60)==0x20,cfg,ok?int(bool(cfg&0x10)):-1,soundPlayer.powered());
}
#endif
LOOP_HELPER static void autoPowerOff(uint32_t now,const Snapshot &s) {
  if(wipeBlocked || controls.page==Controls::Page::Wipe)return;
#if LAUNCHLAB_POWER_LAB
  if(Lab::running)return;  // A lab run measures screen-on time: never sleep.
#endif
#if LAUNCHLAB_HIL
  if(!Hil::allowSleep.load())return;
  const bool dry=Hil::sleepDry.load();  // The rig's host is attached: never really sleep.
#else
  constexpr bool dry=false;
#endif
  if(usbAwake.inhibited(now) && !dry)return;
  if(controls.page==Controls::Page::Analysis && analysis.running())return;
  if(PhoneLinkAwake::holds(BleLink::connected(),inactivity.sinceUse(now)))return;
  const bool measuring=opticalGuard.measuring(now,s.phase==AnalogTachometer::Phase::Launch);
  if(!inactivity.due(now,measuring))opticalGuard.clear();
  if(motionPending || !inactivity.due(now,measuring) || (lastShutdownTry && now-lastShutdownTry<sleepLimit(60000)))return;
  // Recheck immediately at the timer boundary; periodic polling alone could
  // leave a just-attached computer unnoticed for up to 250ms.
  pollUsbAwake(now,s,true);
  if((usbAwake.inhibited(now) && !dry) || !inactivity.due(now,measuring))return;
  if(micListener.holdsSleep(now)){leaveMicPage();return;}
  if(!micListener.off())Serial.println("POWER_OFF_NOTICE mic_stop_timeout");
  lastShutdownTry=now;
  // A failed save retries after 60 s; a new pull restarts the full timeout.
  const bool force=opticalGuard.force();
  const auto flushed=flushForShutdown(now,s,ShutdownWhy::Sleep,force);
  if(flushed==ShutdownFlush::NewPull)lastShutdownTry=0;
  if(flushed==ShutdownFlush::Busy) {
    opticalGuard.refused();
    Serial.printf("POWER_OFF_DEFERRED optical_busy refusals=%u launch=%d force_next=%d retry_s=60\n",
      unsigned(opticalGuard.refusals()),s.phase==AnalogTachometer::Phase::Launch,opticalGuard.force());
  }
  if(flushed!=ShutdownFlush::Ready)return;
  opticalGuard.clear();
  // A host may attach while the forced history flush is blocking.
  pollUsbAwake(millis(),acquisition.snapshot(),true);
  if(usbAwake.inhibited(millis()) && !dry) {
    if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
    return;
  }
  Serial.printf("POWER_OFF reason=inactivity idle_ms=%lu since_use_ms=%lu records=%u saved=%d forced=%d\n",
    (unsigned long)inactivity.elapsed(now),(unsigned long)inactivity.sinceUse(now),practice.size(),!saveError,force);
  cancelSettingEdit(); // Wake into the settings list, never an unfinished edit.
  UsbTx::drain(200);
  soundPlayer.shutdown();  // Neither the amplifier nor the codec stays on through standby.
  if(imuAcquisition.lock()) {
    bool usbCancelled=false;
    // A carried unit is shaken awake again as soon as it sleeps: after
    // UnusedWakes::LIMIT shake wakes in a row that nobody used, this sleep is
    // for the side key alone. A count NVS refuses is only not kept.
    const uint8_t wakes=UnusedWakes::next(unusedWakes,inactivity.unusedShake());
    if(wakes!=unusedWakes) {
      if(prefs.putUChar(UnusedWakes::KEY,wakes)==1)unusedWakes=wakes;
      else Serial.println("POWER_OFF_NOTICE unused_wakes_save_failed");
    }
    const bool carried=shakeToWake && !UnusedWakes::armsShake(wakes);
    Serial.printf("UNUSED_WAKES count=%u limit=%u saved=%u shake_armed=%d\n",unsigned(wakes),unsigned(UnusedWakes::LIMIT),unsigned(unusedWakes),shakeToWake && !carried);
    // Shake to wake Off sleeps as the side key's power-off does: no IMU arm.
    auto plan=sleepPlan(shakeToWake && !carried);
    // An IMU that cannot be armed must not keep the unit awake (through 0.20.5
    // it retried every minute, forever): sleep for the side key alone.
    if(plan.armImu && !shakeWake.arm()) {
      plan=sleepPlan(false);
      const bool keyOnly=shakeWake.clear() && powerKey().configure();
      Serial.printf("SHAKE_WAKE_NOTICE arm_failed fallback=side_key ok=%d\n",keyOnly);
    }
    {
      const WakeUi::State state{tournamentMode,historyPage && !demo && !diagnostics,
        uint8_t(tournamentView),uint8_t(historyView)};
      // The wake markers only pick the page the unit wakes on. One NVS
      // refuses (full) leaves the unit to wake on Main instead: through
      // 0.20.5 it deferred every sleep, every minute.
      const bool marked=prefs.putUInt("wake_ui",WakeUi::encode(state))==sizeof(uint32_t) && saveWakeNavigation();
      if(!marked){prefs.remove("wake_ui");prefs.remove("wake_nav");Serial.println("POWER_OFF_NOTICE wake_mode_save_failed");}
      {
        // Keep the overwritten ring entry so a USB-cancelled attempt is not
        // counted or exported as an actual standby.
        const uint32_t previousPowerNext=powerLog.next,previousPowerCount=powerLog.count;
        const auto previousPowerRecord=powerLog.records[previousPowerNext];
        ++powerLog.sleeps;powerLog.pendingSleep=1;powerRecord(PowerDiagnostics::Sleep);
        if(!savePowerLog())Serial.println("POWER_LOG_NOTICE sleep_checkpoint_failed");
        sleepReceipt={PowerDiagnostics::MAGIC,wallUs()};
        M5.Display.setBrightness(0);M5.Display.sleep();
        Serial.printf("SHAKE_SLEEP timeout_s=%lu sensor_rail=L2_off_on_battery wake=%s mode=%s shake_wake=%d\n",(unsigned long)(inactivity.timeout()/1000),plan.wake,plan.mode,shakeToWake);UsbTx::drain(200);
        // Flash/USB flushing above can outlast the earlier host check. This
        // last O(1) SOF read is safe while holding the IMU mutex; do not call
        // pollUsbAwake here because it can attempt that mutex again.
        if(dry || HWCDC::isPlugged()) {
          usbCancelled=true;inactivity.touch(millis());lastShutdownTry=0;
          if(!dry){usbAwake.sampleHost(millis(),true);usbAutoOffInhibited=true;}
          --powerLog.sleeps;powerLog.next=previousPowerNext;powerLog.count=previousPowerCount;
          powerLog.records[previousPowerNext]=previousPowerRecord;powerLogDirty=true;
#if LAUNCHLAB_HIL
          if(dry)hilSleepDryReport(plan);
#endif
          Serial.println(dry?"POWER_OFF_DEFERRED sleep_dry_run":"POWER_OFF_DEFERRED usb_host_attached_before_sleep");
        } else {usbStandby={UsbStandby::MAGIC,!plan.armImu};shakeWake.sleep(standbyRecheckUs());usbStandby.magic=0;}
        sleepReceipt.magic=0;powerLog.pendingSleep=0;
        savePowerLog();
        M5.Display.wakeup();frameRows.invalidate();M5.Display.setBrightness(backlightValue());
        if(marked && !prefs.remove("wake_ui"))Serial.println("WAKE_UI_NOTICE failed_sleep_marker_clear");
        prefs.remove("wake_nav");
      }
    }
    const bool restored=shakeWake.restore();
    if(!restored)noteMotionRestoreFailure();
    const bool extRestored=pm1Idle().run([](){M5.Power.setExtOutput(extPower);return true;});
    imuAcquisition.unlock();
    if(!extRestored)Serial.println("EXT_POWER_NOTICE restore_wake_failed");
    Serial.printf("POWER_OFF_DEFERRED reason=%s restored=%d retry_s=%u\n",dry?"sleep_dry_run":usbCancelled?"usb_host_attached":"shake_sleep_failed",restored,usbCancelled?0:60);
  } else Serial.println("POWER_OFF_DEFERRED imu_bus_busy");
  if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
}

// The IRQ edge is latched by the ISR. The line level is rechecked at most
// once a second in case an edge was missed, so a stuck line cannot keep PM1
// out of its idle sleep with constant I2C reads.
LOOP_HELPER static void pollPowerKey(uint32_t now) {
  // PM1 holds its IRQ line low until the click is read and cleared, so the
  // level is enough; a line held low by anything else is read once a second.
  // No GPIO interrupt: ESP-IDF installs the GPIO ISR service on the 1 KB IPC
  // task, and an interrupt landing inside that allocation overflowed its stack
  // (0.21.0 gate: "Stack canary watchpoint triggered (ipc1)" at boot).
  if(digitalRead(POWER_KEY_IRQ_PIN) || now-lastPowerKeyRead<1000)return;
  if(!imuAcquisition.lock())return;
  lastPowerKeyRead=now;
  const bool click=powerKey().takeClick();
  imuAcquisition.unlock();
  if(!click || powerKeyRequested)return;
  powerKeyRequested=true;powerKeyRequestedAt=now;inactivity.touch(now);
  Serial.println("POWER_KEY click=1 action=power_off");
}

// A single click switches off like PM1's own double click, after saving.
// A measured burst or motion capture finishes first. Manual power-off stays
// manual: shake wake is not armed and the side key turns the unit back on.
LOOP_HELPER static void powerKeyOff(uint32_t now,const Snapshot &s) {
  if(!powerKeyRequested)return;
  if(wipeBlocked){powerKeyRequested=false;Serial.println("POWER_KEY_IGNORED wipe_in_progress");return;}
  // The burst being measured finishes first. Marks still there after
  // POWER_KEY_WAIT_MS are not a pull, so the off then stops sampling anyway
  // (through 0.20.5 it gave up, and steady marks kept the unit on).
  const bool late=now-powerKeyRequestedAt>=POWER_KEY_WAIT_MS;
  if(motionPending) {
    if(late){powerKeyRequested=false;Serial.println("POWER_KEY_OFF_DEFERRED motion_capture_busy");}
    return;
  }
  if(controls.page==Controls::Page::Analysis){leaveMicPage();if(controls.page==Controls::Page::Analysis)return;}
  if(micListener.holdsSleep(now)){leaveMicPage();return;}
  if(!micListener.off())Serial.println("POWER_OFF_NOTICE mic_stop_timeout");
  const auto flushed=flushForShutdown(now,s,ShutdownWhy::SideKey,late);
  if(flushed==ShutdownFlush::Busy || flushed==ShutdownFlush::NewPull) {
    if(late){powerKeyRequested=false;Serial.println("POWER_KEY_OFF_DEFERRED acquisition_busy");}
    return;
  }
  powerKeyRequested=false;
  if(flushed==ShutdownFlush::SaveFailed)return; // Stay on; the save error is shown.
  if(controls.page==Controls::Page::Wipe)cancelWipe();
  cancelSettingEdit();
  Serial.printf("POWER_OFF reason=power_key records=%u saved=%d forced=%d\n",practice.size(),!saveError,late);
  ++powerLog.sleeps;powerLog.pendingSleep=1;powerRecord(PowerDiagnostics::Sleep);
  if(!savePowerLog())Serial.println("POWER_LOG_NOTICE sleep_checkpoint_failed");
  sleepReceipt={PowerDiagnostics::MAGIC,wallUs()};
  M5.Display.setBrightness(0);M5.Display.sleep();UsbTx::drain(200);
  soundPlayer.shutdown();
  // PM1 removes battery power. USB can keep the ESP32 powered, so it deep
  // sleeps until the next click asserts the IRQ line; the IMU is not armed.
  if(imuAcquisition.lock()){usbStandby={UsbStandby::MAGIC,true};shakeWake.sleep(standbyRecheckUs());usbStandby.magic=0;imuAcquisition.unlock();}
  sleepReceipt.magic=0;powerLog.pendingSleep=0;savePowerLog();
  M5.Display.wakeup();frameRows.invalidate();M5.Display.setBrightness(backlightValue());dirty=true;
  Serial.println("POWER_KEY_OFF_FAILED pm1_power_off_refused");
  if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
}

// The blocked Wipe page's power-off (power_status.h WipeBlockedPower): the
// side key, or IDLE_MS without a button. It writes nothing, neither history,
// settings nor the power log, because after an erase attempt RAM from before
// it must never be saved (docs/FIRMWARE_WIPE_ALL.md): it is the page's
// restart, left off. The next boot resumes a valid marker or blocks again.
static WipeBlockedPower wipePower;
LOOP_HELPER static void wipeBlockedPowerOff(uint32_t now) {
#if LAUNCHLAB_HIL
  const bool dry=Hil::sleepDry.load(),allowed=Hil::allowSleep.load();  // The rig's host is attached.
#else
  constexpr bool dry=false,allowed=true;
#endif
  const auto off=wipePower.decide(now,powerKeyRequested,inactivity.sinceUse(now),!dry && HWCDC::isPlugged());
  powerKeyRequested=false;
  if(off==WipeBlockedPower::Off::Stay || (off==WipeBlockedPower::Off::Idle && !allowed))return;
  wipePower.tried(now);
  Serial.printf("POWER_OFF reason=%s wipe_blocked=1 boot_recovery=%d since_use_ms=%lu saved=0\n",WipeBlockedPower::name(off),
    wipeBootRecovery,(unsigned long)inactivity.sinceUse(now));
  if(dry){Serial.println("POWER_OFF_DEFERRED reason=sleep_dry_run wipe_blocked=1 retry_s=60");return;}
  M5.Display.setBrightness(0);M5.Display.sleep();UsbTx::drain(200);
  soundPlayer.shutdown();
  // As the side key's own off: PM1 removes battery power; on USB the ESP32
  // deep sleeps until the key (or the re-check). The IMU is not armed.
  if(imuAcquisition.lock()){usbStandby={UsbStandby::MAGIC,true};shakeWake.sleep(standbyRecheckUs());usbStandby.magic=0;imuAcquisition.unlock();}
  M5.Display.wakeup();frameRows.invalidate();M5.Display.setBrightness(backlightValue());dirty=true;
  Serial.println("POWER_OFF_DEFERRED reason=pm1_power_off_refused wipe_blocked=1 retry_s=60");
}

// Bluetooth changed in Settings: apply it by restarting, after what a power-off
// saves. Never in a pull or its capture, and not until the choice itself is saved.
LOOP_HELPER static void restartForBluetooth(uint32_t now,const Snapshot &s) {
  static uint32_t lastTry=0;
  if(!BluetoothSetting::restartNeeded(bluetoothOn,bluetoothAtBoot) || wipeBlocked ||
     controls.page==Controls::Page::Edit || controls.page==Controls::Page::Wipe ||
     s.phase==AnalogTachometer::Phase::Launch || motionPending || now-lastTry<1000 || !BleLink::replyFlushed(now))return;
  lastTry=now;
  // A remote Bluetooth change can request a restart during Analysis. Capture
  // its unknown endpoint before shutdown checkpoints or mic buffer teardown.
  if(controls.page==Controls::Page::Analysis){leaveMicPage();if(controls.page==Controls::Page::Analysis)return;}
  if(micListener.holdsSleep(now)){leaveMicPage();return;}
  if(flushForShutdown(now,s,ShutdownWhy::Restart)!=ShutdownFlush::Ready)return;
  if(settingsSave.pending()&SettingsSave::Bluetooth) {
    if(!acquisition.request(Action::CheckpointEnd))acquisition.request(Action::Pin,s.pin);
    return;
  }
  if(!savePowerLog())Serial.println("POWER_LOG_NOTICE restart_checkpoint_failed");
  Serial.printf("BLUETOOTH_RESTART on=%d records=%u saved=1\n",bluetoothOn,practice.size());
  UsbTx::drain(200);delay(150);ESP.restart();
}

// USB backup: everything a player would miss, read from RAM so pulls not yet
// flushed are included. Lines are BACKUP_DATA base64; the host checks the
// checksum inside the container.
// The installed loaded effects' files and sources, read into one PSRAM block
// the backup points at (format 7); the block is the caller's to free.
static uint8_t *readLoadedForBackup(DeviceBackup::Contents &c) {
  c.loadedCount=0;
  if(!loadedEffects || !loadedEffects->store().installed())return nullptr;
  const auto &store=loadedEffects->store();size_t total=0;
  for(unsigned slot=0;slot<Appearance::LOADED;++slot)if(loadedEffects->info(slot).playable)total+=store.entry(slot).fileBytes+store.entry(slot).sourceBytes;
  auto *block=static_cast<uint8_t *>(heap_caps_malloc(std::max<size_t>(total,1),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!block)return nullptr;
  size_t at=0;
  for(unsigned slot=0;slot<Appearance::LOADED;++slot) {
    if(!loadedEffects->info(slot).playable)continue;  // a damaged file stays behind
    const auto &e=store.entry(slot);size_t file=0,source=0;
    if(!store.readFile(slot,block+at,e.fileBytes,file) || !store.readSource(slot,block+at+file,e.sourceBytes,source))continue;
    c.loaded[c.loadedCount++]={uint8_t(slot),block+at,source?block+at+file:nullptr,uint16_t(file),uint16_t(source)};at+=file+source;
  }
  return block;
}
LOOP_HELPER static void exportBackup() {
  auto contents=std::unique_ptr<DeviceBackup::Contents>(new(std::nothrow) DeviceBackup::Contents);
  if(!contents){Serial.println("BACKUP_ERROR out_of_memory");return;}
  contents->practice=practice;contents->look=appearance;contents->bests=personalBests;
  contents->hasMotion=referenceMotion.valid();if(contents->hasMotion)contents->motion=referenceMotion;
  contents->settings={inactivity.minutes(),brightnessPercent,rpmEstimator,sensorProfile,displayFlipped,mountMode,shakeToWake,batteryIcon,minRpmSteps};
  contents->hasThemes=!themeLibrary.empty();contents->themes=themeLibrary;
  contents->hasMilestones=!milestones.isDefault();contents->milestones=milestones;
  contents->hasEffectSet=!effectSet.isDefault();contents->effectSet=effectSet;
  uint8_t *files=readLoadedForBackup(*contents);
  const size_t capacity=DeviceBackup::encodedBound(*contents);
  auto *buffer=static_cast<uint8_t *>(heap_caps_malloc(capacity,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  const size_t n=buffer?DeviceBackup::encode(*contents,VERSION,buffer,capacity):0;
  if(!n){heap_caps_free(buffer);heap_caps_free(files);Serial.println("BACKUP_ERROR out_of_memory");return;}
  Serial.printf("BACKUP_BEGIN format=%lu bytes=%u records=%u sessions=%u motion=%d themes=%d milestones=%d effect_set=%d effects=%u runtime=%s\n",
    (unsigned long)contents->format(),unsigned(n),practice.size(),practice.sessions(),contents->hasMotion,contents->hasThemes,contents->hasMilestones,
    contents->hasEffectSet,contents->loadedCount,VERSION);
  DeviceBackup::base64Lines(buffer,n,96,[](const char *line){Serial.print("BACKUP_DATA ");Serial.println(line);});
  Serial.println("BACKUP_END");
  heap_caps_free(buffer);heap_caps_free(files);
}
LOOP_HELPER static void startRestore() {
  if(analysis.running() || calibrationNeedsSave()){Serial.println("RESTORE_ERROR reason=analysis_pending written=0");return;}
  if(!restoreText)restoreText=static_cast<char *>(heap_caps_malloc(DeviceBackup::LOADED_TEXT_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!restoreText){Serial.println("RESTORE_ERROR reason=out_of_memory written=0");return;}
  restoreRx.start(restoreText,DeviceBackup::LOADED_TEXT_BYTES,millis());
  Serial.printf("RESTORE_READY max_chars=%u\n",unsigned(DeviceBackup::LOADED_TEXT_BYTES));
}
// A backup's loaded effects (DeviceRestore::Device): before anything is
// written the store is opened, formatted if it never was; last of all the
// device's are replaced, each file into the slot the backup had it in. A
// backup without them leaves the device's.
struct RestoreEffects {
  using Result=LoadedEffects<SpiffsFlash>::Store::Result;
  bool prepare(const DeviceBackup::Contents &c) {
    if(!c.loadedCount)return true;
    if(!loadedEffects)return false;
    auto &store=loadedEffects->store();
    if(!store.isOpen()){bool failed=false;while(!store.prepareStep(failed) && !failed){}if(failed)return false;}
    return true;
  }
  bool replace(const DeviceBackup::Contents &c) {
    if(!c.loadedCount)return true;
    if(loadedEffects->clear()!=Result::Ok)return false;
    for(unsigned i=0;i<c.loadedCount;++i) {
      const auto &e=c.loaded[i];
      if(loadedEffects->restore(e.slot,e.file,e.fileBytes,e.source,e.sourceBytes)!=Result::Ok)return false;
    }
    return true;
  }
};
// Validate the whole backup first, then write it inside one ADC-owned idle
// checkpoint (device_restore.h): restored, the device restarts so each store
// loads normally; a failure puts the device's own records back and it runs
// on; only a failure that cannot be put back restarts it on what storage holds.
LOOP_HELPER static void finishRestore(const Snapshot &s) {
  if(analysis.running() || calibrationNeedsSave()){Serial.println("RESTORE_ERROR reason=analysis_pending written=0");return;}
  auto contents=std::unique_ptr<DeviceBackup::Contents>(new(std::nothrow) DeviceBackup::Contents);
  if(!contents){Serial.println("RESTORE_ERROR reason=out_of_memory written=0");return;}
  // Decoded in place: base64's bytes never overtake its text.
  size_t n=0;uint8_t *bytes=reinterpret_cast<uint8_t *>(restoreText);
  if(!restoreRx.take(bytes,DeviceBackup::LOADED_TEXT_BYTES,n) || !DeviceBackup::decode(bytes,n,*contents)) {
    Serial.println("RESTORE_ERROR reason=invalid_backup written=0");return;
  }
  Serial.printf("RESTORE_VALID records=%u sessions=%u motion=%d themes=%d milestones=%d effect_set=%d effects=%u from=%s\n",contents->practice.size(),
    contents->practice.sessions(),contents->hasMotion,contents->hasThemes,contents->hasMilestones,contents->hasEffectSet,contents->loadedCount,contents->runtime);
  if(motionPending || s.phase==AnalogTachometer::Phase::Launch || !acquisition.request(Action::IdleCheckpointBegin,s.launches)) {
    Serial.println("RESTORE_ERROR reason=busy written=0");return;
  }
  RestoreEffects effects;
  DeviceRestore::Device<SpiffsFlash,RestoreEffects> device{practiceStore,appearanceStore,bestStore,motionStore,themeStore,milestoneStore,effectSetStore,
    prefs,historyLog,effects,practice,appearance,personalBests,referenceMotion,themeLibrary,milestones,effectSet,
    {inactivity.minutes(),brightnessPercent,rpmEstimator,sensorProfile,displayFlipped,mountMode,shakeToWake,batteryIcon,minRpmSteps},loggedHistory,loggedBests};
  const auto r=DeviceRestore::run(device,*contents);
  using DeviceRestore::Outcome;
  if(r.outcome==Outcome::Restored || r.outcome==Outcome::Partial) {
    if(r.outcome==Outcome::Restored) {
      // A full NVS refused the mirror; the log holds the records (history_log.h).
      if(!r.historyMirrored || !r.bestsMirrored)
        Serial.printf("RESTORE_NOTICE nvs_copy_failed history=%d best=%d store=log\n",!r.historyMirrored,!r.bestsMirrored);
      heapStatus();Serial.println("RESTORE_OK restarting=1");
    } else Serial.printf("RESTORE_ERROR reason=write_failed record=%s written=partial restarting=1\n",DeviceRestore::name(r.failed));
    UsbTx::drain(200);delay(200);ESP.restart();return;
  }
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("RESTORE_ERROR ADC checkpoint resume failed");
  if(r.outcome==Outcome::Refused)Serial.println("RESTORE_ERROR reason=effects_unavailable written=0");
  else Serial.printf("RESTORE_ERROR reason=write_failed record=%s written=0\n",DeviceRestore::name(r.failed));
  dirty=true;
}
LOOP_HELPER static void pollRestore(const Snapshot &s) {
  const uint32_t now=millis();
  if(restoreRx.timedOut(now)){restoreRx.cancel();usbCommands.refused(now,restoreRx.midLine());Serial.println("RESTORE_ERROR reason=timeout written=0");return;}
  // A transfer owns the USB input until it ends; bounded per loop like commands.
  // One that ends without its "." line tells usbCommands.refused() whether it
  // ended inside a line (a refused byte always does); the guard then drops
  // what that host still sends of the upload.
  for(unsigned n=0;n<256 && restoreRx.active() && Serial.available();++n) {
    inactivity.touch(now);
    switch(restoreRx.feed(Serial.read(),now)) {
      case DeviceBackup::TransferEvent::Chunk:Serial.printf("RESTORE_CHUNK chars=%u\n",unsigned(restoreRx.received()));break;
      case DeviceBackup::TransferEvent::Complete:finishRestore(s);break;
      case DeviceBackup::TransferEvent::Error:usbCommands.refused(now,true);Serial.printf("RESTORE_ERROR reason=%s written=0\n",restoreRx.error());break;
      case DeviceBackup::TransferEvent::None:break;
    }
  }
}

// ---- USB custom themes ------------------------------------------------------
// `L` lists the slots; `T` takes one framed, checksummed request (put, delete,
// select or clear) as a base64 line and a "." line, like a restore. Replies
// are drained at once: a short reply can otherwise wait in the USB ring.
static void themeReply(){UsbTx::drain(100);}
LOOP_HELPER static void listThemes() {
  unsigned available=0;const bool known=nvsAvailable(available);
  // colors=any: any colors are accepted (0.14 and 0.15 refused light or low-contrast themes).
  Serial.printf("THEME_LIST slots=%u selected=%u showing=%u store=%s revision=%lu nvs_available=%d nvs_needed=%u colors=any\n",
    Themes::SLOTS,unsigned(appearance.theme),unsigned(themeLibrary.effective(appearance.theme)),ThemeStore::name(themeStore.status()),
    (unsigned long)themeLibrary.revision,known?int(available):-1,themeStore.neededEntries());
  for(unsigned i=0;i<Themes::SLOTS;++i) {
    char data[(Themes::SLOT_BYTES+2)/3*4+1]={};
    DeviceBackup::base64Text(themeLibrary.raw(i),Themes::SLOT_BYTES,data,sizeof(data));
    Palette::Custom theme;const bool valid=themeLibrary.get(i,theme);
    Serial.printf("THEME_SLOT slot=%u theme=%u state=%s data=%s name=%s\n",i,unsigned(Themes::slotTheme(i)),
      Themes::stateName(themeLibrary.state(i)),data,valid?theme.name:"");
  }
  Serial.println("THEME_LIST_END");themeReply();
}
// A selection the library no longer has returns to the default; an open
// Theme editor closes, since its draft may be gone.
static void themesChanged() {
  controls.customThemes=themeLibrary.validMask();
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::Theme))cancelSettingEdit();
  if(!themeLibrary.available(appearance.theme)) {
    auto next=appearance;
    if(appearanceStore.ready() && next.select(Themes::FALLBACK,appearance.effect,appearance.sound)){appearance=next;settingsSave.mark(SettingsSave::Appearance);}
  }
  syncNavigation();
}
LOOP_HELPER static void selectTheme(Appearance::Theme theme,const Snapshot &s) {
  auto next=appearance;
  if(!themeLibrary.available(theme)){Serial.printf("THEME_ERROR op=select reason=unavailable theme=%u written=0\n",unsigned(theme));themeReply();return;}
  if(!appearanceStore.ready() || !next.select(theme,appearance.effect,appearance.sound)) {
    Serial.println("THEME_ERROR op=select reason=appearance_unavailable written=0");themeReply();return;
  }
  if(next.generation()!=appearance.generation()){appearance=next;settingsSave.mark(SettingsSave::Appearance);}
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::Theme))cancelSettingEdit();
  syncNavigation();
  // Saved with the other settings: at once when the owner is idle, otherwise
  // at its next checkpoint.
  saveSettings(millis(),s,true);
  Serial.printf("THEME_OK op=select theme=%u pending=%d\n",unsigned(theme),bool(settingsSave.pending()&SettingsSave::Appearance));themeReply();
}
LOOP_HELPER static void finishThemeRequest(const Snapshot &s) {
  uint8_t bytes[Themes::Request::BYTES];size_t n=0;
  auto request=std::unique_ptr<Themes::Request>(new(std::nothrow) Themes::Request);
  auto next=std::unique_ptr<Themes::Library>(new(std::nothrow) Themes::Library);
  if(!request || !next){Serial.println("THEME_ERROR reason=out_of_memory written=0");themeReply();return;}
  if(!themeRx.take(bytes,sizeof(bytes),n) || !request->decode(bytes,n)) {
    Serial.println("THEME_ERROR reason=invalid_request written=0");themeReply();return;
  }
  using Op=Themes::Request::Op;
  const char *op=Themes::Request::name(request->op);const unsigned slot=request->argument;
  if(request->op==Op::Select){selectTheme(Appearance::Theme(request->argument),s);return;}
  auto fail=[&](const char *reason){Serial.printf("THEME_ERROR op=%s slot=%u reason=%s written=0\n",op,slot,reason);themeReply();};
  if(request->op!=Op::Clear && slot>=Themes::SLOTS)return fail("bad_slot");
  if(request->op==Op::Put && !request->theme.valid())return fail(Palette::problemName(request->theme.check()));
  // Colors are never refused; a put reports what the editor warns about.
  char warnings[Palette::ADVICE_TEXT]="none";
  if(request->op==Op::Put)request->theme.advice().format(warnings,sizeof(warnings));
  if(themeStore.status()==ThemeStore::Status::Unavailable)return fail("storage_unavailable");
  // An unreadable record is kept until it is cleared on purpose.
  if(request->op!=Op::Clear && themeStore.status()==ThemeStore::Status::Unreadable)return fail("store_unreadable");
  *next=themeLibrary;
  if(request->op==Op::Put)next->put(slot,request->theme);
  else if(request->op==Op::Delete)next->remove(slot);
  else *next=Themes::Library{};
  if(request->op!=Op::Clear && *next==themeLibrary) {
    Serial.printf("THEME_OK op=%s slot=%u revision=%lu unchanged=1 warnings=%s\n",op,slot,(unsigned long)themeLibrary.revision,warnings);themeReply();return;
  }
  unsigned available=0;
  if(request->op==Op::Put && (!nvsAvailable(available) || available<themeStore.neededEntries())) {
    Serial.printf("THEME_ERROR op=put slot=%u reason=nvs_space available_entries=%u needed_entries=%u written=0\n",slot,available,themeStore.neededEntries());
    themeReply();return;
  }
  if(motionPending || s.phase==AnalogTachometer::Phase::Launch || !acquisition.request(Action::IdleCheckpointBegin,s.launches))return fail("busy");
  const bool ok=request->op==Op::Clear?themeStore.clear():themeStore.save(*next);
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("THEME_NOTICE adc_checkpoint_resume_failed");
  if(!ok){Serial.printf("THEME_ERROR op=%s slot=%u reason=write_failed written=unknown\n",op,slot);themeReply();dirty=true;return;}
  themeLibrary=*next;themesChanged();
  Serial.printf("THEME_OK op=%s slot=%u revision=%lu state=%s warnings=%s\n",op,slot,(unsigned long)themeLibrary.revision,
    request->op==Op::Clear?"empty":Themes::stateName(themeLibrary.state(slot)),warnings);themeReply();
  // A selection that fell back is saved like any other setting.
  saveSettings(millis(),acquisition.snapshot(),true);dirty=true;
}
LOOP_HELPER static void pollThemeRequest(const Snapshot &s) {
  const uint32_t now=millis();
  if(themeRx.timedOut(now)){themeRx.cancel();usbCommands.refused(now,themeRx.midLine());Serial.println("THEME_ERROR reason=timeout written=0");themeReply();return;}
  for(unsigned n=0;n<256 && themeRx.active() && Serial.available();++n) {
    inactivity.touch(now);
    switch(themeRx.feed(Serial.read(),now)) {
      case DeviceBackup::Receiver::Event::Chunk:Serial.printf("THEME_CHUNK chars=%u\n",themeRx.received());themeReply();break;
      case DeviceBackup::Receiver::Event::Complete:finishThemeRequest(s);break;
      case DeviceBackup::Receiver::Event::Error:usbCommands.refused(now,true);Serial.printf("THEME_ERROR reason=%s written=0\n",themeRx.error());themeReply();break;
      case DeviceBackup::Receiver::Event::None:break;
    }
  }
}

// ---- USB milestones -----------------------------------------------------------
// `M` lists the Celebrate mode and the table; `U` takes one framed,
// checksummed request (set or reset) like a theme request. A request is
// checked whole and saved inside an idle checkpoint, or nothing changes.
static void milestoneReply(){UsbTx::drain(100);}
static const char *milestoneStoreName(){return !milestoneStore.ready()?"unavailable":milestoneStore.damaged()?"damaged":"ok";}
// An upload must leave room for a history rewrite in the 20 KB NVS.
LOOP_HELPER static void listMilestones() {
  unsigned available=0;const bool known=nvsAvailable(available);
  Milestones::Config::Image image;milestones.encode(image);
  char data[(Milestones::Config::IMAGE_BYTES+2)/3*4+1]={};
  DeviceBackup::base64Text(image.data(),image.size(),data,sizeof(data));
  Serial.printf("MILESTONE_LIST version=3 mode=%s rows=%u max_rows=%u min_rpm=%u max_rpm=%u effects=%u revision=%lu store=%s default=%d nvs_available=%d nvs_needed=%u data=%s%s\n",
    Milestones::name(milestones.mode()),milestones.count(),Milestones::MAX_ROWS,unsigned(Milestones::MIN_RPM),unsigned(Milestones::MAX_RPM),Appearance::EFFECTS,
    (unsigned long)milestones.revision,milestoneStoreName(),milestones.isDefault(),known?int(available):-1,milestoneStore.neededEntries(milestones),data,effectSetFields());
  // effect/effect_id name the pool's first effect, as 0.15 listed its one.
  const auto *picks=milestonePicks();
  for(unsigned i=0;i<milestones.count();++i) {
    // A pool of every drawn effect names about 600 characters.
    const auto &r=milestones.row(i);static char names[16*Appearance::EFFECTS];size_t used=0;names[0]=0;
    for(unsigned e=0;e<Appearance::EFFECTS && used<sizeof(names);++e)if(r.has(Appearance::Effect(e)))
      used+=snprintf(names+used,sizeof(names)-used,"%s%s",used?"+":"",Appearance::label(Appearance::Effect(e)));
    char pool[33];r.pool.hex(pool);
    Serial.printf("MILESTONE_ROW index=%u rpm=%u effect=%s effect_id=%u pool=%s effects=%s next=%s\n",i,unsigned(r.rpm),
      Appearance::label(r.first()),unsigned(r.first()),pool,names,Appearance::label(picks[i]));
  }
  Serial.println("MILESTONE_LIST_END");milestoneReply();
}
LOOP_HELPER static void finishMilestoneRequest(const Snapshot &s) {
  uint8_t bytes[Milestones::Request::BYTES];size_t n=0;
  Milestones::Request request;Milestones::Problem problem=Milestones::Problem::None;unsigned row=0;
  if(!milestoneRx.take(bytes,sizeof(bytes),n) || !request.decode(bytes,n,problem,row)) {
    Serial.println("MILESTONE_ERROR reason=invalid_request written=0");milestoneReply();return;
  }
  const char *op=Milestones::Request::name(request.op);
  if(problem!=Milestones::Problem::None) {
    Serial.printf("MILESTONE_ERROR op=%s reason=invalid_table problem=%s row=%u written=0\n",op,Milestones::problemName(problem),row);
    milestoneReply();return;
  }
  auto fail=[&](const char *reason){Serial.printf("MILESTONE_ERROR op=%s reason=%s written=0\n",op,reason);milestoneReply();};
  if(!milestoneStore.ready())return fail("storage_unavailable");
  auto next=milestones;
  if(request.op==Milestones::Request::Op::Reset)next.reset();
  else next.set(request.mode,request.rows,request.count);
  // A damaged record is replaced even by the table it already shows.
  if(next.generation()==milestones.generation() && !milestoneStore.damaged()) {
    Serial.printf("MILESTONE_OK op=%s revision=%lu unchanged=1\n",op,(unsigned long)milestones.revision);milestoneReply();return;
  }
  if(next.generation()==milestones.generation())++next.revision;
  unsigned available=0;
  const unsigned needed=milestoneStore.neededEntries(next);
  if(!nvsAvailable(available) || available<needed) {
    Serial.printf("MILESTONE_ERROR op=%s reason=nvs_space available_entries=%u needed_entries=%u written=0\n",op,available,needed);
    milestoneReply();return;
  }
  if(motionPending || s.phase==AnalogTachometer::Phase::Launch || !acquisition.request(Action::IdleCheckpointBegin,s.launches))return fail("busy");
  const bool ok=milestoneStore.save(next);
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("MILESTONE_NOTICE adc_checkpoint_resume_failed");
  if(!ok){Serial.printf("MILESTONE_ERROR op=%s reason=write_failed written=unknown\n",op);milestoneReply();dirty=true;return;}
  milestones=next;
  // A Celebrate editor open on the device shows a draft of the old mode.
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::Celebrate))cancelSettingEdit();
  syncNavigation();
  Serial.printf("MILESTONE_OK op=%s revision=%lu mode=%s rows=%u\n",op,(unsigned long)milestones.revision,
    Milestones::name(milestones.mode()),milestones.count());milestoneReply();
}
// ---- USB loaded effects -----------------------------------------------------
// `F` lists the store and every slot; `X` takes one framed, checksummed
// request (fx_transfer.h: put, delete, clear, or source to read a slot's
// packed source back), checked whole and carried out while nothing is
// measured, or nothing changes. The first install formats
// the effect region (docs/FIRMWARE_FLASH_LAYOUT.md), a sector at a time.
static void effectReply(){UsbTx::drain(100);}
static constexpr size_t EFFECT_REQUEST_BYTES=FxTransfer::Request::HEADER+LoadedEffects<SpiffsFlash>::Store::MAX_PAYLOAD+FxTransfer::Request::TRAILER;
static constexpr unsigned EFFECT_REQUEST_CHARS=unsigned((EFFECT_REQUEST_BYTES+2)/3*4);
static const char *effectStoreName() {
  if(!loadedEffects)return "unavailable";
  return loadedEffects->store().isOpen()?"ready":"unformatted";
}
// Which records name loaded effect `id`, as FX_SLOT and a delete's reply list them.
static const char *effectReferences(unsigned id) {
  static char text[32];text[0]=0;
  bool rows=false;for(unsigned i=0;i<milestones.count();++i)rows=rows || milestones.row(i).has(Appearance::Effect(id));
  snprintf(text,sizeof(text),"%s%s%s%s%s",appearance.effect==Appearance::Effect(id)?"best":"",
    appearance.effect==Appearance::Effect(id) && (effectSet.mask().has(id) || rows)?",":"",effectSet.mask().has(id)?"set":"",
    effectSet.mask().has(id) && rows?",":"",rows?"milestones":"");
  return text[0]?text:"none";
}
static bool effectReferenced(unsigned slot){return strcmp(effectReferences(Appearance::FIRST_LOADED+slot),"none")!=0;}
LOOP_HELPER static void listEffects() {
  const auto *store=loadedEffects?&loadedEffects->store():nullptr;
  Serial.printf("FX_LIST version=1 engine=%u code=1 store=%s limit=%u installed=%u free_slots=%u first_id=%u\n",unsigned(LoadableFx::ENGINE),
    effectStoreName(),unsigned(Appearance::LOADED),store?store->installed():0u,store?store->freeSlots():0u,Appearance::FIRST_LOADED);
  for(unsigned slot=0;loadedEffects && slot<Appearance::LOADED;++slot) {
    const auto &i=loadedEffects->info(slot);const auto &e=store->entry(slot);const uint8_t fallback=store->fallback(slot);
    if(!i.installed && fallback==LoadableFx::Program::NO_FALLBACK)continue;
    const unsigned id=Appearance::FIRST_LOADED+slot;
    const char *state=!i.installed?"deleted":i.playable?"ok":i.engine>LoadableFx::ENGINE?"needs_engine":"damaged";
    // The name last: it may hold spaces.
    Serial.printf("FX_SLOT slot=%u id=%u state=%s uid=%016llx revision=%u bytes=%u source_bytes=%u duration_ms=%lu fallback=%s references=%s name=%s\n",
      slot,id,state,(unsigned long long)(i.installed?e.uid:0),unsigned(i.revision),unsigned(e.fileBytes),unsigned(e.sourceBytes),(unsigned long)i.duration,
      fallback!=LoadableFx::Program::NO_FALLBACK?Appearance::label(Appearance::Effect(fallback)):"Orbit",effectReferences(id),i.installed?i.name:"");
  }
  Serial.println("FX_LIST_END");effectReply();
}
LOOP_HELPER static void startEffectRequest() {
  if(!effectRxText)effectRxText=static_cast<char *>(heap_caps_malloc(EFFECT_REQUEST_CHARS,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!effectRxBytes)effectRxBytes=static_cast<uint8_t *>(heap_caps_malloc(EFFECT_REQUEST_BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT));
  if(!loadedEffects || !effectRxText || !effectRxBytes){Serial.println("FX_ERROR reason=storage_unavailable written=0");effectReply();return;}
  effectRx.start(effectRxText,EFFECT_REQUEST_CHARS,millis());
  Serial.printf("FX_READY max_chars=%u\n",EFFECT_REQUEST_CHARS);effectReply();
}
// After an install or a delete: Random, the editors and the milestone picks see the change.
static void effectsChanged() {
  if(!Appearance::celebrates(unsigned(upcomingEffect)))upcomingEffect=Appearance::Effect::Off;
  milestonePicksReady=false;
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::BestEffect))cancelSettingEdit();
  syncNavigation();dirty=true;
}
LOOP_HELPER static void finishEffectRequest(const Snapshot &s) {
  size_t n=0;FxTransfer::Request request;
  if(!effectRx.take(effectRxBytes,EFFECT_REQUEST_BYTES,n) || !request.decode(effectRxBytes,n)){Serial.println("FX_ERROR reason=invalid_request written=0");effectReply();return;}
  const char *op=FxTransfer::Request::name(request.op);
  auto fail=[&](const char *reason){Serial.printf("FX_ERROR op=%s reason=%s written=0\n",op,reason);effectReply();};
  if(motionPending || s.phase==AnalogTachometer::Phase::Launch)return fail("busy");
  using Result=LoadedEffects<SpiffsFlash>::Store::Result;
  auto &store=loadedEffects->store();
  if(request.op==FxTransfer::Request::Op::Put) {
    LoadableFx::Program p;const auto loaded=LoadableFx::load(request.file,request.fileBytes,p,false);
    if(loaded==LoadableFx::Error::Engine)return fail("engine");
    if(loaded!=LoadableFx::Error::None){Serial.printf("FX_ERROR op=put reason=invalid_file problem=%s written=0\n",LoadableFx::label(loaded));effectReply();return;}
    if(LoadableFx::hotBytes(p)>LoadableFx::HOT_BYTES)return fail("too_large_for_ram");
    if(!store.isOpen()) {
      // Once per unit: erase the region a sector at a time (14-30 ms each, the ADC rides them).
      const int64_t started=esp_timer_get_time();bool failed=false;
      while(!store.prepareStep(failed) && !failed)vTaskDelay(1);
      if(failed)return fail("storage_unavailable");
      Serial.printf("FX_NOTICE store_formatted us=%lld\n",(long long)(esp_timer_get_time()-started));
    }
    unsigned slot=0;
    const Result r=loadedEffects->install(request.file,request.fileBytes,request.source,request.sourceBytes,effectReferenced,slot);
    if(r!=Result::Ok) {
      if(r==Result::WriteFailed){Serial.println("FX_ERROR op=put reason=write_failed written=unknown");effectReply();effectsChanged();return;}
      return fail(r==Result::Full?"slots_full":r==Result::TooLarge?"too_large":r==Result::Engine?"engine":r==Result::Invalid?"invalid_file":"storage_unavailable");
    }
    effectsChanged();
    Serial.printf("FX_OK op=put slot=%u id=%u uid=%016llx revision=%u installed=%u free_slots=%u name=%s\n",slot,Appearance::FIRST_LOADED+slot,
      (unsigned long long)p.uid,unsigned(p.revision),store.installed(),store.freeSlots(),p.name);
    effectReply();return;
  }
  if(!store.isOpen())return fail("not_found");
  if(request.op==FxTransfer::Request::Op::Source) {
    // The request is decoded and holds no file: its buffer takes the source.
    const unsigned slot=request.slot;const auto &e=store.entry(slot);size_t n=0;
    if(!e.used)return fail("not_found");
    if(!store.readSource(slot,effectRxBytes,EFFECT_REQUEST_BYTES,n))return fail("read_failed");
    Serial.printf("FX_SOURCE slot=%u id=%u uid=%016llx bytes=%u\n",slot,Appearance::FIRST_LOADED+slot,(unsigned long long)e.uid,unsigned(n));
    DeviceBackup::base64Lines(effectRxBytes,n,96,[](const char *line){Serial.println(line);effectReply();});
    Serial.printf("FX_OK op=source slot=%u bytes=%u\n",slot,unsigned(n));effectReply();return;
  }
  if(request.op==FxTransfer::Request::Op::Delete) {
    const unsigned id=Appearance::FIRST_LOADED+request.slot;const char *references=effectReferences(id);
    static char kept[32];strncpy(kept,references,sizeof(kept)-1);kept[sizeof(kept)-1]=0;
    const Result r=loadedEffects->remove(request.slot);
    if(r==Result::NotFound)return fail("not_found");
    if(r!=Result::Ok){Serial.println("FX_ERROR op=delete reason=write_failed written=unknown");effectReply();effectsChanged();return;}
    effectsChanged();
    Serial.printf("FX_OK op=delete slot=%u id=%u references=%s installed=%u\n",unsigned(request.slot),id,kept,store.installed());effectReply();return;
  }
  const Result r=loadedEffects->clear();effectsChanged();
  if(r!=Result::Ok){Serial.println("FX_ERROR op=clear reason=write_failed written=unknown");effectReply();return;}
  Serial.printf("FX_OK op=clear installed=%u\n",store.installed());effectReply();
}
LOOP_HELPER static void pollEffectRequest(const Snapshot &s) {
  const uint32_t now=millis();
  if(effectRx.timedOut(now)){effectRx.cancel();usbCommands.refused(now,effectRx.midLine());Serial.println("FX_ERROR reason=timeout written=0");effectReply();return;}
  for(unsigned n=0;n<256 && effectRx.active() && Serial.available();++n) {
    inactivity.touch(now);
    switch(effectRx.feed(Serial.read(),now)) {
      case FxTransfer::Event::Chunk:Serial.printf("FX_CHUNK chars=%u\n",effectRx.received());effectReply();break;
      case FxTransfer::Event::Complete:finishEffectRequest(s);break;
      case FxTransfer::Event::Error:usbCommands.refused(now,true);Serial.printf("FX_ERROR reason=%s written=0\n",effectRx.error());effectReply();break;
      case FxTransfer::Event::None:break;
    }
  }
}

// ---- USB effect set -----------------------------------------------------------
// The milestone protocol carries it: `M` adds effect_set=, effect_set_store=
// and effect_set_default= to MILESTONE_LIST, and `U` op 3 (set_effects,
// effect_set.h) replaces the set, checked whole and saved inside an idle
// checkpoint, or nothing changes. Replies are MILESTONE_OK / MILESTONE_ERROR.
static const char *effectSetStoreName(){return !effectSetStore.ready()?"unavailable":effectSetStore.damaged()?"damaged":"ok";}
// An upload must leave room for a history rewrite in the 20 KB NVS, and keep
// the reserve when it fills an empty slot.
static constexpr unsigned EFFECT_SET_NEEDED_ENTRIES=NvsBudget::blobEntries(EffectSet::Config::IMAGE_BYTES)+
  NvsBudget::blobEntries(PracticeHistory::IMAGE_BYTES);
static unsigned effectSetNeededEntries() {
  const unsigned own=NvsBudget::blobEntries(EffectSet::Config::IMAGE_BYTES);
  return NvsBudget::optionalNeeded(own,effectSetStore.bothSlots()?0:own,NvsBudget::blobEntries(PracticeHistory::IMAGE_BYTES));
}
// MILESTONE_LIST's effect set fields, each after a space.
// loaded= is the mask of added effects that play here (IDs 96-127): the ones a
// table or the set may name; older sites ignore it.
static const char *effectSetFields() {
  static char text[136];char mask[33],loaded[33];effectSet.mask().hex(mask);(EffectSet::celebrating()&EffectSet::LOADED).hex(loaded);
  snprintf(text,sizeof(text)," effect_set=%s effect_set_store=%s effect_set_default=%d loaded=%s",mask,effectSetStoreName(),effectSet.isDefault(),loaded);
  return text;
}
// A new set reaches the Best effect editor and Random's next pick at once.
static void effectSetChanged() {
  controls.offeredEffects=effectSet.mask();
  if(!effectSet.offers(upcomingEffect))upcomingEffect=Appearance::Effect::Off;
  // A Best effect editor open on the device cycles the old set.
  if(controls.page==Controls::Page::Edit && controls.setting==unsigned(Controls::Setting::BestEffect))cancelSettingEdit();
  syncNavigation();dirty=true;
}
// Takes a completed `U` transfer that is a set_effects request; false leaves
// it to finishMilestoneRequest.
LOOP_HELPER static bool finishEffectSetRequest(const Snapshot &s) {
  uint8_t bytes[EffectSet::Request::BYTES];size_t n=0;
  if(!milestoneRx.take(bytes,sizeof(bytes),n) || !EffectSet::Request::claims(bytes,n))return false;
  EffectSet::Mask mask;EffectSet::Problem problem=EffectSet::Problem::None;unsigned effect=0;
  if(!EffectSet::Request::decode(bytes,n,mask,problem,effect)) {
    Serial.println("MILESTONE_ERROR reason=invalid_request written=0");milestoneReply();return true;
  }
  const char *op=EffectSet::Request::NAME;
  if(problem!=EffectSet::Problem::None) {
    Serial.printf("MILESTONE_ERROR op=%s reason=invalid_effects problem=%s effect=%u written=0\n",op,EffectSet::problemName(problem),effect);
    milestoneReply();return true;
  }
  auto fail=[&](const char *reason){Serial.printf("MILESTONE_ERROR op=%s reason=%s written=0\n",op,reason);milestoneReply();return true;};
  if(!effectSetStore.ready())return fail("storage_unavailable");
  auto next=effectSet;next.set(mask);
  // A damaged record is replaced even by the set it already shows.
  if(next.generation()==effectSet.generation() && !effectSetStore.damaged()) {
    Serial.printf("MILESTONE_OK op=%s revision=%lu unchanged=1\n",op,(unsigned long)effectSet.revision);milestoneReply();return true;
  }
  if(next.generation()==effectSet.generation())++next.revision;
  unsigned available=0;
  const unsigned needed=effectSetNeededEntries();
  if(!nvsAvailable(available) || available<needed) {
    Serial.printf("MILESTONE_ERROR op=%s reason=nvs_space available_entries=%u needed_entries=%u written=0\n",op,available,needed);
    milestoneReply();return true;
  }
  if(motionPending || s.phase==AnalogTachometer::Phase::Launch || !acquisition.request(Action::IdleCheckpointBegin,s.launches))return fail("busy");
  const bool ok=effectSetStore.saveViewed(next);
  if(!acquisition.request(Action::CheckpointEnd))Serial.println("MILESTONE_NOTICE adc_checkpoint_resume_failed");
  if(!ok){Serial.printf("MILESTONE_ERROR op=%s reason=write_failed written=unknown\n",op);milestoneReply();dirty=true;return true;}
  effectSet=next;effectSetChanged();
  char hex[33];effectSet.mask().hex(hex);
  Serial.printf("MILESTONE_OK op=%s revision=%lu effect_set=%s effects=%u\n",op,(unsigned long)effectSet.revision,hex,effectSet.count());milestoneReply();
  return true;
}

LOOP_HELPER static void pollMilestoneRequest(const Snapshot &s) {
  const uint32_t now=millis();
  if(milestoneRx.timedOut(now)){milestoneRx.cancel();usbCommands.refused(now,milestoneRx.midLine());Serial.println("MILESTONE_ERROR reason=timeout written=0");milestoneReply();return;}
  for(unsigned n=0;n<256 && milestoneRx.active() && Serial.available();++n) {
    inactivity.touch(now);
    switch(milestoneRx.feed(Serial.read(),now)) {
      case DeviceBackup::TransferEvent::Chunk:Serial.printf("MILESTONE_CHUNK chars=%u\n",milestoneRx.received());milestoneReply();break;
      case DeviceBackup::TransferEvent::Complete:if(!finishEffectSetRequest(s))finishMilestoneRequest(s);break;
      case DeviceBackup::TransferEvent::Error:usbCommands.refused(now,true);Serial.printf("MILESTONE_ERROR reason=%s written=0\n",milestoneRx.error());milestoneReply();break;
      case DeviceBackup::TransferEvent::None:break;
    }
  }
}

LOOP_HELPER static void checkStorage() {
  // Explicit USB bench diagnostic. Scratch measurements never enter practice.
  const auto state=acquisition.snapshot();
  if(motionPending || !acquisition.request(Action::IdleCheckpointBegin,state.launches)) {
    Serial.println("HISTORY_CHECK_ERROR wait until capture finishes");return;
  }
  Preferences scratch;scratch.begin("ll-prac-qa",false);
  // Only this diagnostic owns these scratch keys; recover an interrupted bench.
  if(scratch.isKey("history0"))scratch.remove("history0");
  if(scratch.isKey("history1"))scratch.remove("history1");
  bool ok=!scratch.isKey("history0") && !scratch.isKey("history1");
  const bool clean=ok;
  // Two scratch slots plus a rewrite in flight do not fit beside real history
  // in the 20 KB NVS; check first rather than fill it until a write fails.
  unsigned available=0;const unsigned needed=NvsBudget::alternatingStoreEntries(PracticeHistory::IMAGE_BYTES);
  const bool room=nvsAvailable(available) && available>=needed;
  if(!room)Serial.printf("HISTORY_CHECK_SKIPPED reason=nvs_space available_entries=%u needed_entries=%u written=0\n",available,needed);
  ok=ok && room;
  auto h=std::unique_ptr<PracticeHistory>(new(std::nothrow) PracticeHistory);
  auto store=std::unique_ptr<PracticeStore>(new(std::nothrow) PracticeStore);
  uint32_t maximum=0;unsigned writes=0;
  ok=ok && h && store && store->begin(*h,"ll-prac-qa");
  for(unsigned i=1;ok && i<=36;++i) {
    if(i%6==1)h->newSession();
    h->accept(i,true,5000+i*30,i*20000);
    const int64_t started=esp_timer_get_time();ok=store->save(*h);
    if(ok)++writes;
    maximum=std::max(maximum,uint32_t(esp_timer_get_time()-started));
    auto restored=std::unique_ptr<PracticeHistory>(new(std::nothrow) PracticeHistory);
    auto reader=std::unique_ptr<PracticeStore>(new(std::nothrow) PracticeStore);
    ok=ok && restored && reader && reader->begin(*restored,"ll-prac-qa") &&
      restored->generation()==h->generation() && restored->size()==h->size() &&
      restored->session()->mean()==h->session()->mean() && restored->recent()->rpm==h->recent()->rpm;
  }
  if(clean) {
    if(scratch.isKey("history0"))ok=scratch.remove("history0") && ok;
    if(scratch.isKey("history1"))ok=scratch.remove("history1") && ok;
    ok=ok && !scratch.isKey("history0") && !scratch.isKey("history1");
  }
  const bool resumed=acquisition.request(Action::CheckpointEnd);
  Serial.printf("HISTORY_CHECK ok=%d writes=%u max_write_us=%lu scratch_clean=%d resumed=%d actual_records=%u nvs_available_entries=%u nvs_needed_entries=%u\n",
    ok,writes,(unsigned long)maximum,clean,resumed,practice.size(),available,needed);dirty=true;
}

LOOP_HELPER static void checkMotionStorage() {
  const auto state=acquisition.snapshot();
  if(motionPending || !acquisition.request(Action::IdleCheckpointBegin,state.launches)) {
    Serial.println("MOTION_CHECK_ERROR wait until capture finishes");return;
  }
  Preferences scratch;scratch.begin("ll-mot-qa",false);
  for(const char *key:{"ref0","ref1"})if(scratch.isKey(key))scratch.remove(key);
  const bool clean=!scratch.isKey("ref0") && !scratch.isKey("ref1");
  unsigned available=0;const unsigned needed=NvsBudget::alternatingStoreEntries(LaunchMotion::IMAGE_BYTES);
  const bool room=nvsAvailable(available) && available>=needed;
  if(!room)Serial.printf("MOTION_CHECK_SKIPPED reason=nvs_space available_entries=%u needed_entries=%u written=0\n",available,needed);
  auto t=std::unique_ptr<LaunchMotion::Trace>(new(std::nothrow) LaunchMotion::Trace);
  auto restored=std::unique_ptr<LaunchMotion::Trace>(new(std::nothrow) LaunchMotion::Trace);
  auto store=std::unique_ptr<MotionStore>(new(std::nothrow) MotionStore);
  bool ok=clean && room && t && restored && store && store->begin(*restored,"ll-mot-qa");
  unsigned writes=0;uint32_t maximum=0;
  if(t)MotionUI::makeDemo(*t,true);
  for(unsigned i=1;ok && i<=16;++i) {
    t->number=i;t->rpm=5000+i*50;const int64_t started=esp_timer_get_time();ok=store->save(*t);
    if(ok)++writes;maximum=std::max(maximum,uint32_t(esp_timer_get_time()-started));
    auto reader=std::unique_ptr<MotionStore>(new(std::nothrow) MotionStore);
    ok=ok && reader && reader->begin(*restored,"ll-mot-qa") && restored->number==i && restored->rpm==t->rpm;
  }
  bool cleaned=clean;
  if(clean)for(const char *key:{"ref0","ref1"})if(scratch.isKey(key))cleaned=scratch.remove(key) && cleaned;
  cleaned=cleaned && !scratch.isKey("ref0") && !scratch.isKey("ref1");
  const bool resumed=acquisition.request(Action::CheckpointEnd);
  Serial.printf("MOTION_CHECK ok=%d writes=%u bytes=%u max_write_us=%lu scratch_clean=%d resumed=%d actual_records=%u actual_ref=%lu nvs_available_entries=%u nvs_needed_entries=%u\n",
    ok,writes,unsigned(LaunchMotion::IMAGE_BYTES),(unsigned long)maximum,cleaned,resumed,practice.size(),(unsigned long)referenceMotion.number,available,needed);
  dirty=true;
}

// Every checkpoint begins and ends inside one call; only the wipe flow keeps
// one, and the loop stops before here while it does. A stopped owner that is
// not resting and outlasts a loop pass therefore means a Begin whose reply was
// lost, or an End that never arrived. Release it, or the ADC would stay
// stopped and no later pull would be measured.
LOOP_HELPER static void releaseOrphanCheckpoint(uint32_t now,const Snapshot &s) {
  if(!s.suspended || s.resting || wipeCheckpointHeld){orphanSeen=false;return;}
  if(!orphanSeen){orphanSeen=true;orphanSince=now;return;}
  if(uint32_t(now-orphanSince)<ORPHAN_CHECKPOINT_MS)return;
  orphanSeen=false;
  const bool resumed=acquisition.request(Action::CheckpointEnd) || acquisition.request(Action::Pin,s.pin);
  Serial.printf("ADC_NOTICE orphaned_checkpoint_released resumed=%d\n",resumed);dirty=true;
}

#if LAUNCHLAB_HIL
#include "hil.h"
#endif
#if LAUNCHLAB_POWER_LAB
#include "power_lab_device.h"
#endif
// The longest request lines (a v3 milestone request, a theme request, a
// restore line) fit the RX queue twice over.
static_assert(USB_RX_BUFFER_BYTES>=2*((Milestones::Request::BYTES+2)/3*4+2) &&
              USB_RX_BUFFER_BYTES>=2*((Themes::Request::BYTES+2)/3*4+2) && USB_RX_BUFFER_BYTES>=2*(96+2),
              "a request line must fit the USB RX queue");
// A timer wake from a USB-retained standby (shake_wake.h): while USB is still
// there, sleep again before anything starts or lights; unplugged, or the PM1
// unreadable, boot and finish the power-off on battery (finishStandby).
static void recheckUsbStandby(esp_sleep_wakeup_cause_t cause) {
  if(usbStandby.magic!=UsbStandby::MAGIC || cause!=ESP_SLEEP_WAKEUP_TIMER)return;
  uint8_t source=0,mask=0xff;bool read=false;
  M5.In_I2C.begin(I2C_NUM_1,GPIO_NUM_47,GPIO_NUM_48);
  // An idle PM1 fails its first transaction by design (pm1_idle.h).
  for(unsigned attempt=0;attempt<3 && !read;++attempt){read=M5.In_I2C.readRegister(0x6E,0x04,&source,1,100000);if(!read)delay(1);}
  if(read)M5.In_I2C.readRegister(0x6E,StickS3ShakeWake::SYSTEM_IRQ_MASK,&mask,1,100000);
  M5.In_I2C.release();
  standbyRecheck={true,read,source,mask};
#if LAUNCHLAB_HIL
  if(hilStandbyRecheckS){hilStandbyRecheckS=0;return;}  // boot, still in standby: the rig checks the re-check
#endif
  if(read && (source&UsbHostAwake::VIN_MASK) && StickS3ShakeWake::deepSleepWakes(standbyRecheckUs()))esp_deep_sleep_start();
  finishStandby=true;
}

void setup() {
  const bool nvsWasVirgin=nvsVirgin();  // before anything opens a namespace
  const auto wakeCause=esp_sleep_get_wakeup_cause();
  const int64_t sleepEnded=wallUs();
  recheckUsbStandby(wakeCause);
  Serial.setRxBufferSize(USB_RX_BUFFER_BYTES); // Before begin.
  // The core's 256-byte USB TX ring cannot hold one status block, so with the
  // 10 ms timeout below whole lines were dropped while the host was reading
  // (truncated status, a failed backup checksum). Must be set before begin.
  Serial.setTxBufferSize(USB_TX_BUFFER_BYTES);
  Serial.begin(115200);
  Serial.setTxTimeoutMs(10);
  UsbTx::calibrate(); // The TX ring is empty: its free size marks "drained".
  // Set once before either acquisition task starts. Keep ADC, USB and SPI
  // peripheral clocks unchanged; do not switch frequency during a launch.
  const bool clockSet=setCpuFrequencyMhz(LAUNCHLAB_CPU_MHZ);
  const bool clockOk=clockSet && getCpuFrequencyMhz()==LAUNCHLAB_CPU_MHZ && getApbFrequency()==80000000;
  if(!clockOk)setCpuFrequencyMhz(240);
  Serial.printf("CPU_POLICY requested_mhz=%u actual_mhz=%lu apb_hz=%lu fallback=%d\n",
    unsigned(LAUNCHLAB_CPU_MHZ),(unsigned long)getCpuFrequencyMhz(),(unsigned long)getApbFrequency(),!clockOk);
  // Free a bus left held by a slave interrupted mid-read before any I2C use.
  i2cRecovery=I2cBusRecovery::recoverStickS3Internal(i2cRecoveryPulses,i2cSdaWas,i2cSclWas);
  Serial.printf("I2C_RECOVERY bus=internal result=%s pulses=%u sda_was=%d scl_was=%d\n",I2cBusRecovery::name(i2cRecovery),i2cRecoveryPulses,i2cSdaWas,i2cSclWas);
  CpuPower::begin();
  CpuPower::Guard startupClock(CpuPower::Ui);
  auto cfg=M5.config();
  cfg.fallback_board=m5::board_t::board_M5StickS3;
  // internal_spk only configures the speaker; it stays unpowered until a sound plays.
  cfg.internal_mic=cfg.internal_rtc=false;cfg.internal_spk=cfg.internal_imu=true;
  cfg.external_imu=cfg.external_rtc=false;cfg.output_power=false;
  // This UI uses A/B only. M5.update otherwise polls the unused BtnPWR IRQ
  // via PM1 every 4 ms, adding I2C traffic and preventing PM1 idle timeout.
  // PM1's physical power-key/reset operation remains a hardware function.
  cfg.pmic_button=false;
  M5.begin(cfg);
  readDeviceFlash();
  // The changed-row hashes go in PSRAM: without them every frame is pushed whole.
  frameRows.begin(static_cast<uint32_t *>(heap_caps_malloc(FrameRows::BYTES,MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT)));
  soundPlayer.configure();
  M5.Ex_I2C.release();
  pm1WakeValid=pm1Idle().read(0x05,&pm1WakeFlags,1);
  // USB removed during a USB-retained standby: finish its power-off below.
  uint8_t systemIrq=0;
  const bool systemIrqRead=pm1Idle().read(StickS3ShakeWake::SYSTEM_IRQ_STATUS,&systemIrq,1);
  const bool inUsbStandby=usbStandby.magic==UsbStandby::MAGIC,standbyKeyOnly=inUsbStandby && usbStandby.keyOnly;
  uint8_t powerSource=0;
  const bool vinAbsent=pm1Idle().read(0x04,&powerSource,1) && !(powerSource&UsbHostAwake::VIN_MASK);
  const auto standbyWake=usbStandbyWake(usbStandby,wakeCause==ESP_SLEEP_WAKEUP_EXT0,finishStandby,systemIrqRead,systemIrq,vinAbsent);
  finishStandby=standbyWake.finish;
  if(systemIrqRead && systemIrq)pm1Idle().write(StickS3ShakeWake::SYSTEM_IRQ_STATUS,0);
  usbStandby.magic=0;
  const bool keyWake=standbyWake.keyWake;
#if LAUNCHLAB_HIL
  char *const wakeText=standbyWakeText;
#else
  char wakeText[224];  // on setup's stack: the songs need every byte of the internal heap
#endif
  snprintf(wakeText,224,"esp_cause=%d in_standby=%d key_only=%d finish=%d key_wake=%d vin_absent=%d system_irq_valid=%d system_irq=0x%02x recheck=%d recheck_read=%d recheck_source=0x%02x recheck_irq_mask=0x%02x",
    int(wakeCause),inUsbStandby,standbyKeyOnly,finishStandby,keyWake,vinAbsent,systemIrqRead,systemIrq,standbyRecheck.ran,standbyRecheck.read,standbyRecheck.source,standbyRecheck.mask);
  Serial.printf("USB_STANDBY_WAKE %s\n",wakeText);
  // PM1 keeps PWR_CFG through an ESP32 reset (a flash, a crash, a restart):
  // charging stays on whatever ran before.
  if(!pm1Idle().masked(0x06,0x01,0x01))Serial.println("PM1_NOTICE charge_enable_failed");
  if(!pm1Idle().run([](){return M5.Power.M5pm1.clearWakeSource();}))Serial.println("PM1_NOTICE wake_clear_failed");
  if(!shakeWake.clear())Serial.println("SHAKE_WAKE_NOTICE startup_disarm_failed");
  pinMode(POWER_KEY_IRQ_PIN,INPUT_PULLUP);  // polled (pollPowerKey), never an interrupt
  // The value found at boot shows whether PM1 kept SINGLE_RST_DIS through power-off.
  uint8_t bootKeyConfig=0;
  const bool bootKeyConfigRead=pm1Idle().read(StickS3PowerKey::BUTTON_CONFIG,&bootKeyConfig,1);
  const bool keyConfigured=powerKey().configure();
  Serial.printf("POWER_KEY_BOOT btn_cfg_valid=%d btn_cfg=0x%02x configured=%d\n",bootKeyConfigRead,bootKeyConfig,keyConfigured);
  if(!recoverWipe()) {
    // Unplugged in a standby the blocked page began: finish it (it writes nothing).
    if(finishStandby)powerKeyRequested=true;
#if LAUNCHLAB_HIL
    hilBoot();
#endif
    return;
  }
  openHistoryLog();
  disownLostNvs(nvsWasVirgin);
  prefs.begin("launchlab-mini",false);
  powerLogReady=powerPrefs.begin("ll-power",false);
  PowerDiagnostics::fresh(powerLog);
  bool powerInNvs=false;
  if(powerLogReady && powerPrefs.isKey("log")){
    PowerDiagnostics::Image loaded;
    if(powerPrefs.getBytesLength("log")==sizeof(loaded) && powerPrefs.getBytes("log",&loaded,sizeof(loaded))==sizeof(loaded)
      && PowerDiagnostics::valid(loaded)){powerLog=loaded;powerInNvs=true;powerMirror=loaded.checksum;}
    else {powerLogReady=false;Serial.println("POWER_LOG_NOTICE invalid_existing_log_retained");}
  }
  pickLoggedPower(powerInNvs?HistoryLog::Nvs::Found:powerLogReady && !powerPrefs.isKey("log")?HistoryLog::Nvs::Absent:HistoryLog::Nvs::Unreadable);
  ++powerLog.boots;
  const bool wakingFromStandby=powerLog.pendingSleep;
  uint8_t loggedWake=pm1WakeValid?pm1WakeFlags:0;
  if(finishStandby)++powerLog.otherWakes;
  else if(keyWake)++powerLog.powerButtonWakes;
  else if(wakingFromStandby && ((pm1WakeValid && (pm1WakeFlags&0x20)) || wakeCause==ESP_SLEEP_WAKEUP_EXT0))++powerLog.shakeWakes;
  else if(pm1WakeValid && (pm1WakeFlags&0x0c))++powerLog.powerButtonWakes;
  else ++powerLog.otherWakes;
  if(wakingFromStandby) {
    if(wakeCause!=ESP_SLEEP_WAKEUP_UNDEFINED && sleepReceipt.magic==PowerDiagnostics::MAGIC
      && sleepEnded>=sleepReceipt.atUs && sleepEnded-sleepReceipt.atUs<366LL*24*3600*1000000)
      powerLog.sleepMs+=uint64_t(sleepEnded-sleepReceipt.atUs)/1000;
    else ++powerLog.unknownSleepIntervals; // PM1 battery shutdown loses ESP32 RTC time.
  }
  powerLog.pendingSleep=0;sleepReceipt.magic=0;
  bool restoredNavigation=false;
  if(prefs.isKey("wake_nav")) {
    Controls::State restored;uint8_t restoredView=0;
    const bool valid=Controls::decodeWake(prefs.getUInt("wake_nav",0),restored,restoredView);
    const bool consumed=prefs.remove("wake_nav");
    if(valid && consumed){controls=restored;tournamentView=TournamentView(restoredView);syncNavigation();restoredNavigation=true;}
    Serial.printf("WAKE_NAV_RESTORE valid=%d consumed=%d page=%u view=%u\n",valid,consumed,unsigned(controls.page),unsigned(tournamentView));
  }
  if(prefs.isKey("wake_ui")) {
    WakeUi::State state;
    const bool valid=WakeUi::decode(prefs.getUInt("wake_ui",0),uint8_t(PracticeUI::View::Settings),state);
    const bool consumed=prefs.remove("wake_ui");
    if(valid && consumed && !restoredNavigation) {
      tournamentMode=state.tournament;tournamentView=TournamentView(state.tournamentView);
      historyPage=state.history;historyView=PracticeUI::restoredView(state.historyView);
      controls.page=state.tournament?Controls::Page::Tournament:!state.history?Controls::Page::Main:
        historyView==PracticeUI::View::Battery?Controls::Page::Battery:
        historyView==PracticeUI::View::Settings?Controls::Page::Settings:Controls::Page::History;
      if(controls.page==Controls::Page::History)controls.history=uint8_t(historyView);
      syncNavigation();
    }
    Serial.printf("WAKE_UI_RESTORE valid=%d consumed=%d tournament=%d display=%s history=%d page=%u\n",
      valid,consumed,tournamentMode,tournamentViewName(),historyPage,unsigned(historyView));
  }
  if(!RpmEstimatorSetting::load(prefs,rpmEstimator))
    Serial.printf("RPM_SETTING_NOTICE invalid_record_retained_using_default=%s\n",RpmEstimator::name(RpmEstimator::DEFAULT_MODE));
  if(!SensorProfileSetting::load(prefs,sensorProfile))Serial.println("SENSOR_SETTING_NOTICE invalid_record_retained_using_standard_default");
  loadStartMarks();
  const uint8_t sleepMinutes=prefs.getUChar("sleep_min",InactivityTimer::DEFAULT_MINUTES);
  if(!inactivity.setMinutes(sleepMinutes)) {
    inactivity.setMinutes(InactivityTimer::DEFAULT_MINUTES);
    Serial.printf("SLEEP_SETTING_NOTICE invalid_saved_value_using_%u_min\n",unsigned(InactivityTimer::DEFAULT_MINUTES));
  }
  if(!Brightness::load(prefs,brightnessPercent))
    Serial.printf("BRIGHTNESS_SETTING_NOTICE invalid_saved_value_using_default_pct=%u\n",unsigned(Brightness::DEFAULT_PERCENT));
  BleLink::bondPrefs=&prefs;BleLink::loadName(prefs);
  if(prefs.getBytesLength(PASS_CONFIRMED_KEY)==sizeof(passConfirmed))prefs.getBytes(PASS_CONFIRMED_KEY,&passConfirmed,sizeof(passConfirmed));
  if(!BluetoothSetting::load(prefs,bluetoothOn))Serial.println("BLUETOOTH_SETTING_NOTICE invalid_saved_value_retained_using_off_default");
  bluetoothAtBoot=bluetoothOn;
  if(!ShakeWakeSetting::load(prefs,shakeToWake))Serial.println("SHAKE_WAKE_SETTING_NOTICE invalid_saved_value_retained_using_on");
  unusedWakes=prefs.getUChar(UnusedWakes::KEY,0);
  if(!BatteryIconSetting::load(prefs,batteryIcon))Serial.println("BATTERY_ICON_SETTING_NOTICE invalid_saved_value_retained_using_on");
  if(!MinRpmSetting::load(prefs,minRpmSteps))Serial.printf("MIN_RPM_SETTING_NOTICE invalid_saved_value_retained_using_%u\n",unsigned(MinRpm::rpm(minRpmSteps)));
  if(!BattlesSetting::load(prefs,battlesOn,battleMatchTo))Serial.println("BATTLES_SETTING_NOTICE invalid_saved_value_retained_using_on");
  if(!DisplayFlipSetting::load(prefs,displayFlipped))Serial.println("DISPLAY_SETTING_NOTICE invalid_record_retained_using_flip_off_default");
  if(!MountOrientationSetting::load(prefs,mountMode))Serial.println("MOUNT_SETTING_NOTICE invalid_record_retained_using_top_default");
  liveMount=mountMode;
  if(!appearanceStore.begin(appearance,"ll-appearance","cfg0","cfg1"))Serial.println("APPEARANCE_NOTICE invalid_record_retained_using_defaults");
  const bool bestsInNvs=bestStore.begin(personalBests,"ll-bests","best0","best1") && bestStore.present();
  if(!bestStore.ready() || bestStore.damaged())Serial.println("BEST_NOTICE invalid_record_retained_celebration_disabled");
  pickLoggedBests(bestsInNvs);
  if(themeStore.begin(themeLibrary)==ThemeStore::Status::Unreadable)Serial.println("THEME_NOTICE invalid_record_retained_using_default_colors");
  // 0.17's slots, a packed record for a wider table, else 0.15's carried over (milestone_store.h).
  milestoneStore.begin(milestones);
  if(!milestoneStore.ready())Serial.println("MILESTONE_NOTICE storage_unavailable_using_defaults");
  else if(milestoneStore.damaged())Serial.println("MILESTONE_NOTICE invalid_record_using_defaults");
  else if(milestoneStore.source()==MilestoneStore::Source::Legacy)Serial.println("MILESTONE_NOTICE imported_v1_table");
  if(!effectSetStore.begin(effectSet,"ll-appearance","eset0","eset1",true))
    Serial.println(effectSetStore.damaged()?"EFFECT_SET_NOTICE invalid_record_using_defaults":"EFFECT_SET_NOTICE storage_unavailable_using_defaults");
  controls.customThemes=themeLibrary.validMask();controls.offeredEffects=effectSet.mask();
  if(!themeLibrary.available(appearance.theme))Serial.printf("THEME_NOTICE selected_theme_unavailable theme=%u showing=%u\n",unsigned(appearance.theme),unsigned(Themes::FALLBACK));
  uint8_t pin=prefs.getUChar("ao_pin",1);
  if(pin<1 || pin>10)pin=1;
  extPower=prefs.getBool("ext5v",false);
  saveError=!practiceStore.begin(practice);
  pickLoggedHistory();
  // The battle records, from the log alone. This stick's ID in a battle is the
  // end of its Bluetooth address, as its default name is.
  {
    const bool found=historyLog.isOpen() && historyLog.loadRivals(rivals);
    loggedRivals=rivals.generation();
    uint8_t mac[6]={};esp_read_mac(mac,ESP_MAC_BT);
    battle.begin(uint32_t(mac[2])<<24|uint32_t(mac[3])<<16|uint32_t(mac[4])<<8|mac[5]);
    Serial.printf("BATTLE_LOAD found=%d rivals=%u on=%d\n",found,rivals.count(),battlesOn);
  }
  // Reclaim the orphaned RF calibration blob found in ll-practice; the history
  // save it would otherwise crowd out matters far more. Boot only, before ADC.
  if(practiceStore.hasOrphan())Serial.printf("NVS_RECLAIM key=ll-practice/%s removed=%d\n",PracticeStore::ORPHAN_KEY,practiceStore.removeOrphan());
  // What the radio saved under an earlier or unwrapped build (radio_calibration.h).
  RadioCalibration::reclaimAtBoot();
  practice.newSession(); // Boot starts a fresh metric/session boundary; old scalar history stays intact.
  referenceError=!motionStore.begin(referenceMotion);
  if(const auto *last=practice.recent()) {
    latestMotion.number=last->number;latestMotion.rpm=last->rpm;
    if(referenceMotion.valid() && referenceMotion.fused && referenceMotion.number==last->number)latestMotion=referenceMotion;
  }
  if(!pm1Idle().run([](){M5.Power.setExtOutput(extPower);return true;}))Serial.println("EXT_POWER_NOTICE startup_wake_failed");
  const bool idleConfigured=pm1Idle().configure();
  Serial.printf("PM1_IDLE_CONFIG ok=%d seconds=%u fallback_verified=%d\n",idleConfigured,
    unsigned(pm1Idle().stats().seconds),pm1Idle().stats().fallbackVerified);
  M5.Display.setRotation(DisplayOrientation::rotation(displayFlipped));M5.Display.setBrightness(backlightValue());M5.Display.setTextSize(1);
  // Internal RAM first, as stock, unless Bluetooth was on at boot: at 80 MHz a PSRAM
  // canvas made a recap frame about 8 ms slower to compose and push, but the stack
  // needs the internal RAM. Either way the other kind is the fallback if 64.8 KB
  // is not free there.
  const bool canvasPsram=BluetoothSetting::canvasInPsram(bluetoothAtBoot);
  screen.setColorDepth(16);screen.setPsram(canvasPsram);
  screenReady=screen.createSprite(M5.Display.width(),M5.Display.height())!=nullptr;
  if(!screenReady){screen.setPsram(!canvasPsram);screenReady=screen.createSprite(M5.Display.width(),M5.Display.height())!=nullptr;}
  if(!screenReady)Serial.println("DISPLAY_NOTICE direct_draw_fallback");
  if(saveError)Serial.println("HISTORY_ERROR storage unavailable; existing bytes retained");
  M5.BtnA.setHoldThresh(1000);M5.BtnB.setHoldThresh(1000);
  for(unsigned attempt=0;attempt<3 && !startMotion();++attempt)if(attempt<2)delay(100);
  if(!imuAcquisition.running())Serial.println("MOTION_NOTICE IMU startup failed; automatic idle retry enabled");
  acquisition.setRequestHook(quietImuForFlash);
  // What the ADC's continuous driver finds when it allocates (HEAP_BOOT).
  constexpr uint32_t DMA_HEAP=MALLOC_CAP_DMA|MALLOC_CAP_INTERNAL;
  const unsigned dmaFreeBeforeAdc=unsigned(heap_caps_get_free_size(DMA_HEAP)),dmaLargestBeforeAdc=unsigned(heap_caps_get_largest_free_block(DMA_HEAP));
  if(!acquisition.begin(pin,rpmEstimator,sensorProfile))Serial.println("ADC_ERROR acquisition_task_allocation");
  openLoadedEffects();
  pollBattery(millis(),acquisition.snapshot());
  powerRecord(wakingFromStandby?PowerDiagnostics::Wake:PowerDiagnostics::Boot,loggedWake);
  powerLogTick=lastPowerSample=millis();
  Serial.printf("POWER_WAKE esp_cause=%d pm1_flags_valid=%d pm1_flags=0x%02x pending_standby=%d\n",int(wakeCause),pm1WakeValid,pm1WakeFlags,wakingFromStandby);
  // Use hardware wake evidence; the optional diagnostic log can fail to save
  // and must not determine the battery policy.
  inactivity.begin(millis(),!keyWake && ((pm1WakeValid && (pm1WakeFlags&0x20)) || wakeCause==ESP_SLEEP_WAKEUP_EXT0));
  if(finishStandby) {
    // Unplugged during a USB-retained standby: the same power-off, on battery now.
    Serial.printf("USB_STANDBY_FINISH key_only=%d\n",standbyKeyOnly);
    if(standbyKeyOnly){powerKeyRequested=true;powerKeyRequestedAt=millis();}
    // Due at once, and like an unused shake wake past its limit, so handling
    // the unit as it is unplugged cannot keep it awake; a button still can.
    else inactivity.begin(millis()-InactivityTimer::UNUSED_SHAKE_LIMIT_MS,true);
  }
  Serial.printf("HEAP_BOOT before_adc_dma_free=%u before_adc_dma_largest=%u dma_free=%u dma_largest=%u internal_free=%u usb_rx_bytes=%u\n",
    dmaFreeBeforeAdc,dmaLargestBeforeAdc,unsigned(heap_caps_get_free_size(DMA_HEAP)),unsigned(heap_caps_get_largest_free_block(DMA_HEAP)),
    unsigned(heap_caps_get_free_size(MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)),unsigned(USB_RX_BUFFER_BYTES));
  Serial.printf("BOOT %s ppr=1 min_rpm=1000 min_mark=%.0f edge_fraction=%.2f sample_hz=50000 task_core=0\n",VERSION,
    StickS3SensorProfile::minMark(sensorProfile),StickS3SensorProfile::EDGE_SWING_FRACTION);
  Serial.printf("RPM_SETTING_BOOT selected=%s default=%s legacy_history=retained_metric_not_encoded\n",RpmEstimator::name(rpmEstimator),
    RpmEstimator::name(RpmEstimator::DEFAULT_MODE));
  Serial.println("READY commands: p status, P power log, C CPU power profiling, a/c tap A, h tap B, o hold A, b hold B, d diagnostics, n new session, u history export, J calibration export, K backup export, R backup restore, L custom themes, T theme request, M milestones, U milestone request, F loaded effects, X loaded-effect request, e motion export, q synthetic recap, E<0-4,7> best effect preview, t synthetic history, y/z storage check, v screen, w recorder export, x ext5V, g<N> GPIO, s stress, j UI stall");
#if LAUNCHLAB_HIL
  hilBoot();
#endif
#if LAUNCHLAB_POWER_LAB
  labBoot();
#endif
}

// A pull, leaving the recap or closing the Sound editor silences at once;
// the codec powers down once silent and no pull is being measured.
LOOP_HELPER static void tickSound(const Snapshot &s) {
  const bool measuring=s.phase==AnalogTachometer::Phase::Launch;
  using S=Controls::Setting;
  const bool effectEditor=controls.page==Controls::Page::Edit && controls.setting==unsigned(S::BestEffect);
  const bool celebrating=bestEffect.badge(),editing=effectEditor || (controls.page==Controls::Page::Edit && controls.setting==unsigned(S::Sound));
  if(editorEffect.badge() && !effectEditor){editorEffect.clear();dirty=true;}
  // A pull fades a song out within 20 ms and stops other sounds at once; a
  // song plays on past its effect's frames.
  if(measuring){soundPlayer.fadeOut();celebrationSound=soundPreview=false;}
  else if((celebrationSound && !celebrating && !soundPlayer.streaming()) || (soundPreview && !editing)) {
    soundPlayer.stop();celebrationSound=soundPreview=false;
  }
  if(soundRequest.active && (measuring || (soundRequest.celebration?!celebrating || bestEffect.elapsed(millis())>SOUND_LATE_MS:!editing)))
    soundRequest.active=false;
  if(!soundPlayer.playing())celebrationSound=soundPreview=false;
  soundPlayer.tick(measuring || motionPending);
  // A song's effect moves on with the song's first block (startSound), or
  // at once if the song stopped before it began.
  uint32_t begunMs=0;
  if(songCue && soundPlayer.songBegun(begunMs)) {
    const uint32_t at=SoundSync::clockStart(begunMs,soundPlayer.outputUs(),presentLagUs);
    soundShiftMs=int32_t(at-songCueFrom);songCue->align(at);songCue=nullptr;
  } else if(songCue && !soundPlayer.streaming()){songCue->align(millis());songCue=nullptr;}
#if LAUNCHLAB_HIL
  hilFeedProbe(soundPlayer.streaming(),hilStatusRuns,saveCount,lastDraw);
#endif
  updateStartFloor();updateLaunchFloor();
  if(measuring || motionPending || soundPlayer.muted)return;
  // Render a slice per idle pass (1/64 s of audio, a few ms): a waiting
  // request first, else the chosen effect, ready before the next best or the
  // first preview while the Sound editor is open, then every effect the
  // milestone table can play, since a milestone is known only once its pull ends.
  constexpr size_t SLICE=BestEffectSound::RATE/64;
  if(soundRequest.active) {
    if(soundPlayer.prepare(soundRequest.effect,SLICE))startSound(true);
    return;
  }
  const bool wanted=appearance.sound!=Appearance::Sound::Off || editing;
  if(!wanted)return;
  // The editor's preview holds its first frame for its sound: render all of
  // it now (about 0.3 s on the device) rather than a slice per pass.
  const bool waiting=editorEffect.badge() && !editorEffect.started();
  if(!soundPlayer.prepared(soundTarget())){soundPlayer.prepare(soundTarget(),waiting?SIZE_MAX:SLICE);return;}
  if(appearance.sound==Appearance::Sound::Off || !Milestones::milestones(milestones.mode()))return;
  const auto *picks=milestonePicks();
  for(unsigned i=0;i<milestones.count();++i) {
    const auto effect=picks[i];
    if(!soundPlayer.prepared(effect)){soundPlayer.prepare(effect,SLICE);return;}
  }
}

// USB only: replay the last recap with a celebration to check an effect on the
// device. Bests, history and settings are unchanged; max_effect_us and
// max_draw_us restart so PERF reports this preview's slowest pass and frame.
LOOP_HELPER static void previewBestEffect(Appearance::Effect effect) {
#if LAUNCHLAB_HIL
  HilFx::playing=-1;
#endif
  if(tournamentMode || motionPending || !latestMotion.number){Serial.println("EFFECT_PREVIEW_ERROR no_recap");return;}
  if(controls.page==Controls::Page::Analysis){leaveMicPage();if(controls.page==Controls::Page::Analysis)return;}
  if(controls.page==Controls::Page::Edit)cancelSettingEdit();
  controls.page=Controls::Page::Main;syncNavigation();
  historyPage=diagnostics=motionDemo=demo=false;
  // A preview may pick an effect other than the saved one: render its sound
  // here, before the recap and its timing start, rather than miss its cue.
  uint32_t renderUs=0;
  if(appearance.sound!=Appearance::Sound::Off && !soundPlayer.prepared(effect)) {
    soundPlayer.stop();const int64_t started=esp_timer_get_time();
    soundPlayer.prepare(effect);renderUs=uint32_t(esp_timer_get_time()-started);
  }
  launchFeedback.show(millis(),LaunchFeedback::Replay::Twice,MotionReplay::playbackDurationMs(latestMotion));
  bestEffect.queue(true,latestMotion.number,effect);bestEffect.captured(latestMotion.number);
  maxEffectUs=maxDrawUs=0;dirty=true;
#if LAUNCHLAB_HIL
  effectFrames.count=0;
#ifdef BEST_EFFECT_PROFILE
  effectStages.count=0;
#endif
#endif
  Serial.printf("EFFECT_PREVIEW effect=%s duration_ms=%lu launch=%lu sound_render_us=%lu bests_unchanged=1\n",Appearance::label(effect),
    (unsigned long)Appearance::duration(effect),(unsigned long)latestMotion.number,(unsigned long)renderUs);
}

// USB commands, bounded per pass. A real call: its inlined handlers once made
// up most of loop()'s frame.
LOOP_HELPER static void exportCpuPower() {
#if LAUNCHLAB_CPU_PM
  // IDF's stdout is UART, whereas this device uses native USB. Buffer its
  // profiling report so a read-only USB command can retrieve idle mode times.
  constexpr size_t bytes=8192;
  auto buffer=std::unique_ptr<char[]>(new(std::nothrow) char[bytes]);
  FILE *stream=buffer?fmemopen(buffer.get(),bytes,"w"):nullptr;
  if(!stream){Serial.println("CPU_PM_TRACE error=no_buffer");return;}
  const int result=CpuPower::dump(stream);fflush(stream);
  const long length=ftell(stream);fclose(stream);
  Serial.printf("CPU_PM_TRACE begin enabled=%d error=%s\n",CpuPower::active(),esp_err_to_name(result));
  if(length>0)Serial.write(reinterpret_cast<const uint8_t*>(buffer.get()),std::min<size_t>(size_t(length),bytes-1));
  Serial.println("CPU_PM_TRACE end");
#else
  Serial.println("CPU_PM_TRACE enabled=0");
#endif
}

// One accepted USB command (usb_command_guard.h): a letter, "g<pin>" or
// "E[<digit>]".
LOOP_HELPER static void runUsbCommand(const char *command,const Snapshot &s) {
  const char c=command[0];
  if(c=='g') {
    char *end=nullptr;const long pin=strtol(command+1,&end,10);
    if(end!=command+1 && *end==0 && pin>=1 && pin<=10) {
      if(acquisition.request(Action::Pin,uint8_t(pin)))settingsSave.mark(SettingsSave::Pin);
      else Serial.println("COMMAND_ERROR gpio_init");
      dirty=true;
    } else Serial.println("COMMAND_ERROR gpio_must_be_1_to_10");
    return;
  }
  if(c=='E') {
    // E<id> previews that effect (its stored value, one to three digits: a
    // loaded effect is 96-127); E alone the saved one.
    const unsigned id=command[1]?unsigned(strtoul(command+1,nullptr,10)):255u;
    previewBestEffect(Appearance::celebrates(id)?Appearance::Effect(id):celebrationEffect());
    return;
  }
  if(c=='p')status();
  else if(c=='P')exportPowerLog();
  else if(c=='C')exportCpuPower();
  else if(c=='S'){
    inactivity.touch(millis()-inactivity.timeout());
    Serial.println("POWER_SLEEP_TEST requested=1 normal_save_and_sleep_path=1");
  }
  else if(c=='O'){
    powerKeyRequested=true;powerKeyRequestedAt=millis();
    Serial.println("POWER_KEY_TEST requested=1 normal_save_and_power_off_path=1");
  }
  else if(c=='i') {
    if(acquisition.request(Action::IdleCheckpointBegin,s.launches)) {
      if(imuAcquisition.lock()) {
        const bool armed=shakeWake.arm(),restored=shakeWake.restore();
        if(!restored)noteMotionRestoreFailure();
        const bool extRestored=pm1Idle().run([](){M5.Power.setExtOutput(extPower);return true;});
        imuAcquisition.unlock();
        if(!extRestored)Serial.println("EXT_POWER_NOTICE test_restore_wake_failed");
        Serial.printf("SHAKE_WAKE_CHECK armed=%d restored=%d sleep=0\n",armed,restored);
      }
      acquisition.request(Action::CheckpointEnd);
    }
  }
  else if(c=='a'){noteWearTap("usb_a");buttonA();}
  else if(c=='o')holdA();
  else if(c=='d'){diagnostics=!diagnostics;dirty=true;}
  else if(c=='h')toggleHistory();
  else if(c=='c'){noteWearTap("usb_c");nextView();}
  else if(c=='e')exportMotion();
  else if(c=='Q'){const bool ok=imuAcquisition.quiet(300);Serial.printf("IMU_QUIET_TEST ms=300 ok=%d flash_write=0\n",ok);}
  else if(c=='q') {
    if(tournamentMode){Serial.println("RECAP_DEMO_ERROR leave_tournament_first");return;}
    if(controls.page==Controls::Page::Analysis){leaveMicPage();if(controls.page==Controls::Page::Analysis)return;}
    if(controls.page==Controls::Page::Edit)cancelSettingEdit();
    controls.page=Controls::Page::Main;syncNavigation();
    historyPage=diagnostics=false;motionDemo=true;
    MotionUI::makeDemo(demoMotion,false);
    launchFeedback.show(millis(),LaunchFeedback::Replay::Twice,MotionReplay::playbackDurationMs(demoMotion));dirty=true;
    Serial.println("RECAP_DEMO synthetic only; real launches and reference unchanged");
  }
  else if(c=='b')holdB();
  else if(c=='n')newSession();
  else if(c=='u')exportHistory();
  else if(c=='K')exportBackup();
  else if(c=='R')startRestore();
  else if(c=='L')listThemes();
  else if(c=='T'){themeRx.start(millis());Serial.printf("THEME_READY max_chars=%u\n",unsigned((Themes::Request::BYTES+2)/3*4));themeReply();}
  else if(c=='M')listMilestones();
  else if(c=='F')listEffects();
  else if(c=='X')startEffectRequest();
  else if(c=='m') {
    // Analysis from the Main screen or the Menu, and back, as its menu row and a
    // hold of B would: firmware/tools/mic_capture.py, HIL.
    const auto previous=controls.page;
    if(controls.page==Controls::Page::Analysis)controls.page=Controls::Page::Main;
    else if(controls.page==Controls::Page::Main || controls.page==Controls::Page::Menu){controls.page=Controls::Page::Analysis;controls.menu=Controls::ANALYSIS_ROW;}
    else {Serial.println("MIC_STATE error=busy_page");return;}
    navigate(Controls::Effect::None,previous);syncNavigation();dirty=true;
  }
  else if(c=='J')exportCalibration();
  else if(c=='Z')exportCalibrationBatch();
  else if(c=='G')exportLaunchWavs();
  else if(c=='A')micListener.dump();
  else if(c=='Y')micListener.askBench();
  else if(c=='W')micListener.armTape();
  else if(c=='V')micListener.sendTape();
  else if(c=='U'){milestoneRx.start(millis());Serial.printf("MILESTONE_READY max_chars=%u\n",unsigned((Milestones::Request::BYTES+2)/3*4));milestoneReply();}
  else if(c=='t')previewHistory();
  else if(c=='y')checkStorage();
  else if(c=='z')checkMotionStorage();
  else if(c=='v')exportScreen();
  else if(c=='w')exportSignal();
  else if(c=='x') {
    // Explicit command only. No automatic voltage/power changes in sampling.
    if(!imuAcquisition.lock()){Serial.println("COMMAND_ERROR power_busy");return;}
    const bool nextExtPower=!extPower;
    const bool changed=pm1Idle().run([&](){M5.Power.setExtOutput(nextExtPower);return true;});
    imuAcquisition.unlock();
    if(changed){extPower=nextExtPower;settingsSave.mark(SettingsSave::ExtPower);}
    else Serial.println("EXT_POWER_NOTICE toggle_wake_failed");
    acquisition.request(Action::Reset);dirty=true;status();
  } else if(c=='s'){stress=!stress;diagnostics=true;dirty=true;}
  else if(c=='j'){++uiStalls;delay(200);}
}

LOOP_HELPER static void pollCommands(const Snapshot &s) {
  // Stray bytes (an upload gone wrong, a buggy updater, line noise) must not
  // run state-changing letters: see usb_command_guard.h.
  auto &guard=usbCommands;char command[UsbCommandGuard::MAX+1];
  if(controls.page==Controls::Page::Wipe || wipeBlocked) {
    restoreRx.cancel();themeRx.cancel();milestoneRx.cancel();effectRx.cancel();guard.cancel();
  } else {
    if(restoreRx.active())pollRestore(s);
    if(themeRx.active())pollThemeRequest(s);
    if(milestoneRx.active())pollMilestoneRequest(s);
    if(effectRx.active())pollEffectRequest(s);
    // Quiet is the receive queue seen empty, not a slow pass.
    if(!Serial.available())guard.idle(millis());
    if(guard.due(millis(),command))runUsbCommand(command,s);
  }
  // Bound incoming work; an unending USB stream cannot starve button/draw work.
  for(unsigned n=0;n<32 && !restoreRx.active() && !themeRx.active() && !milestoneRx.active() && !effectRx.active() && Serial.available();++n) {
    const char c=Serial.read();const uint32_t now=millis();
    // Wipe confirmations and the final hold belong to physical buttons.
    // Read-only status and cancellation cannot advance the confirmation.
    if(controls.page==Controls::Page::Wipe || wipeBlocked) {
      if(c=='p')status();else if(c=='b' && !wipeBlocked)cancelWipe();
      continue;
    }
    if(guard.drop(c,now))continue;  // the rest of a line whose transfer was refused or timed out
#if LAUNCHLAB_HIL
    if(hilFeed(c)){guard.consumed(c,now);continue;}
#endif
#if LAUNCHLAB_POWER_LAB
    if(labFeed(c)){guard.consumed(c,now);continue;}
#endif
    // Status polling is observational; other explicit USB actions count as use.
    if(c!='p' && c!='P' && c!='C' && c!='\n' && c!='\r')inactivity.touch(now);
    if(guard.due(now,command))runUsbCommand(command,s);
    if(guard.feed(c,now,command))runUsbCommand(command,s);
    if(controls.page==Controls::Page::Wipe || wipeBlocked)guard.cancel();
  }
  if(!Serial.available())guard.idle(millis());
}

#if LAUNCHLAB_MOTION_ADC_GATE
#if LAUNCHLAB_POWER_LAB
static uint32_t labPauseTryMs=0;
#endif
LOOP_HELPER static void tickSensorIdle(uint32_t now,Snapshot &s) {
  const auto imu=imuAcquisition.snapshot();
#if LAUNCHLAB_HIL
  const bool usbBlocks=usbAwake.inhibited(now) && !Hil::usbIdle; // Rest with the rig attached.
#else
  const bool usbBlocks=usbAwake.inhibited(now);
#endif
#if LAUNCHLAB_POWER_LAB
  // a1 keeps sampling, as a unit in a moving hand does; a2 pauses whenever the detector allows.
  const bool labBlocks=Lab::running && Lab::knobs.adc==1;
  if(Lab::running && Lab::knobs.adc==2) {
    const bool idle=s.ready && !s.suspended && !s.signalFault && s.opticalIdle && s.phase==AnalogTachometer::Phase::Ready;
    if(s.resting || !idle || now-labPauseTryMs<1000)return;
    labPauseTryMs=now;
    const bool ok=acquisition.request(Action::IdlePause,s.launches);s=acquisition.snapshot();dirty=true;
    Serial.printf("SENSOR_IDLE_CHANGE pause=1 ok=%d resting=%d state=%s lab=1\n",ok,s.resting,s.stateName());
    return;
  }
#else
  constexpr bool labBlocks=false;
#endif
  const bool blocked=usbBlocks || labBlocks || inactivity.unusedShake() || wipeBlocked ||
    controls.page!=Controls::Page::Main || historyPage || diagnostics || tournamentMode ||
    motionPending || launchFeedback.shown() || historyUnsaved() ||
    bestsUnsaved() || settingsSave.pending() || !imuAcquisition.running() || Serial.available();
  const bool opticalIdle=s.ready && !s.suspended && !s.signalFault && s.opticalIdle &&
    s.phase==AnalogTachometer::Phase::Ready;
  const auto action=sensorIdle.decide(now,esp_timer_get_time(),imu.activity,inactivity.elapsed(now),
    s.resting,opticalIdle,blocked,PowerSavers::settings.restMs);
  if(action==SensorIdle::Action::None)return;
  const bool pause=action==SensorIdle::Action::Pause;
  const bool ok=acquisition.request(pause?Action::IdlePause:Action::IdleResume,s.launches);
  sensorIdle.attempted(now,action,ok);s=acquisition.snapshot();dirty=true;
  Serial.printf("SENSOR_IDLE_CHANGE pause=%d ok=%d resting=%d state=%s sensor_power=on_shared_rail\n",
    pause,ok,s.resting,s.stateName());
}
#endif

// One phone command (docs/BLE_PROTOCOL.md), run from the loop.
namespace BleCommands {
constexpr int32_t OK=0,INVALID=1,BUSY=2,HIDDEN=3,UNKNOWN=4;
static uint8_t *put32(uint8_t *p,uint32_t v){memcpy(p,&v,4);return p+4;}
static uint8_t *put16(uint8_t *p,uint16_t v){memcpy(p,&v,2);return p+2;}
static uint8_t *putF(uint8_t *p,float v){memcpy(p,&v,4);return p+4;}
static bool editing(){return controls.page==Controls::Page::Edit || controls.page==Controls::Page::Wipe || wipeBlocked;}
static bool validValue(unsigned id,uint8_t v) {
  using S=Controls::Setting;
  switch(S(id)) {
    case S::Sleep:return InactivityTimer::validMinutes(v);
    case S::Brightness:return Brightness::valid(v);
    case S::Flip:case S::ShakeWake:case S::BatteryIcon:return v<=1;
    case S::Theme:return v<Appearance::ALL_THEMES;
    case S::Celebrate:case S::Sound:return v<3;
    case S::Mount:return MountOrientation::valid(v);
    case S::MinRpm:return MinRpm::valid(v);
    default:return Controls::editable(id); // applySetting checks the rest.
  }
}
LOOP_HELPER static int32_t setSetting(unsigned id,uint8_t value) {
  // Bluetooth off from the phone: the status goes first, then the loop saves and
  // restarts as the stick's own toggle does. On takes the stick: the radio is off then.
  if(id==unsigned(Controls::Setting::Bluetooth)) {
    if(value)return INVALID;
    if(tournamentMode || editing() || motionPending || acquisition.snapshot().phase==AnalogTachometer::Phase::Launch)return BUSY;
    if(bluetoothOn){bluetoothOn=false;settingsSave.mark(SettingsSave::Bluetooth);dirty=true;}
    return OK;
  }
  if(!Controls::editable(id) || !validValue(id,value))return INVALID;
  if(tournamentMode || editing())return BUSY;
  bool changed=false;
  if(!applySetting(id,value,changed))return INVALID;
  if(changed)settingsSave.mark(SettingsSave::item(id));
  restorePreview=true;previewSetting();saveSettings(millis(),acquisition.snapshot(),true);dirty=true;
  return OK;
}
LOOP_HELPER static size_t putOption(uint8_t *out,size_t at,size_t capacity,unsigned id,uint8_t value) {
  char label[24];ControlsUI::value(label,sizeof(label),id,value);
  const size_t n=strlen(label);
  if(at+2+n>capacity)return at;
  out[at]=value;out[at+1]=uint8_t(n);memcpy(out+at+2,label,n);return at+2+n;
}
LOOP_HELPER static size_t options(unsigned id,uint8_t *out,size_t capacity) {
  using S=Controls::Setting;size_t at=0;
  switch(S(id)) {
    case S::Sleep:for(unsigned v=1;v<=10;++v)at=putOption(out,at,capacity,id,v);break;
    case S::Brightness:for(unsigned v=10;v<=100;v+=10)at=putOption(out,at,capacity,id,v);break;
    case S::Rpm:case S::Flip:case S::Sensor:case S::Mount:case S::ShakeWake:case S::BatteryIcon:case S::Bluetooth:
      for(unsigned v=0;v<2;++v)at=putOption(out,at,capacity,id,v);break;
    case S::Celebrate:case S::Sound:for(unsigned v=0;v<3;++v)at=putOption(out,at,capacity,id,v);break;
    case S::MinRpm:for(unsigned v=MinRpm::MIN_STEPS;v<=MinRpm::MAX_STEPS;++v)at=putOption(out,at,capacity,id,v);break;
    case S::Theme:
      for(unsigned v=0;v<Appearance::ALL_THEMES;++v)if(themeLibrary.available(Appearance::Theme(v)))at=putOption(out,at,capacity,id,v);
      break;
    case S::BestEffect:
      EffectSet::choices(appearance.effect,effectSet.mask(),[&](Appearance::Effect e){at=putOption(out,at,capacity,id,uint8_t(e));});
      break;
    case S::WipeAll:case S::About:break;
  }
  return at;
}
// Live orientation, event type 2: the fusion's latest pose about ten times a
// second while a paired phone has asked for it. It keeps running at RESTING,
// which pauses only the optical ADC, and stops for the length of a pull.
LOOP_HELPER static void tickLiveOrientation(uint32_t now,const Snapshot &s) {
  if(!BleLink::liveOrientationOn())return;
  static BleMotion::Gate gate;LaunchMotion::Quaternion pose;
  if(!gate.due(now,s.phase==AnalogTachometer::Phase::Launch,imuAcquisition.latestPose(pose,esp_timer_get_time())))return;
  uint8_t event[BleMotion::POSE_BYTES];BleMotion::encodePose(pose,event);
  BleLink::publishEvent(event,sizeof(event));
}
// A pairing's number on screen: A confirms and B rejects, and they do nothing else
// meanwhile. A pull rejects it: the screen is frozen for the measurement. True while it shows.
LOOP_HELPER static bool answerPairing(bool buttonsFresh,const Snapshot &s) {
  uint32_t number=0;bool automatic=false;
  if(!BleLink::comparison(number,automatic))return false;
  // A pending pairing prompt must not consume the button that stops a spin.
  if(analysis.running() || calibrationCapturePending){BleLink::answerComparison(false);dirty=true;return false;}
  bool answered=true;
  if(s.phase==AnalogTachometer::Phase::Launch)BleLink::answerComparison(false);
  else if(buttonsFresh && M5.BtnA.wasClicked())BleLink::answerComparison(true);
  else if(buttonsFresh && M5.BtnB.wasClicked())BleLink::answerComparison(false);
  else answered=false;
  if(answered){gestureA.consumed=gestureB.consumed=true;dirty=true;}
  return true;
}
LOOP_HELPER static int32_t run(uint8_t op,const uint8_t *args,size_t length,uint8_t *out,size_t capacity) {
  const uint32_t now=millis();uint8_t *p=out;
  const size_t room=capacity;
  switch(op) {
    case 1: {
      const auto *last=practice.recent();const auto *session=practice.session(0);
      *p++=1;p=put32(p,last?last->number:0);p=put32(p,session?session->number:0);
      p=put16(p,uint16_t(practice.size()));p=put16(p,uint16_t(practice.sessions()));*p++=tournamentMode;
      const size_t n=strlen(VERSION);*p++=uint8_t(n);memcpy(p,VERSION,n);p+=n;
      const char *name=BleLink::fullName();const size_t nameLength=strlen(name);
      *p++=uint8_t(nameLength);memcpy(p,name,nameLength);p+=nameLength;
      *p++=0; // levelSet: no level reference in this firmware
      break;
    }
    case 2:for(unsigned i=0;i<Controls::SETTING_COUNT;++i)if(Controls::editable(i)){*p++=uint8_t(i);*p++=settingValue(i);}break;
    case 3:
      if(length!=2)return -INVALID;
      *p++=uint8_t(setSetting(args[0],args[1]));
      break;
    case 4: {
      const auto s=acquisition.snapshot();const auto tilt=level.reading(now);
      *p++=uint8_t(int8_t(battery.valid(now)?battery.percent:-1));p=put16(p,battery.millivolts);
      *p++=battery.chargeName()[0]=='u'?2:battery.chargeName()[0]=='c'?1:0;
      *p++=s.signalFault?3:s.phase==AnalogTachometer::Phase::Launch?1:s.resting?2:0;
      p=putF(p,tilt.valid()?tilt.degrees:NAN);
      p=put32(p,uint32_t((PhoneLinkAwake::remaining(BleLink::connected(),inactivity.sinceUse(now),inactivity.remaining(now))+999)/1000));
      break;
    }
    case 5: {
      if(tournamentMode)return -HIDDEN;
      if(length!=4)return -INVALID;
      uint32_t from=0;memcpy(&from,args,4);
      for(unsigned i=practice.size();i>0 && size_t(p-out)+16<=room;--i) {
        const auto &r=*practice.recent(i-1);
        if(r.number<from)continue;
        p=put32(p,r.number);p=put32(p,r.session);p=putF(p,r.rpm);p=put32(p,r.seconds);
      }
      break;
    }
    case 6:
      if(tournamentMode)return -HIDDEN;
      for(unsigned i=practice.sessions();i>0 && size_t(p-out)+20<=room;--i) {
        const auto &r=*practice.session(i-1);
        p=put32(p,r.number);p=put32(p,r.count);p=putF(p,r.mean());p=putF(p,r.best);p=put32(p,r.seconds);
      }
      break;
    case 7:
      if(length!=1 || !Controls::editable(args[0]))return -INVALID;
      return int32_t(options(args[0],out,capacity));
    case 8: {
      if(tournamentMode)return -HIDDEN;
      const auto &c=latestCurve;unsigned peak=0;
      for(unsigned i=1;i<c.count;++i)if(c.rpm[i]>c.rpm[peak])peak=i;
      p=put32(p,latestMotion.number);p=put16(p,c.count?c.rpm[peak]:0);p=put16(p,c.count);p=put16(p,0); // leadMs: the curve starts at its first point
      for(unsigned i=0;i<c.count;++i){p=put16(p,c.ms[i]);p=put16(p,c.rpm[i]);}
      break;
    }
    case 9:
      if(tournamentMode || editing()){*p++=BUSY;break;}
      newSession();dirty=true;*p++=OK;
      break;
    case 10:
      for(unsigned i=0;i<powerLog.count && size_t(p-out)+13<=room;++i) {
        const auto &r=powerLog.records[(powerLog.next+PowerDiagnostics::CAPACITY-powerLog.count+i)%PowerDiagnostics::CAPACITY];
        p=put32(p,uint32_t(r.elapsedSeconds));p=put32(p,r.boot);p=put16(p,r.batteryMv);
        *p++=r.event;*p++=r.flags;*p++=r.brightness;
      }
      break;
    case 15:
      if(length!=1 || args[0]>1){*p++=INVALID;break;}
      darkDisplay.set(!args[0] && BleLink::secured());dirty=true;*p++=OK;
      break;
    case 13:
      if(length<2 || size_t(args[0])!=length-1 || !BleName::valid(reinterpret_cast<const char *>(args)+1,args[0])){*p++=INVALID;break;}
      if(tournamentMode || editing()){*p++=BUSY;break;}
      BleLink::setName(reinterpret_cast<const char *>(args)+1,args[0]);
      settingsSave.mark(SettingsSave::Name);saveSettings(millis(),acquisition.snapshot(),true);
      *p++=OK;
      break;
    case 12:
      if(length!=1 || args[0]>1){*p++=INVALID;break;}
      if(tournamentMode){*p++=BUSY;break;}
      BleLink::setLiveOrientation(args[0]);*p++=OK;
      break;
    case 11: {
      if(tournamentMode)return -HIDDEN;
      if(motionPending)return -BUSY;
      // Off the loop stack, as exportMotion: the poses the recap itself draws.
      auto replay=std::unique_ptr<MotionReplay::Replay>(new(std::nothrow) MotionReplay::Replay);
      if(!replay)return -BUSY;
      return int32_t(BleMotion::encodeReplay(latestMotion,*replay,out,capacity));
    }
    case 16:return int32_t(Battle::report(rivals,out,capacity));
    // 14 Set level reference is in the protocol but not in this firmware:
    // unknown command, which an app reads as not supported.
    default:return -UNKNOWN;
  }
  return int32_t(p-out);
}
}

void loop() {
  CpuPower::Guard clock(CpuPower::Ui);
  bool buttonsFresh=false;
  if(imuAcquisition.lock()){M5.update();imuAcquisition.unlock();buttonsFresh=true;}
  Snapshot s=acquisition.snapshot();
  BleLink::handler=BleCommands::run;controls.bluetoothOn=bluetoothOn;
  BleLink::setPromptBusy(s.phase==AnalogTachometer::Phase::Launch || motionPending || tournamentMode || wipeBlocked ||
    analysis.running() || calibrationCapturePending ||
    controls.page==Controls::Page::Edit || controls.page==Controls::Page::Wipe);
  if(BleLink::tick(millis(),bluetoothAtBoot,s.phase==AnalogTachometer::Phase::Launch))dirty=true;
  if(BleLink::takeBondsChanged()){settingsSave.mark(SettingsSave::Bonds);dirty=true;}
  BattlePassFeed::tick(millis());
  BattlePassFeed::tickButton(buttonsFresh,controls.page==Controls::Page::BeybladeX);
  BattleFeed::tick(millis(),s);
  BleCommands::tickLiveOrientation(millis(),s);
  restartForBluetooth(millis(),s);
  if(buttonsFresh && heldButtons.use(millis(),M5.BtnA.isPressed() || M5.BtnB.isPressed(),M5.BtnA.wasReleased() || M5.BtnB.wasReleased()))
    inactivity.touch(millis());
#if LAUNCHLAB_HIL
  // Nothing presses the rig's buttons: every physical edge is worth a line
  // (a Wear check reset with no USB key behind it, 2026-10-27).
  if(buttonsFresh && (M5.BtnA.wasPressed() || M5.BtnA.wasReleased() || M5.BtnB.wasPressed() || M5.BtnB.wasReleased()))
    Serial.printf("HIL_BUTTON a=%d b=%d a_pressed=%d a_released=%d b_pressed=%d b_released=%d ms=%lu\n",
      M5.BtnA.isPressed(),M5.BtnB.isPressed(),M5.BtnA.wasPressed(),M5.BtnA.wasReleased(),
      M5.BtnB.wasPressed(),M5.BtnB.wasReleased(),(unsigned long)millis());
#endif
  if(wipeBlocked) {
    pollWipe(millis(),buttonsFresh,s);
    // Nothing saves here, but the side key and the timer still power off.
    pollPowerKey(millis());
    wipeBlockedPowerOff(millis());
#if LAUNCHLAB_HIL
    // Only the HIL commands a blocked unit allows (hil.h, Hil::blockedCommand).
    for(unsigned n=0;n<32 && Serial.available();++n)hilFeed(char(Serial.read()));
#endif
    tickDisplayPower(millis(),s);
    if(dirty){draw(s);lastDraw=millis();dirty=false;}
    clock.release();delay(IdlePowerPolicy::UI_POLL_MS);return;
  }
  pollLevel(millis());
  if(controls.page==Controls::Page::WearCheck) {
    const auto rawTilt=level.reading(millis());
    controls.wear.observeLevel(rawTilt,s.phase==AnalogTachometer::Phase::Launch);
    observeWearMount(rawTilt);
    const auto stepBefore=controls.wear.step();
    const auto stageBefore=controls.wear.stage();
    const auto unmeasured=controls.wear.observeOptics(s.detectorUs,s.strongTurns,wearDetectorReady(s),
      s.ready && !s.suspended && !s.signalFault && s.phase!=AnalogTachometer::Phase::Settling && s.phase!=AnalogTachometer::Phase::Paused);
    if(unmeasured!=WearCheck::Outcome::None)logWearPull(stageBefore,unmeasured,0.0f);
    if(controls.wear.step()!=stepBefore) {
      inactivity.touch(millis());dirty=true;
      Serial.printf("WEAR_CHECK_STEP step=%s t_us=%llu\n",WearCheck::stepName(controls.wear.step()),(unsigned long long)s.detectorUs);
    }
    if(!controls.wear.complete() && uint32_t(millis()-lastDraw)>=100) {
      const auto tilt=StickS3Level::forDisplay(rawTilt,visibleDisplayFlipped());
      if(tilt.state!=drawnLevel.state || (tilt.valid() &&
        (std::fabs(tilt.degrees-drawnLevel.degrees)>=0.15f ||
         std::fabs(tilt.right-drawnLevel.right)>=0.02f ||
         std::fabs(tilt.down-drawnLevel.down)>=0.02f)))dirty=true;
    }
  }
#if LAUNCHLAB_MOTION_ADC_GATE
  tickSensorIdle(millis(),s);
#endif
  if(controls.page==Controls::Page::Wipe)pollWipe(millis(),buttonsFresh,s);
  else if(BleCommands::answerPairing(buttonsFresh,s)){}
  else if(buttonsFresh) {
    const bool clickedA=gestureA.click(M5.BtnA.wasPressed(),M5.BtnA.wasHold(),M5.BtnA.wasClicked());
    const bool clickedB=gestureB.click(M5.BtnB.wasPressed(),M5.BtnB.wasHold(),M5.BtnB.wasClicked());
    if(M5.BtnA.wasHold())holdA();else if(clickedA){noteWearTap("button");buttonA();}
    if(M5.BtnB.wasHold())holdB();else if(clickedB)buttonB();
    wakeDisplayOnPress(M5.BtnA.wasPressed() || M5.BtnB.wasPressed());
  }
  if(wipeBlocked)return;
  pollCommands(s);
  if(calibrationCapturePending && uint32_t(millis()-lastCaptureTry)>=1000)captureStoppedCalibration();
  const bool analysisOpen=controls.page==Controls::Page::Analysis;
  if(analysisOpen) {
    const auto now=esp_timer_get_time();
    if(analysis.tick(now)) {
      captureStoppedCalibration();
      inactivity.touch(millis());
      dirty=true;
    }
    const uint32_t sinceDraw=millis()-lastDraw;
    const bool graphVisible=!analysis.replay() && !analysis.results();
    if(analysisResults.busy() && !analysis.running() && graphVisible && sinceDraw>=250)dirty=true;
    const auto replayDuration=analysis.replay()?MotionReplay::playbackDurationMs(latestMotion):0;
    if(analysis.needsFrame(now,sinceDraw,replayDuration))dirty=true;
  }
  tickMicPage();
  const bool resultsWereReady=analysisResults.ready();
  if(analysisResults.tick(analysisOpen && !calibrationCapturePending,analysis,micListener.trace(),0,
                          micListener.audioMetadata(analysis.number()))) {
    dirty=true;
    const bool completed=!resultsWereReady && analysisResults.ready();
    captureCalibration(completed);
    if(completed)logAnalysisResults();
  }
  if(analysisOpen && analysis.running())observeForecastCheckpoint(unsigned(analysis.elapsedUs(esp_timer_get_time())/1000));
  if(analysisResults.recordPending())settingsSave.mark(SettingsSave::AnalysisResult);
  pollPowerKey(millis());
  Snapshot event;
#if LAUNCHLAB_HIL
  if(hilFlushPull.armed && s.launches!=hilFlushPull.launches) {
    hilFlushPull.armed=false;hilFlushPull.holding=true;powerKeyRequested=true;powerKeyRequestedAt=millis();
    Serial.printf("HIL_FLUSH_PULL off_requested launches=%lu\n",(unsigned long)s.launches);
  }
  if(!hilFlushPull.holding)
#endif
  while(acquisition.takeEvent(event))routeEvent(event,millis(),true);
  s=acquisition.snapshot();
  const uint32_t now=millis();
  if(s.phase==AnalogTachometer::Phase::Launch || motionDemo || tournamentMode || historyPage || diagnostics){
    if(bestEffect.badge()){bestEffect.clear();dirty=true;}else bestEffect.clear();
  }
  // A celebration runs about as long as the recap (5 s) and starts with its
  // first frame: the recap stays until the effect has ended and the readout
  // has shown clean for CELEBRATION_HOLD_MS.
  const bool celebrationHolds=bestEffect.badge() && bestEffect.started() &&
    bestEffect.elapsed(now)<Appearance::duration(bestEffect.effect())+CELEBRATION_HOLD_MS;
  if(!celebrationHolds && launchFeedback.tick(now)){dirty=true;motionDemo=false;Serial.printf("MAIN_FEEDBACK shown=0 reason=timeout t_ms=%lu\n",(unsigned long)now);}
  if(!launchFeedback.shown())bestEffect.clear();
  // A pull being measured is use; marks that go on far longer are not.
  if(opticalGuard.measuring(now,s.phase==AnalogTachometer::Phase::Launch))inactivity.touch(now);
  finishMotion();
  retryMotion(now,s);
  saveHistory(now,s);s=acquisition.snapshot();
  saveRivals(now,s);
  saveSettings(now,s);s=acquisition.snapshot();
  releaseOrphanCheckpoint(now,s);
  pollBattery(now,s);
  tickPowerLog(now,s);
  tickHistoryLog(now,s);
  pollUsbAwake(now,s);
  tickSound(s);
#if LAUNCHLAB_MOTION_ADC_GATE
  tickSensorIdle(millis(),s);
#endif
  if(restorePreview)previewSetting();
  powerKeyOff(now,s);
  autoPowerOff(now,s);
  tickDisplayPower(millis(),acquisition.snapshot());
  tickDarkDisplay(now);
  if(newSessionAt && now-newSessionAt>=1500){newSessionAt=0;dirty=true;}
  if(stress && now-lastDraw>=50)dirty=true;
  if((M5.BtnA.isPressed() || M5.BtnB.isPressed()) && now-lastDraw>=50)dirty=true;
  if(tournamentHintUntil && int32_t(now-tournamentHintUntil)>=0){tournamentHintUntil=0;dirty=true;}
  if(diagnostics && now-lastDraw>=500)dirty=true;
  if(historyPage && historyView==PracticeUI::View::Battery && now-lastDraw>=1000)dirty=true;
  const bool effectMoving=bestEffect.moving(now) || editorEffect.moving(now);
  if((effectMoving || effectWasMoving) && now-lastDraw>=50)dirty=true;
  // One final clean frame removes the decoration; the NEW BEST label stays.
  if(dirty && (stress || s.phase!=AnalogTachometer::Phase::Launch))effectWasMoving=effectMoving;
  if(!tournamentMode && !diagnostics && !historyPage && launchFeedback.shown() && !motionPending &&
     MotionReplay::playbackNeedsFrame(motionDemo?demoMotion:latestMotion,
       launchFeedback.position(launchFeedback.replayElapsed(now)),launchFeedback.position(launchFeedback.lastReplayElapsed())) && now-lastDraw>=50)dirty=true;
  if(!tournamentMode && !diagnostics && !historyPage && !launchFeedback.shown() && now-lastDraw>=100) {
    const auto tilt=StickS3Level::forDisplay(level.reading(now),visibleDisplayFlipped());
    if(tilt.state!=drawnLevel.state || (tilt.valid() &&
      (std::fabs(tilt.degrees-drawnLevel.degrees)>=0.15f ||
       std::fabs(tilt.right-drawnLevel.right)>=0.02f || std::fabs(tilt.down-drawnLevel.down)>=0.02f)))dirty=true;
  }
#if LAUNCHLAB_POWER_LAB
  labTick(now);
  // A sleeping panel draws nothing; a frame cap holds ordinary redraws back.
  const bool labDraw=!Lab::displayAsleep && (!Lab::running || !Lab::knobs.frameMs || now-lastDraw>=Lab::knobs.frameMs*10u);
#else
  constexpr bool labDraw=true;
#endif
  // Avoid electrical display changes through an ordinary measured burst.
  // Stress mode intentionally exercises the screen even during a burst.
  // A dark screen stays due for its frame, so a press shows the latest at once.
  if(dirty && labDraw && (stress || s.phase!=AnalogTachometer::Phase::Launch) && !displayDark(now)) {
    draw(s);lastDraw=millis();dirty=false;
  }
  if(Serial && now-lastStatus>=2000){lastStatus=now;status();}
  // ADC and IMU owners retain their own clocks and priorities. Avoid waking
  // this UI task 1,000 times/second merely to inspect unchanged snapshots.
  clock.release();delay(IdlePowerPolicy::UI_POLL_MS);
}
