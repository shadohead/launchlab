#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include "mic_rpm.h"
#include "early_spin.h"

// The spin heard since a launch, as the Mic RPM page plots it (mic_view_ui.h):
// slots 0.1 s apart from the end of the pull, a locked spin filling every
// second one. The apps start their time axis at the first tracked reading; this
// one starts at the launch, so the late start stays visible. Heard RPM is
// Hz x 60 / the cycles per turn the optical peak resolved, and never the
// optical RPM, which stays a separate marker at time zero.
namespace MicTrace {
constexpr unsigned ANALYSIS_READINGS=3000; // Five minutes, Analysis only.
constexpr unsigned MAX_READINGS=1200;  // 2 minutes of slots; the apps stop at 10
constexpr unsigned LOST_READINGS=80;   // 8 s of slots with no evidence ends a spin, as in the apps
constexpr float HOP_S=float(MicRpm::HOP)/float(MicRpm::TRACK_HZ);
constexpr float FIRST_S=float(MicRpm::WINDOW)/float(MicRpm::TRACK_HZ)/2;  // a reading is timed at its window's centre
constexpr float GAP_S=0.4f;            // a longer gap breaks the line, as in the apps
constexpr float MIN_SPAN_S=10,SPAN_STEP_S=10,MIN_TOP_RPM=9000,TOP_STEP_RPM=3000;

// The slot of a reading `seconds` after the release, at its window's centre.
inline unsigned slot(float seconds){return unsigned(std::lround(std::max(seconds-FIRST_S,0.f)/HOP_S));}
// One reading, from the analysis task to the loop.
struct Step {
  uint32_t launch=0;uint16_t index=0,rpm=0,rejectedRpm=0,rawRpm=0;
  MicRpm::Reason reason=MicRpm::Reason::Quiet;bool last=false, recovered=false, frame=false;uint32_t skippedMs=0,lostFrames=0;
  uint8_t pitchConfidence=0;
  AudioMetadata::Measurement audio{};
};
// The apps' launch detector's evidence of a spin: trusted, or about to be.
inline bool evidence(const MicRpm::Reading &r) {
  return r.valid || (r.reason==MicRpm::Reason::Acquiring && r.support>=3 && r.score>=MicRpm::MIN_SCORE && r.margin>=MicRpm::MIN_MARGIN);
}
inline Step step(uint32_t launch,unsigned index,const MicRpm::Reading &r,bool last) {
  Step s;s.launch=launch;s.index=uint16_t(index);s.reason=r.reason;s.last=last;
  if(r.valid)s.rpm=uint16_t(std::lround(r.rpm));
  return s;
}
// Whether the reading at `index` is the spin's last: `quiet` readings have
// passed without evidence, or the trace is full.
inline bool finished(unsigned index,unsigned quiet){return quiet>=LOST_READINGS || index+1>=MAX_READINGS;}

// A spin's readings in order, on the analysis task: the Step each becomes, and
// when the spin is over.
class Follower {
public:
  explicit Follower(bool analysis=false):analysis_(analysis){}
  Step next(uint32_t launch,const MicRpm::Reading &r,float seconds) {
    const unsigned at=MicTrace::slot(seconds);
    quiet_=evidence(r)?0:quiet_+(skipped_?1:at-slot_);slot_=at;skipped_=false;
    done_=analysis_?at+1>=ANALYSIS_READINGS:finished(at,quiet_);
    auto sample=step(launch,at,r,done_);sample.frame=true;return sample;
  }
  // The reader skipped sound the ring had lost: the slots up to the next
  // reading were never heard, so they are not quiet ones.
  void skip(){skipped_=true;}
  bool done()const{return done_;}
  unsigned slot()const{return slot_;}
private:
  unsigned slot_=0,quiet_=0;bool done_=false,skipped_=false,analysis_=false;
};

// Owned by the loop: the analysis task only sends Steps. Its slots live
// beside it in StoredTrace, so an empty one costs almost nothing.
class Trace {
public:
  constexpr explicit Trace(uint16_t *slots=nullptr,unsigned capacity=MAX_READINGS,uint16_t *rejected=nullptr,uint8_t *recovery=nullptr,uint8_t *pitchConfidence=nullptr):recovery_(recovery),pitchConfidence_(pitchConfidence),rpm_(slots),rejected_(rejected),capacity_(capacity){}
  unsigned capacity()const{return capacity_;}
  void clear(){earlyReadings_=skippedMs_=lostFrames_=0;std::fill(std::begin(reasons_),std::end(reasons_),0);if(recovery_)std::memset(recovery_,0,(capacity_+7)/8);if(pitchConfidence_)std::memset(pitchConfidence_,0,capacity_);launch_=0;count_=heard_=first_=last_=rawCount_=0;peak_=optical_=rejectedPeak_=0;started_=ended_=frozen_=false;reason_=MicRpm::Reason::Quiet;}
  // `opticalRpm`: the launch's peak, 0 when the optical reading was invalid.
  void begin(uint32_t launch,float opticalRpm=0){clear();launch_=launch;optical_=uint16_t(std::lround(std::min(opticalRpm,65535.f)));started_=true;}
  // Steps of an older launch and repeats are ignored; a lost step reads as no reading.
  void add(const Step &s) {
    if(frozen_ || !started_ || s.launch!=launch_ || s.index<count_ || s.index>=capacity_)return;
    while(count_<s.index){if(rejected_)rejected_[count_]=0;rpm_[count_++]=0;}
    if(s.frame){++reasons_[unsigned(s.reason)];skippedMs_=s.skippedMs;lostFrames_=s.lostFrames;}
    if(rejected_){
      const uint16_t raw=s.rawRpm?s.rawRpm:(s.rejectedRpm?s.rejectedRpm:s.rpm);
      rejected_[count_]=raw;
      if(raw){
        ++rawCount_;
        if((s.recovered || s.pitchConfidence) && recovery_)recovery_[s.index/8]|=uint8_t(1u<<(s.index%8));
        if(pitchConfidence_)pitchConfidence_[s.index]=s.pitchConfidence;
        if(!s.recovered && !s.pitchConfidence && std::lround(seconds(s.index)*1000)<=EarlySpin::WINDOW_MS)++earlyReadings_;
      }
      rejectedPeak_=std::max(rejectedPeak_,s.rejectedRpm);
    }
    rpm_[count_++]=s.rpm;reason_=s.reason;ended_=s.last;
    if(!s.rpm)return;
    if(!heard_)first_=s.index;
    last_=s.index;++heard_;peak_=std::max(peak_,s.rpm);
  }
  void freeze(uint32_t endMs=UINT32_MAX){
    frozen_=true;
    const unsigned before=count_;
    // A delayed UI pass may see a window past the five-minute deadline.
    // Endpoint samples cannot also serve as pre-stop RPM observations.
    while(count_ && uint32_t(std::lround(seconds(count_-1)*1000))>=endMs)--count_;
    if(count_==before)return;
    heard_=rawCount_=earlyReadings_=first_=last_=0;peak_=rejectedPeak_=0;
    for(unsigned i=0;i<count_;++i){
      if(rawRpm(i)){
        ++rawCount_;
        if(!recovered(i) && uint32_t(std::lround(seconds(i)*1000))<=EarlySpin::WINDOW_MS)++earlyReadings_;
      }
      rejectedPeak_=std::max(rejectedPeak_,rejectedRpm(i));
      if(!rpm_[i])continue;
      if(!heard_)first_=i;
      ++heard_;last_=i;peak_=std::max(peak_,rpm_[i]);
    }
  }
  bool started()const{return started_;}
  bool ended()const{return ended_;}
  uint32_t launch()const{return launch_;}
  unsigned count()const{return count_;}
  unsigned earlyReadings()const{return earlyReadings_;}
  bool recovered(unsigned i)const{return pitchConfidence(i) || (recovery_ && (recovery_[i/8]&(1u<<(i%8))));}
  uint8_t pitchConfidence(unsigned i)const{return pitchConfidence_?pitchConfidence_[i]:0;}
  unsigned skippedMs()const{return skippedMs_;}
  unsigned lostFrames()const{return lostFrames_;}
  unsigned reasonCount(unsigned i)const{return reasons_[i];}
  unsigned rawCount()const{return rejected_?rawCount_:heard_;}
  unsigned heard()const{return heard_;}
  uint16_t rpm(unsigned i)const{return rpm_[i];}
  uint16_t rawRpm(unsigned i)const{return rejected_?rejected_[i]:rpm_[i];}
  uint16_t rejectedRpm(unsigned i)const{return rejected_ && !rpm_[i]?rejected_[i]:0;}
  uint16_t rejectedPeakRpm()const{return rejectedPeak_;}
  static float seconds(unsigned i){return FIRST_S+float(i)*HOP_S;}
  float elapsed()const{return count_?seconds(count_-1):0;}
  float firstSeconds()const{return seconds(first_);}
  float lastSeconds()const{return seconds(last_);}
  uint16_t firstRpm()const{return heard_?rpm_[first_]:0;}
  uint16_t latestRpm()const{return heard_?rpm_[last_]:0;}
  uint16_t peakRpm()const{return peak_;}
  uint16_t opticalRpm()const{return optical_;}
  MicRpm::Reason reason()const{return reason_;}
  // The change from the first reading to the latest, in percent.
  float changePercent()const{return heard_?100*(float(latestRpm())-float(firstRpm()))/float(firstRpm()):0;}
private:
  uint8_t *recovery_;
  uint8_t *pitchConfidence_;
  unsigned earlyReadings_=0,skippedMs_=0,lostFrames_=0;uint16_t reasons_[MicRpm::REASONS]={};
  uint16_t *rpm_;       // 0: no trusted reading
  uint16_t *rejected_;  // Optional Analysis-only original acoustic readings, before the filter
  unsigned capacity_;
  uint32_t launch_=0;unsigned count_=0,heard_=0,first_=0,last_=0,rawCount_=0;uint16_t peak_=0,optical_=0,rejectedPeak_=0;
  bool started_=false,ended_=false,frozen_=false;MicRpm::Reason reason_=MicRpm::Reason::Quiet;
};
class StoredTrace:public Trace {
public:
  StoredTrace():Trace(slots_){}
private:
  uint16_t slots_[MAX_READINGS]={};
};

// A made-up spin: `silent` readings before the first trusted one, then an
// exponential decline over `seconds`, which stays above the tracker's 1,800
// RPM floor for two minutes at 100. For the render check and USB `Y`.
inline void demo(Trace &t,unsigned readings,unsigned silent,float seconds=30) {
  t.begin(0,6900);
  for(unsigned i=0;i<readings;++i) {
    Step s;s.index=uint16_t(i);s.reason=i<silent?MicRpm::Reason::BroadbandNoise:MicRpm::Reason::Tracking;
    if(i>=silent)s.rpm=uint16_t(std::lround(6700*std::exp(-float(i-silent)*HOP_S/seconds)));
    t.add(s);
  }
}

// The axes: 0 RPM at the foot as in the apps, with whole thousands at each of
// their three divisions, and a whole number of 10 s spans so they stay put.
inline float topRpm(float peak){return std::ceil(std::max(MIN_TOP_RPM,peak*1.08f)/TOP_STEP_RPM)*TOP_STEP_RPM;}
inline float spanSeconds(float elapsed){return std::max(MIN_SPAN_S,std::ceil(elapsed/SPAN_STEP_S)*SPAN_STEP_S);}
// Calls emit(column,rpm,join) for each point of the line, columns counted
// from the launch in a plot `width` pixels across: the mean of the readings
// on that column, so a long spin costs at most one segment per column. `join`
// connects it to the point before; a gap of GAP_S or more does not.
template<class Emit> inline void columns(const Trace &t,int width,float span,Emit emit) {
  if(!t.heard())return;
  int column=-1;float sum=0,previous=0;unsigned n=0;bool join=false;
  for(unsigned i=0;i<t.count();++i) {
    if(!t.rpm(i))continue;
    const float time=Trace::seconds(i);
    const int x=int(std::lround(time/span*float(width)));
    if(n && x!=column){emit(column,sum/float(n),join);join=time-previous<GAP_S;sum=0;n=0;}
    column=x;sum+=float(t.rpm(i));++n;previous=time;
  }
  if(n)emit(column,sum/float(n),join);
}
}
