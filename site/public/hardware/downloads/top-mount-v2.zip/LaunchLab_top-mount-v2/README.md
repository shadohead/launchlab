# LaunchLab Top Mount v2 — extra hook engagement

| Part | Version | Print-pose STL |
| --- | --- | --- |
| Shell, unchanged from v1 | Top Mount v2 pairing | [Shell](stl/LaunchLab_Top_Mount_v2_shell_UPRIGHT.stl) |
| Matching dock with extended hooks | Top Mount v2 | [Dock](stl/LaunchLab_Top_Mount_v2_dock_FLAT.stl) |

[Download both STLs](LaunchLab_Top_Mount_v2_STLs.zip). Units are millimetres; both parts rest at Z=0. **If you already have the v1 shell, reprint only the dock.** The shell STL and STEP are byte-for-byte identical to v1. The separate shared sensor attachment is not included.

## Change from v1

Both dock hooks gain 0.5 mm of outward reach, increasing overhang from 1.6 to **2.1 mm** (1.9 mm past the nominal shell inner face). The flexible arm roots move 2 mm toward the rear, lengthening the arms; relief slots grow from 2.8 to 3.4 mm. The neck top is lowered to Z=13.5 mm so it flexes below the Hat plugs; the hook-bearing tips remain full height. Two 1 mm floor ribs shift 0.6 mm inward to stay clear of the wider flex envelope. The shell windows, bottom chamfer, mounting ears and device seat remain unchanged.

The added reach is measured normal to each tapered side wall, not vertically or along the arm. Both hooks measure **+0.500 mm**. Changes are confined to the latch region; no extra clearance is added to the shell windows to cancel the engagement increase. Press both hooks inward to release.

## Paired print projects

- [P1S PLA — shell and dock on one plate](bambu/LaunchLab_Top_Mount_v2_P1S_PLA_shell_and_dock.3mf): 52m 59s, 10.73 g.
- [P1S PETG — shell and dock on one plate](bambu/LaunchLab_Top_Mount_v2_P1S_PETG_shell_and_dock.3mf): 53m 40s, 10.65 g.

Profiles use a P1S 0.4 mm nozzle, 0.2 mm layers, Arachne walls and slim tree supports from the build plate. Both projects passed settings, geometry, temperatures, plate and shell-support audits. Clip necks receive model extrusion through their full height in both materials; no deposited support segment reaches the snap arms. These are local print preparations; no printer was contacted.

## CAD and review

- [Blender model](LaunchLab_Top_Mount_v2_review.blend) and actual CAD images in `renders/`.
- `step/` contains both full CAD solids. Fasteners remain 2 × M2x4 M5-to-dock and 4 × M2x6 dock-to-QRE-base.
- `preview/` contains assembly-coordinate parts and references; print from `stl/` or the paired projects.
- `reports/cad_validation.json` records fit, access, plug, receiver, insertion and approximate clip-flex checks.
- `reports/change_from_v1.json` records both 0.5 mm measurements, unchanged shells and confined changes.
- `reports/print/` records fresh plate and clip-deposition audits; `reports/stl_readback.json` records mesh checks.

The nominal small-deflection beam estimate is about 1.68% maximum outer-fibre strain. It is an approximation, not nonlinear FEA. **Printed snap feel, retention, insertion force and fatigue remain untested.** Reference hardware and illustrative wires/proxies are not print parts.

## Release history

This supersedes [Top Mount v1](../v1/README.md) for new mount prints. The next Top Mount revision is v3; the other mount family has its own counter. Prior versions remain frozen. This is a mount-pair release, not a new full sensor kit.

Build CAD with `.venv/bin/python scripts/build_top_mount_v2.py`, prepare/audit plates with `.venv/bin/python scripts/print_mount_pair_v2.py top_mount`, and check clip toolpaths with `.venv/bin/python scripts/check_mount_v2_print_clips.py top_mount`. Run `scripts/check_mount_v2_geometry.py` after both CAD builds. Publish with `.venv/bin/python scripts/release_mount_family.py --family top_mount --spec scripts/mount_release_v2_specs.json`. `manifest.json` maps copied assets to source paths and SHA-256 hashes.
