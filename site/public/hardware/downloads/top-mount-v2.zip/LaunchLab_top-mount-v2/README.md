# LaunchLab Top Mount v2 print package

This package contains the shell and matching dock for the Compact QRE1113 Top Mount layout.
The separate QRE sensor attachment, M5StickS3, fasteners and wires are not included.
Download the matching sensor attachment from the [LaunchLab downloads page](https://launchlab.beywatch.gg/downloads).

## Included files

| File | Use |
| --- | --- |
| [Shell STL](stl/LaunchLab_Top_Mount_v2_shell_UPRIGHT.stl) | Shell in its printing orientation. |
| [Dock STL](stl/LaunchLab_Top_Mount_v2_dock_FLAT.stl) | Matching dock in its printing orientation. |
| [PLA plate](bambu/LaunchLab_Top_Mount_v2_P1S_PLA_shell_and_dock.3mf) | Both pieces on one saved Bambu P1S PLA plate. |
| [PETG plate](bambu/LaunchLab_Top_Mount_v2_P1S_PETG_shell_and_dock.3mf) | Both pieces on one saved Bambu P1S PETG plate. |
| [Shell STEP](step/LaunchLab_Top_Mount_v2_shell.step) | Shell CAD solid for inspection or editing. |
| [Dock STEP](step/LaunchLab_Top_Mount_v2_dock.step) | Dock CAD solid for inspection or editing. |
| [PLA profile](print_profiles/PLA.json) and [PETG profile](print_profiles/PETG.json) | Saved material profiles. |
| [Machine profile](print_profiles/machine.json) and [process profile](print_profiles/process.json) | Saved printer and slicing settings. |
| [Current assemblies](CURRENT_ASSEMBLIES.md) | Matching sensor and mount combinations. |
| [Source record](SOURCE.json) | Frozen input identity, source hashes and supplied notices. |
| [Checksums](SHA256SUMS.txt) | SHA-256 inventory of the other files in this archive. |

Together with this README, the archive contains 14 files.

## Print and assemble

1. Extract the ZIP before opening a file.
2. For a Bambu P1S with a 0.4 mm nozzle, open the plate for your material in Bambu Studio.
   Review the saved settings, supports and loaded filament before printing.
   The PLA and PETG projects each contain both mating pieces.
3. For another printer or slicer, import both STLs and reslice for your machine and material.
   STL dimensions are in millimetres; the supplied poses rest at Z=0.
4. If you already have the Top Mount v1 shell, print only the v2 dock.
   The paired shell geometry is unchanged from v1.
5. Fasten the intact M5StickS3 to the dock with two M2x4 screws and the dock to the matching QRE base with four M2x6 screws.
   Fit the shell over the dock; press both hooks inward to release it.

Use the [assembly guide](https://launchlab.beywatch.gg/build?model=compact) for the complete parts list and wiring.
The saved plate estimates are 52 min 59 s / 10.73 g for PLA and 53 min 40 s / 10.65 g for PETG.
Actual results depend on the printer, material and settings.
Check fit and snap retention after printing; digital checks do not establish physical fit or durability.

## Printing files and CAD rebuild scripts

The included STLs and 3MF plates are the files you use to print these parts.
The STEP files let you inspect or edit the supplied CAD solids.
CAD rebuild scripts instead regenerate models from parameters and reference geometry.
Those scripts and their required inputs are maintained in the private hardware development repository; they are not included here or published in the public source repository.
This ZIP does not provide a self-contained CAD regeneration workflow.
You do not need the rebuild scripts to print the included parts.
