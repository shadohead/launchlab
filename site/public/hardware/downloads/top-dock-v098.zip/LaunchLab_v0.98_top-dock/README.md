# Four-screw M5 dock and QRE base v098

The M5 dock is now held at four corners instead of two.
The bracket gains two ears at its Hat end, and the dock-ready QRE base gains two matching pilots.
The new pair mirrors the existing pair at (X +/-14.5, Y 12) about the plate centre: (X +/-14.5, Y -12).
The four screws form a 29 x 24 mm pattern. A true 29 mm square would put the new pilots past the plate's Hat-end edge (Y -16.5).

The new ears and pilots copy the v073 originals exactly:
- **Ear:** a 2.8 mm radius pad run out from the rail and shroud wall, Z 11.2 to 13.4, with a 2.2 mm clearance hole.
- **Pilot:** a 2.6 mm boss on a 45-degree foot from the Z 7.4 deck to Z 11.2, with a 1.7 mm hole to Z 7.2.
- **Screws:** four M2x6 pan-head. Each new screw engages 3.8 mm, as the originals do, with its tip 0.2 mm above the pilot bottom.

The dock is otherwise the v096 cable-shroud dock: 17 mm string-launcher shroud, constant 3 mm chamfer, open floor for the right-angle QRE leads.
The base is otherwise the v073 plate: v067 open holders, stripe recess, sensor pocket and keeper unchanged (154 mm3 added, only inside the two new pilot zones).

Checks (CAD, nominal):
- New screws seat on their ears, with a clear 3 mm driver column straight down past the shroud wall and the M5.
- The M5 case, all 16 Hat plug positions, the QRE parts, the right-angle QRE plugs and the latch motion from 0 to 90 degrees have zero overlap.
- The dock still lifts straight off the base, and the M5 still slides in along the rails.
- Minimum sampled upper skin: 1.53 mm.
- The open clips clear the new pilots in the base print pose.

Print files:
- Dock: flat underside down, tree supports from the build plate only, 29m 30s, 4.61 g.
- Base: the v073 print pose with the clips open, plus the pressure bar, slim tree supports from the build plate with the hinge support blockers, 52m 14s, 10.08 g. The hinge-gap support and layer-deposition audits pass.

Compatibility: the four-pilot base still takes the two-screw v096 dock (the new pilots stay empty) and the separate v097 carrier.
The four-screw dock needs the four-pilot base for its new screws.
Physical fit, screw engagement and harness slack are unverified. No printer job was dispatched.

## Release notes

Default top-mounted M5 dock from 2026-10-07, replacing the two-screw [v096 dock](../LaunchLab_v096_QRE_M5_cable_shroud_dock/README.md).
It screws onto the [four-screw QRE base](../LaunchLab_v098_QRE_four_screw_base/README.md) with 4 x M2x6.
Print `bambu/LaunchLab_v098_P1S_TREE_PLATE_PLA.3mf`: P1S PLA, flat underside down, tree supports from the build plate only, about 29m 30s and 4.61 g.
