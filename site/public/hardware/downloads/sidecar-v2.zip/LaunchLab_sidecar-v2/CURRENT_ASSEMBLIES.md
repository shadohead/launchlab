# Current mount combinations

Compact: v102 QRE sensor base with either Top Mount v2 (shell and dock) or Sidecar v2 (shell and base).
Standard: v102 TCRT sensor attachment with Sidecar v2.
This package README lists the included files and how to print them; CAD rebuild scripts are not included.
Mount pairs exclude the separate sensor attachment. Reference hardware is not a print part.
Sidecar sensor placement in the website is illustrative; printed fit/retention remain untested.
Sidecar level and tilt replay mapping awaits the upcoming orientation firmware.
See https://launchlab.beywatch.gg/build and https://launchlab.beywatch.gg/downloads for matching parts.
