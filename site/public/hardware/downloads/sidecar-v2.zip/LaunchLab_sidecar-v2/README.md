# LaunchLab Sidecar v2 — extra hook engagement

| Part | Version | Print-pose STL |
| --- | --- | --- |
| Shell, unchanged from v1 | Sidecar v2 pairing | [Shell](stl/LaunchLab_Sidecar_v2_shell_UPRIGHT.stl) |
| Matching base with extended hooks | Sidecar v2 | [Base](stl/LaunchLab_Sidecar_v2_base_SEAT_DOWN.stl) |

[Download both STLs](LaunchLab_Sidecar_v2_STLs.zip). Units are millimetres; both parts rest at Z=0. **If you already have the v1 shell, reprint only the base.** The shell STL and STEP are byte-for-byte identical to v1. The separate shared sensor attachment is not included.

## Change from v1

Both base hooks gain 0.5 mm of outward reach, increasing effective engagement from 0.8 to **1.3 mm**. Inward relief slots grow from 2.0 to 2.6 mm to allow insertion and release. The flexible arm roots, thickness and receiver interfaces stay as v1. The left enclosed wire cutout and bottom chamfer are unchanged. Thread the wires through before snapping on the shell.

The added reach is measured normal to each tapered side wall, not vertically or along the arm. Both hooks measure **+0.500 mm**. Changes are confined to the latch region; no extra clearance is added to the shell windows to cancel the engagement increase. Press both hooks inward to release.

## Paired print projects

- [P1S PLA — shell and base on one plate](bambu/LaunchLab_Sidecar_v2_P1S_PLA_shell_and_base.3mf): 1h 2m 55s, 15.54 g.
- [P1S PETG — shell and base on one plate](bambu/LaunchLab_Sidecar_v2_P1S_PETG_shell_and_base.3mf): 1h 3m 48s, 15.43 g.

Profiles use a P1S 0.4 mm nozzle, 0.2 mm layers, Arachne walls and slim tree supports from the build plate. Both projects passed settings, geometry, temperatures, plate and shell-support audits. Clip necks receive model extrusion through their full height in both materials; no deposited support segment reaches the snap arms. These are local print preparations; no printer was contacted.

## CAD and review

- [Blender model](LaunchLab_Sidecar_v2_review.blend) and actual CAD images in `renders/`.
- [Interactive 3D assembly](LaunchLab_Sidecar_v2_review.glb); `step/` contains the shell and the seat/clip solid. The base STEP excludes the mesh-derived native grip head; the full base STL includes it.
- `preview/` contains assembly-coordinate parts and references; print from `stl/` or the paired projects.
- `reports/cad_validation.json` records fit, access, plug, receiver, insertion and approximate clip-flex checks.
- `reports/change_from_v1.json` records both 0.5 mm measurements, unchanged shells and confined changes.
- `reports/print/` records fresh plate and clip-deposition audits; `reports/stl_readback.json` records mesh checks.

The nominal small-deflection beam estimate is about 1.63% maximum outer-fibre strain. It is an approximation, not nonlinear FEA. **Printed snap feel, retention, insertion force and fatigue remain untested.** Reference hardware and illustrative wires/proxies are not print parts.

## Release history

This supersedes [Sidecar v1](../v1/README.md) for new mount prints. The next Sidecar revision is v3; the other mount family has its own counter. Prior versions remain frozen. This is a mount-pair release, not a new full sensor kit.

Build CAD with `.venv/bin/python scripts/build_sidecar_v2.py`, prepare/audit plates with `.venv/bin/python scripts/print_mount_pair_v2.py sidecar`, and check clip toolpaths with `.venv/bin/python scripts/check_mount_v2_print_clips.py sidecar`. Run `scripts/check_mount_v2_geometry.py` after both CAD builds. Publish with `.venv/bin/python scripts/release_mount_family.py --family sidecar --spec scripts/mount_release_v2_specs.json`. `manifest.json` maps copied assets to source paths and SHA-256 hashes.
