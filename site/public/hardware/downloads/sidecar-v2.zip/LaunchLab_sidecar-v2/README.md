# LaunchLab Sidecar v2 print package

This package contains the shell and matching base for the sideways M5StickS3 Sidecar layout.
It pairs with either the Compact QRE1113 or Standard TCRT5000 sensor attachment.
The separate sensor attachment, M5StickS3, fasteners and wires are not included.
Download the matching sensor attachment from the [LaunchLab downloads page](https://launchlab.beywatch.gg/downloads).

## Included files

| File | Use |
| --- | --- |
| [Shell STL](stl/LaunchLab_Sidecar_v2_shell_UPRIGHT.stl) | Shell in its printing orientation. |
| [Base STL](stl/LaunchLab_Sidecar_v2_base_SEAT_DOWN.stl) | Complete base, including the launcher interface, in its printing orientation. |
| [PLA plate](bambu/LaunchLab_Sidecar_v2_P1S_PLA_shell_and_base.3mf) | Both pieces on one saved Bambu P1S PLA plate. |
| [PETG plate](bambu/LaunchLab_Sidecar_v2_P1S_PETG_shell_and_base.3mf) | Both pieces on one saved Bambu P1S PETG plate. |
| [Shell STEP](step/LaunchLab_Sidecar_v2_shell.step) | Shell CAD solid for inspection or editing. |
| [Seat and clips STEP](step/LaunchLab_Sidecar_v2_seat_and_clips_ONLY.step) | Seat and clip solids only; this STEP omits the launcher interface included in the full base STL. |
| [PLA profile](print_profiles/PLA.json) and [PETG profile](print_profiles/PETG.json) | Saved material profiles. |
| [Machine profile](print_profiles/machine.json) and [process profile](print_profiles/process.json) | Saved printer and slicing settings. |
| [Current assemblies](CURRENT_ASSEMBLIES.md) | Matching sensor and mount combinations. |
| [Source record](SOURCE.json) | Frozen input identity, source hashes and supplied notices. |
| [Checksums](SHA256SUMS.txt) | SHA-256 inventory of the other files in this archive. |

Together with this README, the archive contains 14 files.

## Print and assemble

1. Extract the ZIP before opening a file.
2. For a Bambu P1S with a 0.4 mm nozzle, open the plate for your material in Bambu Studio.
   Review the saved settings, supports and loaded filament before printing.
   The PLA and PETG projects each contain both mating pieces.
3. For another printer or slicer, import both STLs and reslice for your machine and material.
   Use the complete base STL for printing; the seat-and-clips STEP is only part of the base.
   STL dimensions are in millimetres; the supplied poses rest at Z=0.
4. If you already have the Sidecar v1 shell, print only the v2 base.
   The paired shell geometry is unchanged from v1.
5. Fasten the intact M5StickS3 to the base with two M2x4 screws into its secondary back holes.
   Thread the wires through the enclosed left-side exit before fitting the shell.
   Press both hooks inward to release it.

Use the [Compact Sidecar assembly guide](https://launchlab.beywatch.gg/build?model=compact&mount=side-qre) or [Standard Sidecar assembly guide](https://launchlab.beywatch.gg/build?model=standard) for the complete parts list and wiring.
The saved plate estimates are 1 h 2 min 55 s / 15.54 g for PLA and 1 h 3 min 48 s / 15.43 g for PETG.
Actual results depend on the printer, material and settings.
Check fit and snap retention after printing; digital checks do not establish physical fit or durability.

## Printing files and CAD rebuild scripts

The included STLs and 3MF plates are the files you use to print these parts.
The STEP files let you inspect or edit the supplied CAD solids, subject to the partial-base limitation above.
CAD rebuild scripts instead regenerate models from parameters and reference geometry.
Those scripts and their required inputs are maintained in the private hardware development repository; they are not included here or published in the public source repository.
This ZIP does not provide a self-contained CAD regeneration workflow.
You do not need the rebuild scripts to print the included parts.
