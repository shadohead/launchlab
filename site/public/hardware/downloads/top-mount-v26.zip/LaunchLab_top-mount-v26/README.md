# LaunchLab Top Mount v26: one-dot clamps

Four printed units for the QRE1113 Top Mount: base with captive one-dot clamps, sensor retainer, M5 cradle, and M5 snap cover. No Sidecar adapter or sensor cover is included.

The clamps use the 0.375 mm snap cap, lower tray and shallower underside. Keep the two captive clamps separate in the slicer; do not fuse or reposition them. The Top Mount and existing Sidecar v15 with QRE1113 can use the separate clip-base-only upgrade. TCRT5000 is unchanged.

Editable CAD, mesh readback and the supplied P1S PLA/PETG slices passed digital checks. Check physical fit on your launcher; universal fit, retention, and fatigue are not established.
