# Uniform-hinge QRE1113 launcher mount (default base)

This is the default launcher mount from 2026-10-09, replacing the [v101 LaunchLab-mark base](../LaunchLab_v101_QRE_logo_flush_base/README.md).
It is v101 with one change to the clip hinges; the LaunchLab mark, flush underside and solid hinges stay.

Each hinge block is now one height, Z13.28 mm, from the cup face to the D tip.
In v101 the block between the cap's outer end and the cup face stopped 1.8 mm lower, at the cap underside, so a right-angle step dropped off the cap and only about 0.5 mm of plastic covered the shaft bore there.
Each cap now runs out to the cup face at full height, with the same 0.45 mm rounded top edge, square outer corners like the cup below, and the cup-face groove carried up to the top.
The plastic over the bore is now at least 2.1 mm everywhere (67 mm3 added over both hinges).
It also trims a 0.05 mm sliver of the old v064 cap that stood proud of each cap side next to the hinge relief (0.03 mm3 removed).

Everything else is unchanged from v101: the four M2 dock pilots (29 x 24 mm), clips, sensor pocket, keeper, optical datum (Z3.1 mm) and launcher contacts.
The M5StickS3 still mounts either way without reprinting this base:

- **On top of the QRE:** the [four-screw dock](../LaunchLab_v098_QRE_M5_four_screw_dock/README.md) with 4 x M2x6 pan-head screws, or the older two-screw v096 dock.
- **Separate carrier:** leave the pilots empty and use the [v097 M5 carrier](../LaunchLab_v097_M5_carrier_chamfered_shroud/README.md).

Fit the analog SparkFun QRE1113 and secure the pressure bar with 2 x M2x4. The QRE uses right-angle Dupont connectors.

Print `bambu/LaunchLab_v102_P1S_PLA_QRE_UNIFORM_HINGES_BASE_TREE_SLIM_PLA.3mf`: the plate with both clips captive and fully open, its two hinge support blockers, and the pressure bar.
P1S 0.4 mm, PLA, 0.2 mm layers, four Arachne walls, 25% gyroid, slim tree supports from the build plate only with 1.0 mm XY clearance.
Local estimate: 52m 57s, 10.54 g (2.5 g support). Select AMS slot A3 when sending.
Remove exterior supports after cooling and gently rotate the clips closed.

CAD checks: the block top is Z13.284 everywhere inside its rounded rim, and the cap plan section matches the nominal outline (cup face to D tip, minus the groove) at every level.
Material is added only on top of the block and removed only as the four slivers.
The caps keep their gap to both docks (v098 0.10 mm, v096 0.10 mm, unchanged), and no part or reference gains any overlap.
Both clips still sweep 0 to 90 degrees freely, keep a 0.60 mm print-pose gap and stay captive.
Print checks on this exact project: mesh readback, no support in either hinge gap (165802 support segments checked) and model deposition in every sliced cross-section component.
The layer check now samples each cross-section 0.003 mm either side of mid-layer and keeps the median, because an exact plane can meet mesh vertices and return a broken section.
The uniform hinges are unprinted.

Original BP Gear Port: Migbello / Thingiverse 6856080 / CC BY-SA. See LICENSE.txt.
