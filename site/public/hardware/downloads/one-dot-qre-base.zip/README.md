# One-dot captive base upgrade for QRE1113

Replaces only the printed base with captive clamps on Top Mount v25 or Sidecar v15; the updated complete Top Mount v26 already contains this base. Keep all other existing parts. No Sidecar adapter, shell, sensor cover, electronics, or TCRT5000 parts included.

The STL prints as one unit with three separate bodies. Do not fuse, split, or reposition them. PLA and PETG 3MFs are saved P1S projects; use the appropriate material project and reslice if your setup differs. Check physical fit before use.
