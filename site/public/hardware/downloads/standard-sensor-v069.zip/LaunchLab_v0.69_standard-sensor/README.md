TCRT5000 open print-in-place mount v069

Uses the user-approved QRE v067 open holder standard: original open cups,
rounded integral caps, continuous 4.8 mm receiver posts, 0.6 mm radial printing
clearance, and untouched lower bracing. Print both clips fully open with
vertical axles. External tree supports are needed; hinge blockers are included.
Remove external supports and rotate the clips closed. No clip screws.

The v057 sensor pocket, 12.8 mm PCB seat, optical window, 6.4 mm reinforced
shoulders, 13.3 mm sensor walls, and single M3 board standoff stay unchanged.
The M5 carrier is separate. Use the existing board screw; there is no top keeper.

Shared-helper parity with QRE v067, protected CAD regions, 0–90 degree clip
sweep, captivity, watertight meshes and reference collisions are verified.
The TCRT port still needs a physical fit test. No printer dispatch.

Full P1S PLA slice: 50m50s / 9.86 g. Single hinge test: 23m44s / 2.90 g.
Arachne, four walls, 0.2 mm layers, 25% gyroid, 5 mm brim, slim tree supports
from build plate only. Two hinge blockers on the full mount. Bambu geometry,
G-code checksum, support gaps and every sampled model section passed.
Native Prusa imports/re-exports preserve geometry and support blockers;
select your printer and PLA profiles and reslice in Prusa.
