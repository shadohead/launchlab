# Uniform-hinge TCRT5000 launcher mount

This is the current TCRT5000 mount from 2026-10-09, replacing [TCRT v100](../LaunchLab_v100_TCRT_solid_hinges/README.md).
It has the same hinge change as the [QRE v102 base](../LaunchLab_v102_QRE_uniform_hinges_base/README.md).

Each hinge block is now one height, Z13.28 mm, from the cup face to the D tip.
In v100 the block between the cap's outer end and the cup face stopped 1.8 mm lower, at the cap underside, so a right-angle step dropped off the cap and only about 0.5 mm of plastic covered the shaft bore there.
Each cap now runs out to the cup face at full height, with the same 0.45 mm rounded top edge, square outer corners like the cup below, and the cup-face groove carried up to the top.
The plastic over the bore is now at least 2.1 mm everywhere (67 mm3 added over both hinges).
It also trims a 0.05 mm sliver of the old v064 cap that stood proud of each cap side next to the hinge relief (0.03 mm3 removed).

The v057 sensor pocket, 12.8 mm PCB seat, optical window, reinforced shoulders, sensor walls, single M3 board standoff and solid hinges are unchanged.
The M5 carrier is separate. Use the existing board screw; there is no top keeper. No clip screws.

Print `bambu/LaunchLab_v102_P1S_PLA_TCRT_UNIFORM_HINGES_TREE_SLIM.3mf`: the mount with both clips captive and fully open and its two hinge support blockers.
P1S 0.4 mm, PLA, 0.2 mm layers, four Arachne walls, 25% gyroid, 5 mm brim, slim tree supports from the build plate only.
Local estimate: 51m 7s, 10.12 g (2.7 g support). Select AMS slot A3 when sending.
Remove exterior supports after cooling and gently rotate the clips closed.

CAD checks: the block top is Z13.284 everywhere inside its rounded rim, and the cap plan section matches the nominal outline (cup face to D tip, minus the groove) at every level.
Material is added only on top of the block and removed only as the four slivers.
No part or reference gains any overlap.
Both clips still sweep 0 to 90 degrees freely, keep a 0.60 mm print-pose gap and stay captive.
Print checks on this exact project: mesh readback, no support in either hinge gap (180372 support segments checked) and model deposition in every sliced cross-section component.
The layer check now samples each cross-section 0.003 mm either side of mid-layer and keeps the median, because an exact plane can meet mesh vertices and return a broken section.
The uniform hinges are unprinted.

Original BP Gear Port: Migbello / Thingiverse 6856080 / CC BY-SA. See LICENSE.txt.
