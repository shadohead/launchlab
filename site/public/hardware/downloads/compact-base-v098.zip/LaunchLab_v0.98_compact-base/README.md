# Four-screw QRE1113 launcher mount (default base)

This is the default launcher mount from 2026-10-07, replacing the [two-pilot v073 base](../LaunchLab_v073_QRE_dock_ready_base/README.md).
It is the v073 Split-X plate with four M2 dock pilots instead of two.
The new pair sits at the Hat end, mirroring the original pair: X +/-14.5 at Y 12 and Y -12, a 29 x 24 mm pattern.

The M5StickS3 can still move between mounting spots without reprinting this base:

- **On top of the QRE:** screw the [four-screw dock](../LaunchLab_v098_QRE_M5_four_screw_dock/README.md) into all four pilots with 4 x M2x6 pan-head screws. The older two-screw v096 dock also fits; its two screws use the original pilots.
- **Separate carrier:** leave the pilots empty and use the [v097 M5 carrier](../LaunchLab_v097_M5_carrier_chamfered_shroud/README.md).

The holders, sensor pocket, keeper, optical datum (Z3.1 mm) and launcher contacts are unchanged from v073. Only the two new pilot zones gain material.
Fit the analog SparkFun QRE1113 and secure the existing pressure bar with 2 x M2x4. The QRE uses right-angle Dupont connectors.

Print `bambu/LaunchLab_v098_P1S_PLA_QRE_FOUR_SCREW_BASE_TREE_SLIM_PLA.3mf`: the plate with both clips captive and fully open, its two hinge support blockers, and the pressure bar.
P1S 0.4 mm, PLA, 0.2 mm layers, four Arachne walls, 25% gyroid, slim tree supports from the build plate only with 1.0 mm XY clearance.
Local estimate: 52m 14s, 10.08 g (2.5 g support). Select AMS slot A3 when sending.
Remove exterior supports after cooling and gently rotate the clips closed.

Checks on this exact project: mesh readback against the four-pilot STLs, no support in either hinge gap (164639 support segments checked), and model deposition in every sliced cross-section component.
The open clips clear the new pilots in the print pose. Physical screw engagement is unverified.

Original BP Gear Port: Migbello / Thingiverse 6856080 / CC BY-SA. See LICENSE.txt.
